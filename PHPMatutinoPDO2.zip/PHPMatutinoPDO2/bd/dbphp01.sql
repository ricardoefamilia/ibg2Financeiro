drop database if exists dbphp01;
create database dbphp01;
use dbphp01;

-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 10-Set-2021 às 20:05
-- Versão do servidor: 5.7.21-log
-- versão do PHP: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `dbphp01`
--

DELIMITER $$
--
-- Procedimentos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `iCadastroPessoa` (IN `nomeP` VARCHAR(255), `dtNascP` DATE, `loginP` VARCHAR(65), `senhaP` VARCHAR(64), `perfilP` VARCHAR(20), `emailP` VARCHAR(255), `cpfP` VARCHAR(14), `cepP` VARCHAR(10), `logradouroP` VARCHAR(255), `complementoP` VARCHAR(255), `bairroP` VARCHAR(255), `cidadeP` VARCHAR(255), `ufP` VARCHAR(2), OUT `msg` TEXT)  begin
declare idx int(11) default -1;
declare idp int(11) default 0;

select idpessoa into idp from pessoa where cpf = cpfP;
if(idp > 0)then
    set msg = "Usuário cadastrado anteriormente.";
else
    select idendereco into idx from endereco where 
logradouro = logradouroP and complemento = complementoP and 
cep = cepP;
    if(idx = -1) then
        insert into endereco values (null, logradouroP, complementoP,
           bairroP, cidadeP, ufP, cepP);
        select idendereco into idx from endereco where 
            logradouro = logradouroP and complemento = complementoP and 
            cep = cepP;
    end if;
    insert into pessoa values (null, nomeP, dtNascP, loginP,
        md5(senhaP), perfilP, emailP, cpfP, idx);
    set msg = "Dados cadastrados com sucesso.";
end if;
select msg;
end$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `endereco`
--

CREATE TABLE `endereco` (
  `idendereco` int(11) NOT NULL,
  `logradouro` varchar(255) NOT NULL,
  `complemento` varchar(255) NOT NULL,
  `bairro` varchar(255) NOT NULL,
  `cidade` varchar(255) NOT NULL,
  `uf` varchar(2) NOT NULL,
  `cep` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `endereco`
--

INSERT INTO `endereco` (`idendereco`, `logradouro`, `complemento`, `bairro`, `cidade`, `uf`, `cep`) VALUES
(1, 'QI 23 Lote 14, Guará II, Guará II', 'ss', 'Guará II', 'Brasília', 'DF', '71060639'),
(2, 'QI 23 Lote 14', 'aa', 'Guará II', 'Brasília', 'DF', '71060639'),
(3, 'QI 23 Lote 14, Guará II', 'aa', 'Guará II', 'Brasília', 'DF', '71060639'),
(4, 'Praça da Sé', 'lado ímpar', 'Sé', 'São Paulo', 'SP', '01001-000'),
(5, 'Praça da Sé', 'lado par', 'Sé', 'São Paulo', 'SP', '01001-000'),
(6, 'QE 40 Conjunto Q, Guará II', 'feee', 'Guará II', 'Brasília', 'DF', '71070-172'),
(7, 'QI 23 Lote 14, Guará II', 'ddd', 'Guará II', 'Brasília', 'DF', '71060639'),
(8, 'QE 40 Conjunto Q, Guará II', 'fff', 'Guará II', 'Brasília', 'DF', '71070-172'),
(9, 'QE 40 Conjunto Q, Guará II', 'ddd', 'Guará II', 'Brasília', 'DF', '71070-172'),
(10, 'Rua Amapurus', '130', 'Tauá', 'Rio de Janeiro', 'RJ', '21920-120'),
(11, 'QE 40 Conjunto Q', 'dd', 'Guará II', 'Brasília', 'DF', '71070-172');

-- --------------------------------------------------------

--
-- Estrutura da tabela `fornecedor`
--

CREATE TABLE `fornecedor` (
  `idfornecedor` int(11) NOT NULL,
  `nomeFornecedor` varchar(255) NOT NULL,
  `representante` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telfixo` varchar(20) NOT NULL,
  `telcel` varchar(20) NOT NULL,
  `fkendereco` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `fornecedor`
--

INSERT INTO `fornecedor` (`idfornecedor`, `nomeFornecedor`, `representante`, `email`, `telfixo`, `telcel`, `fkendereco`) VALUES
(4, 'Nike', 'André', 'rosilenebaptistaamaral@yahoo.com.br', '61 2342-3422', '61 9827-9878', 2),
(5, 'Adidas', 'Fernando Gaúcho', 'dfdf@dfdf', '61 2555-5577', '61 9888-8888', 11);

-- --------------------------------------------------------

--
-- Estrutura da tabela `pessoa`
--

CREATE TABLE `pessoa` (
  `idpessoa` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `dtNasc` date NOT NULL,
  `login` varchar(65) NOT NULL,
  `senha` varchar(64) NOT NULL,
  `perfil` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `fkendereco` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `pessoa`
--

INSERT INTO `pessoa` (`idpessoa`, `nome`, `dtNasc`, `login`, `senha`, `perfil`, `email`, `cpf`, `fkendereco`) VALUES
(2, 'Carlos', '1980-03-20', 'carlos', '4a8a08f09d37b73795649038408b5f33', 'Funcionário', 'carlos@gmail.com', '297.482.734-23', 3),
(5, 'Roberto Carlos', '1968-03-23', 'mariag', 'f8461b554d59b3014e8ff5165dc62fac', 'Cliente', 'maria@bol.com.br', '262.267.790-12', 5),
(7, 'Elaine', '1990-10-10', 'elaine', 'e1671797c52e15f763380b45e841ec32', 'Cliente', 'elaine@gmail.com', '591.930.360-35', 7),
(10, 'Josué', '1980-03-10', 'josue', '363b122c528f54df4a0446b6bab05515', 'Funcionário', 'josue@gmail.com', '133.224.890-00', 10);

-- --------------------------------------------------------

--
-- Estrutura da tabela `produto`
--

CREATE TABLE `produto` (
  `id` int(11) NOT NULL COMMENT 'Chave primária da tabela produto',
  `nome` varchar(255) NOT NULL COMMENT 'campo string para receber o nome do produto',
  `vlrCompra` decimal(18,2) NOT NULL COMMENT 'campo para receber o valor de compra do produto',
  `vlrVenda` decimal(18,2) NOT NULL COMMENT 'campo para receber o valor de venda do produto',
  `qtdEstoque` int(11) NOT NULL COMMENT 'campo referente ao total de produto em estoque',
  `imagem` varchar(255) NOT NULL,
  `fkFornecedor` int(11) NOT NULL COMMENT 'campo que referencia o fornecedor do produto.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `produto`
--

INSERT INTO `produto` (`id`, `nome`, `vlrCompra`, `vlrVenda`, `qtdEstoque`, `imagem`, `fkFornecedor`) VALUES
(14, 'erwe', '33.00', '44.00', 4, 'img/bule.jfif', 4),
(17, 'Novo', '33.00', '66.00', 4, 'img/adidas.jpg', 4),
(18, 'bola', '22.00', '44.00', 20, 'img/bola.png', 4),
(19, 'Tênis', '33.00', '55.00', 4, 'img/adidas.jpg', 4);

-- --------------------------------------------------------

--
-- Estrutura stand-in para vista `visao1`
-- (Veja abaixo para a view atual)
--
CREATE TABLE `visao1` (
`idpessoa` int(11)
,`nome` varchar(255)
,`dtNasc` date
,`login` varchar(65)
,`senha` varchar(64)
,`perfil` varchar(20)
,`email` varchar(255)
,`cpf` varchar(14)
,`fkendereco` int(11)
,`idendereco` int(11)
,`logradouro` varchar(255)
,`complemento` varchar(255)
,`bairro` varchar(255)
,`cidade` varchar(255)
,`uf` varchar(2)
,`cep` varchar(10)
);

-- --------------------------------------------------------

--
-- Estrutura para vista `visao1`
--
DROP TABLE IF EXISTS `visao1`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `visao1`  AS SELECT `pessoa`.`idpessoa` AS `idpessoa`, `pessoa`.`nome` AS `nome`, `pessoa`.`dtNasc` AS `dtNasc`, `pessoa`.`login` AS `login`, `pessoa`.`senha` AS `senha`, `pessoa`.`perfil` AS `perfil`, `pessoa`.`email` AS `email`, `pessoa`.`cpf` AS `cpf`, `pessoa`.`fkendereco` AS `fkendereco`, `endereco`.`idendereco` AS `idendereco`, `endereco`.`logradouro` AS `logradouro`, `endereco`.`complemento` AS `complemento`, `endereco`.`bairro` AS `bairro`, `endereco`.`cidade` AS `cidade`, `endereco`.`uf` AS `uf`, `endereco`.`cep` AS `cep` FROM (`pessoa` join `endereco` on((`pessoa`.`fkendereco` = `endereco`.`idendereco`))) ;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `endereco`
--
ALTER TABLE `endereco`
  ADD PRIMARY KEY (`idendereco`);

--
-- Índices para tabela `fornecedor`
--
ALTER TABLE `fornecedor`
  ADD PRIMARY KEY (`idfornecedor`),
  ADD KEY `fkendereco` (`fkendereco`);

--
-- Índices para tabela `pessoa`
--
ALTER TABLE `pessoa`
  ADD PRIMARY KEY (`idpessoa`),
  ADD UNIQUE KEY `cpf_UNIQUE` (`cpf`),
  ADD KEY `fkendereco` (`fkendereco`);

--
-- Índices para tabela `produto`
--
ALTER TABLE `produto`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fkFornecedor` (`fkFornecedor`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `endereco`
--
ALTER TABLE `endereco`
  MODIFY `idendereco` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `fornecedor`
--
ALTER TABLE `fornecedor`
  MODIFY `idfornecedor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `pessoa`
--
ALTER TABLE `pessoa`
  MODIFY `idpessoa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `produto`
--
ALTER TABLE `produto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Chave primária da tabela produto', AUTO_INCREMENT=20;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `fornecedor`
--
ALTER TABLE `fornecedor`
  ADD CONSTRAINT `fornecedor_ibfk_1` FOREIGN KEY (`fkendereco`) REFERENCES `endereco` (`idendereco`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `pessoa`
--
ALTER TABLE `pessoa`
  ADD CONSTRAINT `pessoa_ibfk_1` FOREIGN KEY (`fkendereco`) REFERENCES `endereco` (`idendereco`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `produto`
--
ALTER TABLE `produto`
  ADD CONSTRAINT `produto_ibfk_1` FOREIGN KEY (`fkFornecedor`) REFERENCES `fornecedor` (`idfornecedor`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
