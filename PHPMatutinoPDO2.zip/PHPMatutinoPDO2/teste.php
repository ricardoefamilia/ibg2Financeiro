<?php
session_start();
$_SESSION['aluno'] = "Walisson";
echo $_SESSION['aluno'];
