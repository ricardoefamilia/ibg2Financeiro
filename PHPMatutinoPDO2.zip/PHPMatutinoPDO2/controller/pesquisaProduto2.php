<?php
session_start();
$pesquisa = $_POST['pesquisa'];
$_SESSION['p'] = $pesquisa;
header("Location: ../ListaProdutos.php");
exit();
