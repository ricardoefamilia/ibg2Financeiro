<?php
ob_start();
if (!isset($_SESSION)) {
    session_start();
}
if((!isset($_SESSION['loginp']) || !isset($_SESSION['nomep'])) ||
        !isset($_SESSION['perfilp']) || !isset($_SESSION['nr']) ||
        ($_SESSION['nr'] != $_SESSION['confereNr'])) { 
    // Usuário não logado! Redireciona para a página de login 
    header("Location: sessionDestroy.php");
    exit;
}
include_once 'controller/ProdutoController.php';
include_once './model/Produto.php';
include_once './model/Fornecedor.php';
include_once './model/Mensagem.php';
include_once 'controller/FornecedorController.php';
if(!isset($_SESSION['p'])){
    $_SESSION['p'] = "";
}
$fcc = new FornecedorController();
$msg = new Mensagem();
$pr = new Produto();
$fornecedor = new Fornecedor();
$prPesquisa = new Produto();
$pr->setFornecedor($fornecedor);
$btEnviar = FALSE;
$btAtualizar = FALSE;
$btExcluir = FALSE;
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Cadastro</title>
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <style>
            .btInput{
                margin-top: 20px;
            }
            .pad15{
                padding-bottom: 15px; padding-top: 15px;
            }
        </style>
    </head>
    <body onload="manter();">
        <?php
            include_once './nav.php';
            echo navBar();
        ?>

        <div class="container-fluid">
            <div class="row" style="margin-top: 30px;">   
            <div class="col-md-12">
                <div class="row"> 
                    <div class="col-md-12">
                        <div class="row mb-1">
                            <form method="post" action="./controller/pesquisaProduto2.php" >
                                <input type="text" id="pesquisa" class="form-group"
                                size="30" name="pesquisa">
                                <input type="submit" class="form-group" value="Pesquisar">
                            </form>
                        </div>
                        <table class="table table-striped table-responsive"
                               style="border-radius: 3px; overflow:hidden;">
                            <thead class="table-dark">
                                <tr><th>Código</th>
                                    <th>Produto</th>
                                    <th>Imagem</th>
                                    <th>Compra (R$)</th>
                                    <th>Venda (R$)</th>
                                    <th>Estoque</th>
                                    <th>Fornecedor</th>
                                    <th>Representante</th>
                                    <th colspan="2" style="text-align:center;">Ações</th></tr>
                            </thead>
                            <tbody>
                                <?php
                                 if (isset($_SESSION['p']) && $_SESSION['p'] != "") {
                                    $pesquisa = $_SESSION['p'];
                                    $pc = new ProdutoController();
                                    $listaProdutos = $pc->listarProdutosPesquisa($pesquisa);
                                }else{
                                    $pcTable = new ProdutoController();
                                    $listaProdutos = $pcTable->listarProdutos();
                                }
                                $a = 0;
                                if ($listaProdutos != null) {
                                    foreach ($listaProdutos as $lp) {
                                        $a++;
                                        ?>
                                        <tr>
                                            <td><?php print_r($lp->getIdProduto()); ?></td>
                                            <td><?php print_r($lp->getNomeProduto()); ?></td>
                                            <td><img src="<?php print_r($lp->getImagem()); ?>" 
                                                     width="48"></td>
                                            <td><?php print_r($lp->getVlrCompra()); ?></td>
                                            <td><?php print_r($lp->getVlrVenda()); ?></td>
                                            <td><?php print_r($lp->getQtdEstoque()); ?></td>
                                            <td><?php print_r($lp->getFornecedor()->getNomefornecedor()); ?></td>
                                            <td><?php print_r($lp->getFornecedor()->getRepresentante()); ?></td>
                                            <td><a href="cadastroProduto.php?id=<?php echo $lp->getIdProduto(); ?>"
                                                   class="btn btn-light">
                                                    <img src="img/edita.png" width="24"></a></td>
                                                </form>
                                                <td><button type="button" 
                                                        class="btn btn-light" data-bs-toggle="modal" 
                                                        data-bs-target="#exampleModal<?php echo $a; ?>">
                                                    <img src="img/delete.png" width="24"></button></td>
                                        </tr>
                                        <!-- Modal -->
                                    <div class="modal fade" id="exampleModal<?php echo $a; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                                    <button type="button" class="btn-close" 
                                                            data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <form method="post" action="">
                                                        <label><strong>Deseja excluir o produto 
                                                                <?php echo $lp->getNomeProduto(); ?>?</strong></label>
                                                        <input type="hidden" name="ide" 
                                                               value="<?php echo $lp->getIdProduto(); ?>">
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="submit" name="excluir" class="btn btn-primary">Sim</button>
                                                            <button type="reset" class="btn btn-secondary" 
                                                                    data-bs-dismiss="modal">Não</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                }
                                ?>
                                </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>     
    </div>


    <script src="js/bootstrap.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
        var myModal = document.getElementById('myModal')
        var myInput = document.getElementById('myInput')

        myModal.addEventListener('shown.bs.modal', function () {
            myInput.focus()
        })
    </script> 
    <script>
        function manter(){
             var p = "<?php echo $_SESSION['p'] ; ?>";
            document.getElementById("pesquisa").value=p;
        }
    </script>
</body>
</html>
<?php ob_end_flush();?>
