<?php

require_once 'top.php';
require_once 'sql/banco-destinacao.php';

   $id = $_GET['id'];
   $destinacao = buscaDestinacaoPorID($con, $id);
?>

<section class="container">

   <div class="col-sm-5">
      <div class="page-header">
         <h3>Alterar Destinação</</h3>
      </div>
      <form method="post" action="altera-destinacao.php">
         <div class="row">
            <div class="col-xs-8">
               <div class="form-group">
                  <label for="descricao">Nome da destinação</label>
                  <input type="hidden" name="id" value="<?=$destinacao['iddestinacao']?>">
                  <input type="text" name="descricao" id="descricao" value="<?=$destinacao['descricao']?>" class="form-control">
               </div>
            </div>
         </div>
         <button type="submit" class="btn btn-info">
            <span class="fa fa-check"></span>
            Alterar
         </button>
      </form>
   </div>

</section>

<?php require_once 'footer.php'; ?>
