<?php

   require_once 'sql/conexao.php';
   require_once 'sql/banco-membros.php';
   require_once 'mostra-alerta.php';
   error_reporting(E_ALL);
   ini_set("display_errors", 1);



    $resultados = InserirMembroFamiliares($con,$_POST,$idMembro)

	if ( $resultados ) {
      $_SESSION['success'] = 'Cadastro efetuado com sucesso';
       //header('Location: lista-membros.php');

	  } else {
       echo mysqli_error($con);
    }

//   die();
