<?php

   require_once 'sql/banco-destinacao.php';
   require_once 'mostra-alerta.php';

   if (alteraDestinacao($con, $_POST['descricao'], $_POST['id'])) {
       $_SESSION['success'] = 'Destinação alterada com sucesso';
       header('Location: form-destinacao.php');
   } else {
       echo mysqli_error($con);
   }

   die();
