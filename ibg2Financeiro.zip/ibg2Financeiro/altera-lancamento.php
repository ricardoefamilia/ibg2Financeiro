<?php

   require_once 'sql/banco-entradas.php';
   require_once 'mostra-alerta.php';
   
   //var_dump($_POST) or die;
   
if (isset($_POST['checkbox'])) {
       
       if (alteraEntradas($con, $_POST)) {
            $_SESSION['success'] = '<span class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span> Lançamento confirmado com sucesso';
            header('Location: form-entradas-listar.php');
        } else {
        echo mysqli_error($con);
        }

        
}else{
       $_SESSION['danger'] = '<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> Nenhum lançamento selecionado';
       header('Location: form-entradas-listar.php');
   }
 
   die();
   
