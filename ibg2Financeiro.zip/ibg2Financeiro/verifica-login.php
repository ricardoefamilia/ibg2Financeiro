<?php
    session_start();

   require_once 'sql/conexao.php';
   require_once 'sql/banco-usuario.php';

   $usuario = buscaUsuario($con, $_POST['nome'], $_POST['senha']);

   if ($usuario === null) {
       $_SESSION["danger"] = "Usuário ou senha inválida";
       header("Location: index.php");
   } else {
      
       header("Location: home.php");
   }

	die();
