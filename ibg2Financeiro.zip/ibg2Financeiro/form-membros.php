<?php
   require_once 'top.php';
   require_once 'mostra-alerta.php';
   require_once 'sql/banco-dom.php';

   $dons = listaDons($con);
?>

   <?php mostraAlerta('danger'); ?>


   <section class="container">
      <h2 class="page-header">Cadastro de Membros e Congregados</h2>

      <ul class="nav nav-tabs">
         <li class="active"><a data-toggle="tab" href="#dados-pessoais">Dados pessoais</a></li>
         <li><a data-toggle="tab" href="#enderecoTab">Endereço</a></li>
         <li><a data-toggle="tab" href="#filiacao">Filiação</a></li>
         <li><a data-toggle="tab" href="#trabalho">Trabalho</a></li>
         <li><a data-toggle="tab" href="#igreja">Igreja</a></li>
         <li><a data-toggle="tab" href="#dons">Dons</a></li>
         <li><a data-toggle="tab" href="#ibg2">IBG2</a></li>
      </ul>

      <form action="1.php" method="post" id="form-membros">
      <div class="tab-content">

         <div id="dados-pessoais" class="tab-pane fade in active">
            <div class="panel-body">

               <div class="row">

                     <div class="col-sm-12">
                        <div class="form-group">
                           <label for="tipo-pessoa">
                              Tipo de pessoa
                              <span class="red-color fa fa-asterisk"></span>
                           </label>
                           <div class="radio">
                              <label for="">
                                 <input type="radio" name="tipoPessoa" value="1" checked>Membro
                              </label>
                              <label for="">
                                 <input type="radio" name="tipoPessoa" value="0">Congregado
                              </label>
                           </div>
                        </div>
                     </div>

                     <div class="col-sm-5">
                        <div class="form-group">
                           <label for="nome">
                              Nome
                              <span class="red-color fa fa-asterisk"></span>
                           </label>
                           <input type="text" name="nome" id="nome" class="form-control" >
                        </div>
                     </div>

                     <div class="col-md-4">
                        <div class="form-group">
                           <label for="">E-mail</label>
                           <input type="text" name="emailPessoal" class="form-control">
                        </div>
                     </div>

                     <div class="col-sm-3">
                        <label for="sexo">
                           Sexo
                           <span class="red-color fa fa-asterisk"></span>
                        </label>
                        <div class="radio">
                           <label for="">
                              <input type="radio" name="sexo" value="1" checked>Masculino
                           </label>
                           <label for="">
                              <input type="radio" name="sexo" value="0">Feminino
                           </label>
                        </div>
                     </div>
               </div>

               <div class="row">

                 <div class="col-sm-5">
                    <div class="form-group">
                       <label for="orgaoExpedidor">
                          Órgão expedidor
                          <span class="red-color fa fa-asterisk"></span>
                       </label>
                        <input type="text" name="orgaoExpedidor" id="rg" class="form-control" >
                    </div>
                 </div>

                  <div class="col-sm-3">
                     <div class="form-group">
                        <label for="rg">
                           Nº da identidade
                           <span class="red-color fa fa-asterisk"></span>
                        </label>
                        <input type="text" name="rg" id="rg" class="form-control" >
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="">
                           CPF
                           <span class="red-color fa fa-asterisk"></span>
                        </label>
                        <input type="text" name="cpf" id="cpf" class="form-control" >
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="dataNascimento">
                            Data de Nascimento
                            <span class="red-color fa fa-asterisk"></span>
                         </label>
                         <input type="input" name="nascimento" id="nascimento" class="form-control datepicker" >
                     </div>
                  </div>
               </div>
                
               <div class="row">
                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="">
                              Nascimento - UF
                              <span class="red-color fa fa-asterisk"></span>
                           </label>
                         <select name="nascimentoEstado" id="nascimentoEstado" class="form-control" >
                             <option value="">-- Selecione --</option>
                             <option value="AC">Acre</option>
                             <option value="AL">Alagoas</option>
                             <option value="AP">Amapá</option>
                             <option value="AM">Amazonas</option>
                             <option value="BA">Bahia</option>
                             <option value="CE">Ceará</option>
                             <option value="DF">Distrito Federal</option>
                             <option value="ES">Espírito Santo</option>
                             <option value="GO">Goiás</option>
                             <option value="MA">Maranhão</option>
                             <option value="MT">Mato Grosso</option>
                             <option value="MS">Mato Grosso do Sul</option>
                             <option value="MG">Minas Gerais</option>
                             <option value="PA">Pará</option>
                             <option value="PB">Paraíba</option>
                             <option value="PR">Paraná</option>
                             <option value="PE">Pernambuco</option>
                             <option value="PI">Piauí</option>
                             <option value="RJ">Rio de Janeiro</option>
                             <option value="RN">Rio Grande do Norte</option>
                             <option value="RS">Rio Grande do Sul</option>
                             <option value="RO">Rondônia</option>
                             <option value="RR">Roraima</option>
                             <option value="SC">Santa Catarina</option>
                             <option value="SP">São Paulo</option>
                             <option value="SE">Sergipe</option>
                             <option value="TO">Tocantins</option>
                         </select>
                     </div>
                  </div>

                  <div class="col-sm-3">
                     <div class="form-group">
                        <label for="">
                              Nascimento - Cidade
                              <span class="red-color fa fa-asterisk"></span>
                           </label>
                        <input type="text" name="nascimentoCidade" id="cidade-nascimento" class="form-control" >
                     </div>
                  </div>

                  <div class="col-sm-3">
                     <div class="form-group">
                        <label for="">
                              Estado Civil
                              <span class="red-color fa fa-asterisk"></span>
                           </label>
                        <select class="form-control" name="estadoCivil" id="estado-civil" >
                              <!-- <option value="">Selecione...</option> -->
                              <option>Solteiro(a)</option>
                              <option>Casado(a)</option>
                              <option>Divorciado(a)</option>
                              <option>Separado(a)</option>
                              <option>Viúvo(a)</option>
                           </select>
                     </div>
                  </div>


                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="">
                              Tipo sanguineo
                              <span class="red-color fa fa-asterisk"></span>
                           </label>
                        <select class="form-control" name="tipoSanguineo" id="tipo-sanguineo" >
                             <!-- <option value="">Selecione...</option> -->
                                <option>O</option>
                                <option>A</option>
                                <option>B</option>
                                <option>AB</option>
                          </select>
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="">Fator RH</label>
                        <select class="form-control" name="fatorRh" >
                             <!-- <option value="">Selecione...</option> -->
                                <option value="+">+</option>
                                <option value="-">-</option>
                          </select>
                     </div>
                  </div>

               </div>

               <div class="row">
                  <div class="col-sm-4">
                     <div class="form-group">
                        <label>
                              Grau de instrução
                              <span class="red-color fa fa-asterisk"></span>
                           </label>

                        <select class="form-control" name="escolaridade" id="escolaridade" >
                             <!-- <option value="">Selecione...</option> -->
                             <optgroup label="Ensino Fundamental">
                               <option>Ensino Fundamental incompleto</option>
                               <option>Ensino Fundamental cursando</option>
                               <option>Ensino Fundamental completo</option>
                             </optgroup>

                             <optgroup label="Ensino Médio">
                               <option>Ensino Médio incompleto</option>
                               <option>Ensino Médio cursando</option>
                               <option>Ensino Médio completo</option>
                             </optgroup>

                             <optgroup label="Ensino Superior">
                               <option>Ensino Superior incompleto</option>
                               <option>Ensino Superior cursando</option>
                               <option>Ensino Superior completo</option>
                             </optgroup>
                          </select>
                     </div>
                  </div>

               </div>
            </div>
         </div>
         <!-- fim dados pessoais -->

         <div id="enderecoTab" class="tab-pane fade">
            <div class="panel-body">

               <div class="row">
                  <div class="col-md-2">
                     <div class="form-group">
                        <label for="cep">
                           CEP
                           <span class="red-color fa fa-asterisk"></span>
                        </label>
                        <input type="text" id="cep" name="cep" class="form-control" onblur="pesquisacep(this.value);"  >
                     </div>
                  </div>

                  <div class="col-md-4">
                     <div class="form-group">
                        <label for="endereco">
                           Endereço
                           <span class="red-color fa fa-asterisk"></span>
                        </label>
                        <input type="text" id="endereco" name="endereco" class="form-control">
                     </div>
                  </div>
                   
                  <div class="col-md-2">
                     <div class="form-group">
                        <label for="">
                          Bairro
                          <span class="red-color fa fa-asterisk"></span>
                        </label>
                        <input type="text" id="bairro" name="bairro" class="form-control">
                     </div>
                  </div>
                   
                  <div class="col-md-3">
                     <div class="form-group">
                        <label for="">
                           Cidade
                           <span class="red-color fa fa-asterisk"></span>
                           </label>
                        <input type="text" id="cidade" name="cidade" class="form-control">
                     </div>
                  </div>

                  <div class="col-md-1">
                     <div class="form-group">
                        <label for="">
                           UF
                           <span class="red-color fa fa-asterisk"></span>
                           </label>
                         <select name="estado" id="estado" class="form-control">
                            
                             <option value="AC">AC</option>
                             <option value="AL">AL</option>
                             <option value="AP">AP</option>
                             <option value="AM">AM</option>
                             <option value="BA">BA</option>
                             <option value="CE">CE</option>
                             <option value="DF" selected>DF</option>
                             <option value="ES">ES</option>
                             <option value="GO">GO</option>
                             <option value="MA">MA</option>
                             <option value="MT">MT</option>
                             <option value="MS">MS</option>
                             <option value="MG">MG</option>
                             <option value="PA">PA</option>
                             <option value="PB">PB</option>
                             <option value="PR">PR</option>
                             <option value="PE">PE</option>
                             <option value="PI">PI</option>
                             <option value="RJ">RJ</option>
                             <option value="RN">RN</option>
                             <option value="RS">RS</option>
                             <option value="RO">RO</option>
                             <option value="RR">RR</option>
                             <option value="SC">SC</option>
                             <option value="SP">SP</option>
                             <option value="SE">SE</option>
                             <option value="TO">TO</option>
                        </select>
                     </div>
                  </div>

               </div>

               <div class="row">
                   <div class="col-md-2">
                      <div class="form-group">
                         <label for="">
                           Número
                           <span class="red-color fa fa-asterisk"></span>
                         </label>
                         <input type="text" name="numero" class="form-control">
                      </div>
                   </div>

                   <div class="col-md-4">
                      <div class="form-group">
                         <label for="">
                           Complemento
                           <span class="red-color fa fa-asterisk"></span>
                         </label>
                         <input type="text" name="complemento" class="form-control">
                      </div>
                   </div>

                   <div class="col-md-3">
                     <div class="form-group">
                       <label for="">Telefone</label>
                       <input type="text" id="telefone" name="telefone" class="form-control">
                     </div>
                   </div>

                   <div class="col-md-3">
                     <div class="form-group">
                       <label for="">Celular</label>
                       <input type="text" id="celular" name="celular" class="form-control">
                     </div>
                   </div>
               </div>

            </div>
         </div>
         <!-- fim endereço -->

         <div id="filiacao" class="tab-pane fade">
            <div class="panel-body">
               <div class="row">
                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="nomePai">Nome do pai</label>
                        <input type="text" name="nomePai" class="form-control">
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="paiEvangelico">É evangélico?</label>
                        <div class="radio">
                           <label for="">
                              <input type="radio" name="paiEvangelico" value="1" checked> Sim
                           </label>
                           <label for="">
                              <input type="radio" name="paiEvangelico" value="0"> Não
                           </label>
                        </div>
                     </div>
                  </div>

                  <div class="col-sm-6">
                     <div class="form-group">
                        <label for="nomePai">Nome da igreja</label>
                        <input type="text" name="igrejaPai" class="form-control">
                     </div>
                  </div>

               </div>

               <div class="row">

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="nomePai">Nome da mãe</label>
                        <input type="text" name="nomeMae" class="form-control">
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="paiEvangelico">É evangélica?</label>
                        <div class="radio">
                           <label for="">
                              <input type="radio" name="maeEvangelica" value="1" checked> Sim
                           </label>
                           <label for="">
                              <input type="radio" name="maeEvangelica" value="0"> Não
                           </label>
                        </div>
                     </div>
                  </div>

                  <div class="col-sm-6">
                     <div class="form-group">
                        <label for="nomePai">Nome da igreja</label>
                        <input type="text" name="igrejaMae" class="form-control">
                     </div>
                  </div>

               </div>

               <h3 class="page-header">Conjugê</h3>
               <div class="row">

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Nome</label>
                        <input type="text" name="nomeConjuge" class="form-control">
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="paiEvangelico">É evangélico(a)?</label>
                        <div class="radio">
                           <label for="">
                                 <input type="radio" name="conjugeEvangelico" value="1" checked> Sim
                              </label>
                           <label for="">
                                 <input type="radio" name="conjugeEvangelico" value="0"> Não
                              </label>
                        </div>
                     </div>
                  </div>

                  <div class="col-sm-6">
                     <div class="form-group">
                        <label for="nomePai">Nome da igreja</label>
                        <input type="text" name="igrejaConjuge" class="form-control">
                     </div>
                  </div>

               </div>

               <div class="row">

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Data de nascimento</label>
                        <input type="input" name="dataNascimentoConjuge" class="form-control datepicker">
                     </div>
                  </div>

                  <div class="col-sm-4 col-sm-offset-2">
                     <div class="form-group">
                        <label for="">Data de casamento</label>
                        <input type="input" name="dataCasamento" class="form-control datepicker">
                     </div>
                  </div>

               </div>
            </div>
         </div>
          
          <!-- Fim dados de FILIAÇÃO -->
          
         <div id="trabalho" class="tab-pane fade">
            <div class="panel-body">
               <div class="row">

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Nome</label>
                        <input type="text" name="empresaNome" class="form-control">
                     </div>
                  </div>

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Cargo</label>
                        <input type="text" name="empresaCargo" class="form-control">
                     </div>
                  </div>

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Profissão</label>
                        <input type="text" name="profissao" class="form-control">
                     </div>
                  </div>

               </div>

               <div class="row">


                  <div class="col-sm-2">
                    <div class="form-group">
                      <label for="">Cep</label>
                      <input type="text" name="empresaCep" id="empresaCep" class="form-control"  onblur="pesquisacep2(this.value);" >
                    </div>
                  </div>

                   <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Endereço</label>
                        <input type="text" name="empresaEndereco" id="empresaEndereco" class="form-control" >
                     </div>
                  </div>
                   
                   <div class="col-sm-2">
                   <div class="form-group">
                     <label for="">Bairro</label>
                     <input type="text" name="empresaBairro" id="empresaBairro" class="form-control" >
                   </div>
                 </div>
                   
                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Cidade</label>
                        <input type="text" name="empresaCidade" id="empresaCidade" class="form-control" >
                     </div>
                  </div>
               </div>

                <div class="col-sm-2">
                    <div class="form-group">
                        <label for=""> UF</label>
                        <select name="empresaEstado" id="empresaEstado" class="form-control" >
                            <option value="AC">AC</option>
                             <option value="AL">AL</option>
                             <option value="AP">AP</option>
                             <option value="AM">AM</option>
                             <option value="BA">BA</option>
                             <option value="CE">CE</option>
                             <option value="DF" selected>DF</option>
                             <option value="ES">ES</option>
                             <option value="GO">GO</option>
                             <option value="MA">MA</option>
                             <option value="MT">MT</option>
                             <option value="MS">MS</option>
                             <option value="MG">MG</option>
                             <option value="PA">PA</option>
                             <option value="PB">PB</option>
                             <option value="PR">PR</option>
                             <option value="PE">PE</option>
                             <option value="PI">PI</option>
                             <option value="RJ">RJ</option>
                             <option value="RN">RN</option>
                             <option value="RS">RS</option>
                             <option value="RO">RO</option>
                             <option value="RR">RR</option>
                             <option value="SC">SC</option>
                             <option value="SP">SP</option>
                             <option value="SE">SE</option>
                             <option value="TO">TO</option>
                        </select>
                    </div>
              </div>
                
               <div class="row">
                   
                 <div class="col-sm-2">
                    <div class="form-group">
                       <label for="">Número</label>
                       <input type="text" name="empresaNumero" class="form-control">
                    </div>
                 </div>

                 <div class="col-sm-4">
                    <div class="form-group">
                       <label for="">Complemento</label>
                       <input type="text" name="empresaComplemento" class="form-control">
                    </div>
                 </div>
               </div>
            </div>
         </div>

          <!-- fim dos dados de TRABALHO -->
          
          <div id="igreja" class="tab-pane fade">
            <div class="panel-body">
               <div class="row">
                   
                 <legend>Batismo</legend>
                   
                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Igreja onde foi batizado</label>
                        <input type="text" name="igrejaBatismoNomeIgreja" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Data de batismo</label>
                        <input type="text" name="igrejaBatismoDataBatismo" class="form-control datepicker">
                     </div>
                  </div>

               </div>
                <br><br>
               <div class="row">

                 <legend>Igreja de origem</legend>

                 <div class="col-sm-4">
                    <div class="form-group">
                       <label for="">Nome</label>
                       <input type="text" name="igrejaOrigemNome" class="form-control">
                    </div>
                 </div>
                   
                <div class="col-sm-2">
                     <div class="form-group">
                        <label for="">Cep</label>
                        <input type="text" name="igrejaOrigemCep" id="igrejaOrigemCep" class="form-control"  onblur="pesquisacep3(this.value);" >
                     </div>
                  </div>

                 <div class="col-sm-4">
                     <div class="form-group">
                         <label for="">Endereço</label>
                         <input type="text" name="igrejaOrigemEndereco" id="igrejaOrigemEndereco" class="form-control" >
                     </div>
                 </div>
                   
                <div class="col-sm-2">
                     <div class="form-group">
                         <label for="">Bairro</label>
                         <input type="text" name="igrejaOrigemBairro" id="igrejaOrigemBairro"  class="form-control" >
                     </div>
                 </div>
                   
                 <div class="col-sm-4">
                     <div class="form-group">
                         <label for="">Cidade</label>
                         <input type="text" name="igrejaOrigemCidade" id="igrejaOrigemCidade" class="form-control" >
                     </div>
                 </div>
                                    
                 <div class="col-sm-2">
                    <div class="form-group">
                       <label for="">UF</label>
                       <select name="igrejaOrigemEstado" id="igrejaOrigemEstado" class="form-control">
                            <option value="AC">AC</option>
                             <option value="AL">AL</option>
                             <option value="AP">AP</option>
                             <option value="AM">AM</option>
                             <option value="BA">BA</option>
                             <option value="CE">CE</option>
                             <option value="DF" selected>DF</option>
                             <option value="ES">ES</option>
                             <option value="GO">GO</option>
                             <option value="MA">MA</option>
                             <option value="MT">MT</option>
                             <option value="MS">MS</option>
                             <option value="MG">MG</option>
                             <option value="PA">PA</option>
                             <option value="PB">PB</option>
                             <option value="PR">PR</option>
                             <option value="PE">PE</option>
                             <option value="PI">PI</option>
                             <option value="RJ">RJ</option>
                             <option value="RN">RN</option>
                             <option value="RS">RS</option>
                             <option value="RO">RO</option>
                             <option value="RR">RR</option>
                             <option value="SC">SC</option>
                             <option value="SP">SP</option>
                             <option value="SE">SE</option>
                             <option value="TO">TO</option>
                       </select>
                    </div>
                 </div>
                 
                 <div class="col-sm-2">
                     <div class="form-group">
                         <label for="">Número</label>
                         <input type="text" name="igrejaOrigemNumero" class="form-control">
                     </div>
                 </div>

                 <div class="col-sm-4">
                    <div class="form-group">
                       <label for="">Complemento</label>
                       <input type="text" name="igrejaOrigemComplemento" class="form-control">
                    </div>
                 </div>

             </div>

               <div class="row">

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Telefone</label>
                        <input type="text" id="igrejaOigemTelefone" name="igrejaOigemTelefone" class="form-control">
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="">Dizimista</label>
                        <select class="form-control" name="igrejaOrigemDizimista">
                            <!-- <option value="">Selecione...</option> -->
                            <option value="1">Sim</option>
                            <option value="0">Não</option>
                        </select>
                     </div>
                  </div>

                  <div class="col-sm-12">
                     <div class="form-group">
                        <label for="">Atividades desenvolvidas em outras igrejas</label>
                        <textarea class="form-control" name="igrejaOrigemAtividades"></textarea>
                     </div>
                  </div>
               </div>

            </div>
         </div>
          
          <!-- fim dos dados de IGREJA -->

         <div id="dons" class="tab-pane fade">
            <div class="panel-body">

               <div class="row">

                  <div class="col-sm-12">
                     <div class="form-group">
                        <label for="paiEvangelico">Compromete-se a entregar os seus dízimos neste Igreja?</label>
                        <label class="radio-inline">
                              <input type="radio" name="dizimistaFiel" value="1" checked>Sim
                           </label>
                        <label class="radio-inline">
                              <input type="radio" name="dizimistaFiel" value="0">Não
                           </label>
                     </div>
                  </div>

               </div>

               <div class="row">

                  <div class="col-sm-12">
                     <div class="form-group">
                        <label for="paiEvangelico">Conhece os ensinos bíblicos sobre os dons espirituais?</label>
                        <label class="radio-inline">
                              <input type="radio" name="donsConhece" value="1" checked>Sim
                           </label>
                        <label class="radio-inline">
                              <input type="radio" name="donsConhece" value="0">Não
                           </label>
                     </div>
                  </div>

               </div>


               <div class="row">

                  <div class="col-md-12">

                     <p>Conhece seus dons?</p>
                     <p>Se os conhece, assinale-os:</p>

                     <div class="form-group">
                        <select id="dom" multiple="multiple" name="seleciona-dons[]">

                            <?php foreach ($dons as $dom): ?>
                                <option value="<?=$dom['idDom']?>">
                                    <?=$dom['nomeDom']?>
                                </option>
                            <?php endforeach ?>

                        </select>
                     </div>

                     <div class="form-group">
                        <label for="paiEvangelico">Tem-no(s) praticado?</label>
                        <label class="radio-inline">
                              <input type="radio" name="donsPratica" value="1" checked>Sim
                           </label>
                        <label class="radio-inline">
                              <input type="radio" name="donsPratica" value="0">Não
                           </label>
                     </div>
                  </div>

               </div>
            </div>
         </div>
          
          <!-- fim dos DONS -->
          
         <div id="ibg2" class="tab-pane fade">
            <div class="panel-body">
               <h3 class="page-header">Entrada</h3>

               <div class="row">
                  <div class="col-md-8">

                     <div class="form-group">
                        <span class="red-color fa fa-asterisk"></span>
                        <label for="">Admissão na IBG2 - Modo: </label>

                        <label class="radio-inline">
                              <input type="radio" name="modoAdmissao" value="Batismo" checked>Batismo
                        </label>

                        <label class="radio-inline">
                              <input type="radio" name="modoAdmissao" value="Carta">Carta
                        </label>

                        <label class="radio-inline">
                              <input type="radio" name="modoAdmissao" value="Aclamação">Aclamação
                        </label>
                         
                         <label class="radio-inline">
                              <input type="radio" name="modoAdmissao" value="Reconciliação">Reconciliação
                        </label>

                     </div>

                     <div class="form-group form-inline">
                        <span class="red-color fa fa-asterisk"></span>
                        <label for="">Data da Sessão </label>
                        <input type="text" name="dataEntrada" class="form-control datepicker" >
                     </div>
                  </div>

                  <div class="col-sm-12">
                     <div class="form-group">
                        <span class="red-color fa fa-asterisk"></span>
                        <label for="">Atividades desenvolvidas na IBG2</label>
                        <textarea class="form-control" name="atividades" ></textarea>
                     </div>
                  </div>


               </div>

               <!-- <h3 class="page-header">Saída</h3>
               <div class="row">
                  <div class="col-md-6">

                     <div class="form-group">
                        <label for="">Saída na IBG2 - Modo: </label>

                        <label class="radio-inline">
                            <input type="radio" name="saidaModo" value="Carta">Carta
                        </label>

                        <label class="radio-inline">
                              <input type="radio" name="saidaModo" value="Desligamento">Desligamento
                        </label>

                        <label class="radio-inline">
                              <input type="radio" name="saidaModo" value="Falecimento">Falecimento
                        </label>

                        <div class="radio">
                           <label for="">
                             <input type="radio">Outro
                            </label>
                           <input type="text" name="saidaModo" class="form-control">
                        </div>
                     </div>

                     <div class="form-group form-inline">
                        <label for="">Data da Sessão </label>
                        <input type="date" name="saidaDate" class="form-control datepicker">
                     </div>
                  </div>

                  <div class="col-sm-12">
                     <div class="form-group">
                        <label for="">Observação</label>
                        <textarea class="form-control" name=""></textarea>
                     </div>
                  </div>
               </div>


               <h3 class="page-header">Readmissão</h3>
               <div class="row">
                  <div class="col-md-6">

                     <div class="form-group">
                        <label for="">Readmissão - Modo: </label>
                        <input type="text" name="readmissaoModo" class="form-control">

                     </div>
                  </div>

                  <div class="col-md-3">
                     <label for="">Data da Sessão </label>
                     <input type="date" name="readmissaoData" class="form-control datepicker">
                  </div>
               </div>
            </div>
         </div> -->

      </div>
      <button type="submit" class="btn btn-success">Salvar</button>
     </div>
     </div>
     </form>
</section>
   <!-- fim container -->

<?php require_once 'footer.php' ?>
<!-- <script src="js/jquery.validate.js"></script>
<script src="js/require.js"></script>
<script src="js/valida-campos.js"></script> -->
<script>
   $(document).ready(function() {
      $('#dom').multiselect();

      $('.datepicker').datepicker({
          format: 'dd/mm/yyyy',
          language: 'pt-BR',
          todayHighlight: true
      });

   });

</script>
<script>
jQuery(function($){
   $("#igrejaOigemTelefone").mask("(99) 9999-9999");
   $("#telefone").mask("(99) 9999-9999");
   $("#celular").mask("(99) 9 9999-9999");
   $("#cpf").mask("999.999.999-99");   
});

</script>

