<?php
require_once 'sql/conexao.php';
require_once 'sql/banco-saida.php';
require_once 'mostra-alerta.php';

//echo '<pre>';
//var_dump($_SESSION['cart']) or die;

foreach ($_SESSION['cart-saida'] as $key => $value) :
   if (adicionaSaida($con, $value)) {
       $_SESSION['success'] = 'Saidas cadastradas com sucesso';
       header('Location: form-saida.php');
   } else {
       echo mysqli_error($con) . "<br>";
   }
endforeach;
unset($_SESSION['cart-saida']);
die();
