<?php include("sql/conexao.php");
require_once 'mostra-alerta.php';


if (isset($_GET['logout']) || empty($_SESSION['perfil'])) {

    session_destroy();
    
       header('Location: index.php');
    die;
}

?>

<!DOCTYPE>
<html>
<head>
   <title>Sistema de Coletas</title>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <link rel="stylesheet" href="css/dataTables.bootstrap.css">
   <link rel="stylesheet" href="css/bootstrap-datepicker.css">
   <link rel="stylesheet" href="css/bootstrap-multiselect.css">
   
   <link rel="stylesheet" href="css/fonts-awesome.min.css">
   <link rel="stylesheet" href="css/select2.min.css">
   <link rel="stylesheet" href="css/checkbox.css">
   <link rel="stylesheet" href="css/master.css">
   <link rel="stylesheet" href="css/style.css.css">
   <link rel="stylesheet" href="css/prism.css">
   <link type="text/css" href="css/chosen.css" rel="stylesheet" >
   
   <style type="text/css">

    body { padding-top:20px; }
   
</style>
  
</head>

<body>

    <header>
        <div class="container">
            <nav class="navbar navbar-default" >
                <div class="container-fluid"> 
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>

                        <a class="navbar-brand" href="home.php">Finanças IBG2</a>
                        
                    </div>
                    <div id="navbar" class="collapse navbar-collapse">
                        <ul class="nav navbar-nav">

                            <li class="active">
                                <a href="home.php">
                                    <span class="glyphicon glyphicon-home"></span> Home
                                </a>
                            </li>
                            
                            
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <span class="glyphicon glyphicon-calendar"></span> Relátorios <b class="caret"></b>
                                </a>

                                <ul class="dropdown-menu">
                                    
                                    <li><a href="#"><span class="fa fa-calculator"></span> Relátorios de lançamentos</a></li>
                                    <li class="divider"></li>
                                    <li><a href="#"><span class="fa fa-hand-o-down"></span> Relátorios de saidas</a></li>
                                    
                                </ul>
                            </li>
                            
                         
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <span class="fa fa-plus-circle"></span> Cadastros <b class="caret"></b>
                                </a>

                                <ul class="dropdown-menu">
                                    <li><a href="form-usuario.php"><span class="fa fa-user"></span>  Cadastrar Usuários</a></li>
                                    <li class="divider"></li>
                                    <li><a href="form-lancamento.php"><span class="fa fa-calculator"></span>  Cadastrar Lançamentos</a></li>
                                    <li class="divider"></li>
                                    <li><a href="form-saida.php"><span class="fa fa-hand-o-down"></span>  Cadastrar Saida</a></li>
                                    <li class="divider"></li>
                                    <li><a href="form-destinacao.php"><span class="fa fa-list"></span>  Cadastrar Destinação</a></li>
                                    <li class="divider"></li>
                                    <li><a href="form-membros.php"><span class="fa fa-users"></span>  Cadastrar Membros</a></li>
                                    <li class="divider"></li>
                                    <li><a href="form-visitante.php"><span class="fa fa-user-plus"></span>  Cadastrar Visitantes</a></li>
                                </ul>
                            </li>
                            
                            
                            
                            
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <span class="fa fa-thumbs-o-up"></span> Confirmações <b class="caret"></b>
                                </a>

                                <ul class="dropdown-menu">
                                    
                                    <li><a href="form-entradas-listar.php"><span class="fa fa-calculator"></span> Confirmar Lançamentos</a></li>
                                    <li class="divider"></li>
                                    <li><a href="form-saidas-listar.php"><span class="fa fa-hand-o-down"></span> Confirmar Saidas</a></li>
                                    
                                </ul>
                            </li>
                            
                            
                            
                            

                        </ul>


                        <ul class="nav navbar-nav navbar-right">

                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <span class="glyphicon glyphicon-user"></span> 
                                    <?php echo $_COOKIE['nomePessoa']; ?> <b class="caret"></b>
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a href="#"><span class="glyphicon glyphicon-user"></span> Perfil</a></li>
                                    <li><a href="#"><span class="glyphicon glyphicon-cog"></span> Configurações</a></li>
                                    <li class="divider"></li>
                                    <li><a href="?logout"><span class="glyphicon glyphicon-off"></span> Sair</a></li>
                                </ul>
                            </li>

                        </ul>
                    </div>
                </div>
            </nav>
        </div>



    </header>
