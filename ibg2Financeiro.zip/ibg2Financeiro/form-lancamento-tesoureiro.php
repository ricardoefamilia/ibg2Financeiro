<?php
      require_once 'top.php';
      require_once 'mostra-alerta.php';
      require_once 'sql/banco-teste.php';
      require_once 'sql/banco-membros.php';
      require_once 'sql/banco-bancos.php';
       require_once 'sql/banco-destinacao.php';

      error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
      session_start();

      $destinacoes = buscaDestinacoes($con);
      $membros = consultaMembros($con);
      $bancos = buscaBancos($con);
      
      
     
      if ($_GET['acao'] == 'del') {
          $id = intval($_GET['id']);
          unset($_SESSION['cart'][$id]);
          $_SESSION['warning'] = 'Lançamento removido com sucesso.';
          header('Location: form-lancamento.php');
          die();
      }

?>


   <section class="container margem-bottom">

      <?php
         mostraAlerta('danger');
         mostraAlerta('warning');
         mostraAlerta('success');
      ?>

      <div class="col-md-12">
            <h3 class="page-header text-center">Cadastrar Lançamento</h3>
         <form method="post" action="add-to-cart.php">

            <h4>Nome</h4>
            <div class="col-md-12">
                
                
                   
                  <select data-placeholder="Busca" class="chosen-select" name="nome" id="nome">

                     <?php foreach ($membros as $membro): ?>
                         <?php if ($membro['nome'] === Anônimo):?>
                        <option value="<?=$membro['idPessoas']?>"><?=$membro['nome']?></option>
                        <?php endif;?>
                    <?php endforeach; ?>

                  </select>
               
               </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">

                <h3 class="page-header text-center">Tipo de Oferta</h3>

                <!-- CHEQUE -->
<!--                <div class="col-md-5">
                    <h4>Cheque</h4>

                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="numero-cheque">N. do cheque</label>
                            <div class="input-group">
                                <span class="input-group-addon">
                                <input type="checkbox" id="check-cheque">
                             </span>
                                <input type="text" class="form-control" name="numero-cheque" id="cheque" disabled>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="nome-banco">Banco</label>
                            <select class="form-control" id="banco" name="nome-banco" disabled>
                                < ?php foreach ($bancos as $banco): ?>
                                    <option value="< ?=$banco['nrBanco']?> - < ?=$banco['banco']?>" < ?php if($banco['nrBanco']==="001") echo"selected";?>>< ?=$banco['nrBanco']?> - < ?=$banco['banco']?> </option>
                                < ?php endforeach; ?>

                            </select>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="nome-banco">Agência</label>
                            <input type="text" class="form-control" name="cheque-agencia" id="cheque-agencia" disabled>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="nome-banco">Conta</label>
                            <input type="text" class="form-control" name="cheque-conta" id="cheque-conta" disabled>
                        </div>
                    </div>


                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="nome-banco">Valor</label>
                            <input type="text" class="form-control" name="valor-cheque" id="valor-cheque" disabled>
                        </div>
                    </div>
                </div>-->

                <!-- DEPOSITO -->
                <div class="col-md-4">
                    <h4>Depósitos / Transferências</h4>

                    <label for="numero-cheque">N. do comprovante</label>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon">
                                    <input type="checkbox" id="check-deposito">
                                </span>
                            <input type="text" class="form-control" name="comprovante-deposito" id="comprovante-deposito" disabled>
                        </div>
                    </div>


                    <label for="numero-cheque">Valor</label>
                    <div class="form-group">
                        <input type="text" class="form-control" id="valor-deposito" name="valor-deposito" disabled>
                    </div>
                </div>

                <!-- DINHEIRO -->
<!--                <div class="col-md-3">
                    <h4>Dinheiro</h4>
                    <label for="numero-cheque">Valor</label>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon">
                                 <input type="checkbox" id="check-dinheiro">
                                 </span>
                            <input type="text" class="form-control" name="dinheiro" id="dinheiro" disabled>
                        </div>
                    </div>
                </div>-->



            </div>
        </div>


        <div class="col-md-12">
            <h3 class="page-header text-center">Destinação</h3>
            
            <div class="form-group">
                <select class="chosen-select" name="destinacao">

                    
                        <option value="6">
                            Oferta Avulsa
                        </option>
                    

                </select>
            </div>
        </div>

            

            <button type="submit" class="btn btn-default center-block">
               <span class="fa fa-plus"></span>
               Adicionar
            </button>
          
         </form>
      </div>

    <?php if (empty($_SESSION['cart'])): ?>
    <?php else: ?>
      <div class="col-xs-12 col-md-12">

            <h3 class="page-header text-center">Lançamentos cadastrados</h3>

         <form action="verifica-lancamento.php" method="post">
             <div class="table-responsive">
            <table class="table table-bordered">

               <thead>
                  <tr>
                     <th>#</th>
                     <th>Nome</th>
                     <th>Valor</th>
                     <th>Pagamento</th>
                     <th>Destinação</th>
                     <th>Ação</th>
                  </tr>
               </thead>


            <tbody>

               <?php
                  foreach ($_SESSION['cart'] as $key => $value) :
                  $pessoa = consultaMembrosPorID($con, $value["FKPessoa"]);
                  $destinacao = selecionaDestinacao($con, $value['FKDestinacao']);
                ?>

                  <tr>
                     <td><?=$key?></td>
                     <td><?=$pessoa['nome'];?></td>
                     <td><?=$value['valor']?></td>

                     <td>
                        <?php if ($value["especie"] === 1): ?>
                           Dinheiro
                        <?php endif; ?>

                        <?php if ($value["especie"] === 2): ?>
                           Depósito
                        <?php endif; ?>

                        <?php if ($value["especie"] === 3): ?>
                           Cheque
                        <?php endif; ?>
                     </td>

                     <td><?=$destinacao['descricao'];?></td>
                     <td>
                        <!-- BTN MODAL -->
                        <button type="button" class="btn btn-danger btnModal" data-toggle="modal" data-target="#myModal-<?=$key?>">
                           <span class="fa fa-trash"></span>
                           Remover
                        </button>

                        <a href="form-lancamento-altera.php?id=<?=$key?>" class="btn btn-info" >
                           <span class="fa fa-pencil-square-o"></span>
                           Alterar
                       </a>
                     </td>

                     <!-- Modal Remover -->
                     <div class="modal fade" id="myModal-<?=$key?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                       <div class="modal-dialog" role="document">

                          <!-- MODAL CONTENT -->
                         <div class="modal-content">

                           <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times</button>
                              <h4>Excluir Lançamento</h4>
                           </div>

                           <!-- MODAL BODY -->
                           <div class="modal-body">
                              <p>Tem certeza que deseja excluir o Lançamento?</p>
                           </div>

                           <!-- MODAL FOOTER -->
                           <div class="modal-footer">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Não</button>
                              <a class="btn btn-primary" href="<?=$_SERVER['PHP_SELF']?>?acao=del&id=<?=$key?>">
                                 Sim
                              </a>
                           </div>
                         </div>

                       </div>
                     </div>

                  </tr>

               <?php endforeach ?>

            </tbody>

            </table>
            </div>

            <button type="submit" id="finalizar" class="btn btn-success center-block">
                Continuar
               <span class="fa fa-angle-double-right"></span>
            </button>
         </form>
      </div>
    <?php endif; ?>

    </section>

 
<?php require_once 'footer.php' ?>
