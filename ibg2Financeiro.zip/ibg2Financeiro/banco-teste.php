<?php
    session_start();
   require_once 'conexao.php';

   function adicionaDestinacao($con, $destinacao)
   {
       $destinacao = mysqli_real_escape_string($con, $destinacao);
       $query = "INSERT INTO destinacao (descricao) values('{$destinacao}')";
       return mysqli_query($con, $query);
   }

   function removeDestinacao($con, $id)
   {
       $query = "DELETE FROM destinacao where iddestinacao = {$id}";
       return mysqli_query($con, $query);
   }

   function buscaDestinacoes($con)
   {
       $destinacoes = [];
       $query = "SELECT * FROM destinacao";
       $result = mysqli_query($con, $query);

       while ($destinacao = mysqli_fetch_assoc($result)) {
           array_push($destinacoes, $destinacao);
       }

       return $destinacoes;
   }

   function selecionaPessoa($con, $id = [])
   {
       $query = "SELECT nome FROM pessoas where idPessoas = {$id}";
       $resultado = mysqli_query($con, $query);
       $pessoa = mysqli_fetch_assoc($resultado);

       return $pessoa;
   }

   function selecionaDestinacao($con, $id = [])
   {
       $query = "SELECT descricao FROM destinacao where iddestinacao = {$id}";
       $resultado = mysqli_query($con, $query);
       $destinacao = mysqli_fetch_assoc($resultado);

       return $destinacao;
   }


   function adicionaLancamento($con, $value)
   {
       $fkUsuarioLancou = $_COOKIE['usuario'];
       $fkUsuarioConferiu = $_SESSION['usuarioConferiu'];
       if(isset($value['valor'])){
           $valorTradado = str_replace(',','.',str_replace('.','',$value['valor']));
            $value['valor'] = mysqli_real_escape_string($con, $valorTradado);
        }
       if(isset($value['numero-cheque'])){
            $value['numero-cheque'] = mysqli_real_escape_string($con, $value['numero-cheque']);
        }
       if(isset($value['nome-banco'])){
            $value['nome-banco'] = mysqli_real_escape_string($con, $value['nome-banco']);
        }
       if(isset($value['numero-comprovante'])){
            $value['numero-comprovante'] = mysqli_real_escape_string($con, $value['numero-comprovante']);
        }
       if(isset($value['agencia'])){
            $value['agencia'] = mysqli_real_escape_string($con, $value['agencia']);
        }
       if(isset($value['conta'])){
            $value['conta'] = mysqli_real_escape_string($con, $value['conta']);
        }

       if ($value['especie'] === 1) {
                  
           $query = "INSERT INTO entradas
           (FKDestinacao, FKPessoa_Ofertou, FKUsuarioLancou, FKUsuarioConferiu, valor, especie, nrCheque, bancoCheque, nrDepositoComprovante, agencia, conta, dataLancamentoEntrada, horaLancamentoEntrada,confirmado) values (
                  '" . $value['FKDestinacao'] . "' ,
                  '" . $value['FKPessoa'] . "' ,
                  '" . $fkUsuarioLancou . "' ,
                  " . $fkUsuarioConferiu . " ,
                  '" . $value['valor'] . "' ,
                  '" . $value['especie'] . "' ,
                  '" . "-" . "' ,
                  '" . "-" . "' ,
                  '" . "-" . "' ,
                  '" . "-" . "' ,
                  '" . "-" . "',
                  current_date(), current_time(),
                  0
               )";
           
                           
           return mysqli_query($con, $query);
       }

       if ($value['especie'] === 2) {
           $query = "INSERT INTO entradas
            (FKDestinacao, FKPessoa_Ofertou, FKUsuarioLancou, FKUsuarioConferiu, valor, especie, nrCheque, bancoCheque, nrDepositoComprovante, agencia, conta, dataLancamentoEntrada, horaLancamentoEntrada, confirmado) values (
                  " . $value['FKDestinacao'] . " ,
                  " . $value['FKPessoa'] . " ,
                  " . $fkUsuarioLancou . " ,
                  " . $fkUsuarioConferiu . " ,
                  " . $value['valor'] . " ,
                  " . $value['especie'] . " ,
                  '" . "-" . "' ,
                  '" . "-" . "' ,
                  '" . $value['numero-comprovante'] . "' ,
                  '" . "-" . "' ,
                  '" . "-" . "',
                  current_date(), current_time(),
                  0
               )";
           return mysqli_query($con, $query);
       }

       if ($value['especie'] === 3) {
           $query = "INSERT INTO entradas
           (FKDestinacao, FKPessoa_Ofertou, FKUsuarioLancou, FKUsuarioConferiu, valor, especie, nrCheque, bancoCheque, nrDepositoComprovante, agencia, conta, dataLancamentoEntrada, horaLancamentoEntrada, confirmado) values (
                  " . $value['FKDestinacao'] . " ,
                  " . $value['FKPessoa'] . " ,
                  " . $fkUsuarioLancou . " ,
                  " . $fkUsuarioConferiu . " ,
                  " . $value['valor'] . " ,
                  " . $value['especie'] . " ,
                  '" . $value['numero-cheque'] . "' ,
                  '" . $value['nome-banco'] . "' ,
                  '" . "-" . "' ,
                  '" . $value['agencia'] . "' ,
                  '" . $value['conta'] . "',
                  current_date(), current_time(),
                  0
               )";
           return mysqli_query($con, $query);
       }
   }
