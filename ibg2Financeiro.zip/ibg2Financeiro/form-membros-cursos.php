<?php
    require_once 'top.php';
    $idMembro = $_GET['id'];
?>

<section class="container">
    <h3 class="page-header">Especialização</h3>
    <div class="row">
        <div class="col-sm-12">
            <div class="table-responsive">
                <form action="cadastra-cursos.php" method="post">
                    <input type="hidden" name="idMembro" value="<?=$idMembro?>">
                <table class="table">

                    <thead>
                        <tr>
                            <th class="text-center">Curso</th>
                            <th class="text-center">Titulação</th>
                            <th class="text-center">Instituição</th>
                        </tr>
                    </thead>

                    <tbody id="tabela-especializacao">
                        <tr>
                            <td> <input type="text" name="curso[]" id="curso" class="form-control" > </td>
                            <td> <input type="text" name="titulacao[]" id="titulacao" class="form-control" > </td>
                            <td> <input type="text" name="instituicao[]" id="instituicao" class="form-control"> </td>
                        </tr>
                    </tbody>

                </table>
            </div>
                    <button type="button" class="btn btn-primary pull-right" id="adiciona-especializacao">
                        <span class="fa fa-plus"></span> Add
                    </button>
                    <button type="submit" class="btn btn-success">
                        <span class="fa fa-check"></span> Concluir
                    </button>
                    <a href="membros-cadastro-cursos.php?id=<?=$idMembro?>" class="btn btn-default">
                        <span class="fa fa-angle-double-left"></span> Voltar
                    </a>
                </form>
        </div>
    </div>

</section>

<?php require_once 'footer.php' ?>
<script src="js/adiciona-especializacao.js"></script>
