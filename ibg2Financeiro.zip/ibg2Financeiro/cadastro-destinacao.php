<?php
   require_once 'sql/conexao.php';
   require_once 'sql/banco-destinacao.php';
   session_start();


     if ($_POST["destinacao"] === "" || $_POST["destinacao"] === null) {
        $_SESSION['danger'] = "O campo 'Nome da destinacao' não pode ficar em branco!";
        header('Location: form-destinacao.php');
    } elseif (adicionaDestinacao($con, $_POST["destinacao"])) {
        $_SESSION['success'] = 'Destinação cadastrada com sucesso!';
        header('Location: form-destinacao.php');
    }

    die();
