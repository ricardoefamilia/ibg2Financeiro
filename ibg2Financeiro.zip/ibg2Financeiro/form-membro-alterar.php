<?php
   require_once 'top.php';
   require_once 'sql/banco-membros.php';
   require_once 'sql/banco-uf.php';
   require_once 'sql/banco-orgao.php';

   $id = $_GET['id'];
   $membro = consultaMembrosPorID($con, $id);
   $estados = buscaEstados($con);
   $orgaos = buscaOrgaos($con);

   echo "<pre>";
    print_r($membro);
   echo "</pre>";
?>


   <section class="container">
      <h2 class="page-header">Alterar - <?=$membro['nome'] ?> </h2>

      <ul class="nav nav-tabs">
         <li class="active"><a data-toggle="tab" href="#dados-pessoais">Dados pessoais</a></li>
         <li><a data-toggle="tab" href="#enderecoTab">Endereço</a></li>
         <li><a data-toggle="tab" href="#filiacao">Filiação</a></li>
         <li><a data-toggle="tab" href="#trabalho">Trabalho</a></li>
         <li><a data-toggle="tab" href="#igreja">Igreja</a></li>
         <li><a data-toggle="tab" href="#dons">Dons</a></li>
         <li><a data-toggle="tab" href="#ibg2">IBG2</a></li>
      </ul>

      <form action="cadastra-membro.php" method="post" id="form-membros">
      <div class="tab-content">

         <div id="dados-pessoais" class="tab-pane fade in active">
            <div class="panel-body">

               <div class="row">

                     <div class="col-sm-12">
                        <div class="form-group">
                           <label for="tipo-pessoa">
                              Tipo de pessoa
                              <span class="red-color fa fa-asterisk"></span>
                           </label>
                           <div class="radio">
                               <?php if ($membro['tipoPessoa'] == 1): ?>
                                   <label for="">
                                       <input type="radio" name="tipoPessoa" value="1" checked>Membro
                                   </label>
                               <?php else: ?>
                                   <label for="">
                                       <input type="radio" name="tipoPessoa" value="1">Membro
                                   </label>
                               <?php endif ?>

                               <?php if ($membro['tipoPessoa'] == 1): ?>
                                   <label for="">
                                       <input type="radio" name="tipoPessoa" value="0" checked>Congregado
                                   </label>
                               <?php else: ?>
                                   <label for="">
                                       <input type="radio" name="tipoPessoa" value="0">Congregado
                                   </label>
                               <?php endif ?>
                           </div>
                        </div>
                     </div>

                     <div class="col-sm-5">
                        <div class="form-group">
                           <label for="nome">
                              Nome
                              <span class="red-color fa fa-asterisk"></span>
                           </label>
                           <input type="text" name="nome" id="nome" value="<?=$membro['nome']?>" class="form-control" >
                        </div>
                     </div>

                     <div class="col-md-4">
                        <div class="form-group">
                           <label for="">E-mail</label>
                           <input type="text" name="emailPessoal" value="<?=$membro['emailPessoal']?>" class="form-control">
                        </div>
                     </div>

                     <div class="col-sm-3">
                        <label for="sexo">
                           Sexo
                           <span class="red-color fa fa-asterisk"></span>
                        </label>
                        <div class="radio">
                            <?php if ($membro['sexo'] == 1): ?>
                                <label for="">
                                    <input type="radio" name="sexo" value="1" checked>Masculino
                                </label>
                            <?php else: ?>
                                <label for="">
                                    <input type="radio" name="sexo" value="1">Masculino
                                </label>
                            <?php endif ?>

                            <?php if ($membro['sexo'] == 0): ?>
                                <label for="">
                                    <input type="radio" name="sexo" value="0" checked>Feminino
                                </label>
                            <?php else : ?>
                                <label for="">
                                    <input type="radio" name="sexo" value="0">Feminino
                                </label>
                            <?php endif ?>
                        </div>
                     </div>
               </div>

               <div class="row">

                 <div class="col-sm-5">
                    <div class="form-group">
                       <label for="orgaoExpedidor">
                          Órgão expedidor
                          <span class="red-color fa fa-asterisk"></span>
                       </label>
                       <select name="orgaoExpedidor" id="orgaoExpedidor" class="form-control" >

                          <?php foreach ($orgaos as $orgao):
                            $orgaoCorreto = $membro['orgaoExpedidor'] === $orgao['sigla'];
                            $selecao = $orgaoCorreto ? "selected='selected'" : "";
                          ?>
                            <option value="<?=$orgao['sigla']?>" <?=$selecao?>>
                              <?=$orgao['descricao'] ?>
                            </option>
                          <?php endforeach; ?>

                       </select>
                    </div>
                 </div>

                  <div class="col-sm-3">
                     <div class="form-group">
                        <label for="rg">
                           Nº da identidade
                           <span class="red-color fa fa-asterisk"></span>
                        </label>
                        <input type="text" name="rg" id="rg" value="<?=$membro['rg']?>" class="form-control" >
                     </div>
                  </div>



                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="">
                           CPF
                           <span class="red-color fa fa-asterisk"></span>
                        </label>
                        <input type="text" name="cpf" id="cpf" value="<?=$membro['cpf']?>" class="form-control" >
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="dataNascimento">
                            Data de Nascimento
                            <span class="red-color fa fa-asterisk"></span>
                         </label>
                         <input type="date" name="nascimento" id="nascimento" value="<?=$membro['nascimento']?>" class="form-control datepicker" >
                     </div>
                  </div>


               </div>


               <div class="row">
                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="">
                              Nascimento - UF
                              <span class="red-color fa fa-asterisk"></span>
                           </label>
                        <select name="nascimentoEstado" id="nascimentoEstado" class="form-control" >

                              <?php foreach ($estados as $estado):
                                  $estadoCorreto = $membro['estado'] === $estado['sigla'];
                                  $selecao = $estadoCorreto ? "selected='selected'" : "";
                              ?>
                                  <option value="<?=$estado['sigla']?>" <?=$selecao?>>
                                    <?=$estado['descricao']?>
                                  </option>
                              <?php endforeach; ?>

                           </select>
                     </div>
                  </div>

                  <div class="col-sm-3">
                     <div class="form-group">
                        <label for="">
                              Nascimento - Cidade
                              <span class="red-color fa fa-asterisk"></span>
                           </label>
                        <input type="text" name="nascimentoCidade" id="cidade-nascimento" value="<?=$membro['nascimentoCidade']?>" class="form-control" >
                     </div>
                  </div>

                  <div class="col-sm-3">
                     <div class="form-group">
                        <label for="">
                              Estado Civil
                              <span class="red-color fa fa-asterisk"></span>
                           </label>
                        <select class="form-control" name="estadoCivil" id="estado-civil" >
                            <?php if ($membro['estadoCivil'] == 1) : ?>
                              <option value="1" selected>Solteiro(a)</option>
                            <?php else : ?>
                              <option value="1">Solteiro(a)</option>
                            <?php endif ?>

                            <?php if ($membro['estadoCivil'] == 2) : ?>
                              <option value="2" selected>Casado(a)</option>
                            <?php else: ?>
                              <option value="2">Casado(a)</option>
                            <?php endif ?>

                            <?php if ($membro['estadoCivil'] == 3) : ?>
                              <option value="3" selected>Divorciado(a)</option>
                            <?php else: ?>
                              <option value="3">Divorciado(a)</option>
                            <?php endif ?>

                            <?php if ($membro['estadoCivil'] == 4) : ?>
                              <option value="4" selected>Separado(a)</option>
                            <?php else: ?>
                              <option value="4">Separado(a)</option>
                            <?php endif ?>

                            <?php if ($membro['estadoCivil'] == 5) : ?>
                              <option value="5" selected>Viúvo(a)</option>
                            <?php else: ?>
                              <option value="5">Viúvo(a)</option>
                            <?php endif ?>
                        </select>
                     </div>
                  </div>


                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="">
                              Tipo sanguineo
                              <span class="red-color fa fa-asterisk"></span>
                           </label>
                        <select class="form-control" name="tipoSanguineo" id="tipo-sanguineo" >

                            <?php if ($membro['tipoSanguineo'] == 1): ?>
                                <option value="1" selected>O</option>
                            <?php else: ?>
                                <option value="1">O</option>
                            <?php endif ?>

                            <?php if ($membro['tipoSanguineo'] == 2): ?>
                                <option value="2" selected>A</option>
                            <?php else: ?>
                                <option value="2">A</option>
                            <?php endif ?>

                            <?php if ($membro['tipoSanguineo'] == 3): ?>
                                <option value="3" selected>B</option>
                            <?php else: ?>
                                <option value="3">B</option>
                            <?php endif; ?>

                            <?php if ($membro['tipoSanguineo'] == 4): ?>
                                <option value="4" selected>AB</option>
                            <?php else: ?>
                                <option value="4">AB</option>
                            <?php endif; ?>
                        </select>
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="">Fator RH</label>
                        <input type="text" name="fatorRh" value="<?=$membro['fatorRh']?>" class="form-control">
                     </div>
                  </div>

               </div>

               <div class="row">


                  <div class="col-sm-4">
                     <div class="form-group">
                        <label>
                              Grau de instrução
                              <span class="red-color fa fa-asterisk"></span>
                           </label>

                        <select class="form-control" name="escolaridade" id="escolaridade" >
                             <optgroup label="Ensino Fundamental">
                                 <?php if ($membro['escolaridade'] == 1): ?>
                                     <option value="1" selected>Ensino Fundamental incompleto</option>
                                 <?php else: ?>
                                     <option value="1">Ensino Fundamental incompleto</option>
                                 <?php endif ?>

                                 <?php if ($membro['escolaridade'] == 2): ?>
                                     <option value="2" selected>Ensino Fundamental cursando</option>
                                 <?php else: ?>
                                     <option value="2">Ensino Fundamental cursando</option>
                                 <?php endif ?>

                                 <?php if ($membro['escolaridade'] == 3): ?>
                                     <option value="3" selected>Ensino Fundamental completo</option>
                                 <?php else: ?>
                                     <option value="3">Ensino Fundamental completo</option>
                                 <?php endif ?>
                             </optgroup>

                             <optgroup label="Ensino Médio">
                                 <?php if ($membro['escolaridade'] == 4): ?>
                                     <option value="4" selected>Ensino Médio incompleto</option>
                                 <?php else: ?>
                                     <option value="4">Ensino Médio incompleto</option>
                                 <?php endif ?>

                                 <?php if ($membro['escolaridade'] == 5): ?>
                                     <option value="5" selected>Ensino Médio cursando</option>
                                 <?php else: ?>
                                     <option value="5">Ensino Médio cursando</option>
                                 <?php endif ?>

                                 <?php if ($membro['escolaridade'] == 6): ?>
                                     <option value="6" selected>Ensino Médio completo</option>
                                 <?php else: ?>
                                     <option value="6">Ensino Médio completo</option>
                                 <?php endif ?>
                             </optgroup>

                             <optgroup label="Ensino Superior">

                                 <?php if ($membro['escolaridade'] == 7): ?>
                                     <option value="7" selected>Ensino Superior incompleto</option>
                                 <?php else: ?>
                                     <option value="7">Ensino Superior incompleto</option>
                                 <?php endif ?>

                                 <?php if ($membro['escolaridade'] == 8): ?>
                                     <option value="8" selected>Ensino Superior cursando</option>
                                 <?php else: ?>
                                     <option value="8">Ensino Superior cursando</option>
                                 <?php endif ?>

                                 <?php if ($membro['escolaridade'] == 9): ?>
                                     <option value="9" selected>Ensino Superior completo</option>
                                 <?php else: ?>
                                     <option value="9">Ensino Superior completo</option>
                                 <?php endif ?>

                             </optgroup>
                          </select>
                     </div>
                  </div>

                  <div class="col-sm-12">
                      <legend>Especialização</legend>

                      <table class="table">

                          <thead>
                              <tr>
                                  <th class="text-center">
                                      Curso
                                      <span class="red-color fa fa-asterisk"></span>
                                  </th>

                                  <th class="text-center">
                                      Titulação
                                      <span class="red-color fa fa-asterisk"></span>
                                  </th>
                                  <th class="text-center">Instituição</th>
                                  <th></th>
                              </tr>
                          </thead>

                          <tbody id="tabela-especializacao">
                              <tr>
                                  <td> <input type="text" name="curso[]" id="curso" class="form-control" > </td>
                                  <td> <input type="text" name="titulacao[]" id="titulacao" class="form-control" > </td>
                                  <td> <input type="text" name="instituicao[]" class="form-control"> </td>
                              </tr>
                          </tbody>

                      </table>

                      <button type="button" class="btn btn-info" id="adiciona-especializacao">
                          <span class="fa fa-plus"></span> Add
                      </button>
                  </div>

               </div>
            </div>
         </div>
         <!-- fim dados pessoais -->

         <div id="enderecoTab" class="tab-pane fade">
            <div class="panel-body">

               <div class="row">

                  <div class="col-md-2">
                     <div class="form-group">
                        <label for="cep">
                           CEP
                           <span class="red-color fa fa-asterisk"></span>
                        </label>
                        <input type="text" id="cep" name="cep" value="<?=$membro['cep']?>" class="form-control" onblur="pesquisacep(this.value);"  >
                     </div>
                  </div>

                  <div class="col-md-4">
                     <div class="form-group">
                        <label for="endereco">
                           Endereço
                           <span class="red-color fa fa-asterisk"></span>
                        </label>
                        <input type="text" id="endereco" name="endereco" value="<?=$membro['endereco']?>" class="form-control" readonly>
                     </div>
                  </div>

                  <div class="col-md-3">
                     <div class="form-group">
                        <label for="">
                           Cidade
                           <span class="red-color fa fa-asterisk"></span>
                           </label>
                        <input type="text" id="cidade" name="cidade" value="<?=$membro['cidade']?>" class="form-control" readonly>
                     </div>
                  </div>

                  <div class="col-md-1">
                     <div class="form-group">
                        <label for="">
                           UF
                           <span class="red-color fa fa-asterisk"></span>
                           </label>
                        <input type="text" name="estado" id="estado" value="<?=$membro['estado']?>" class="form-control" readonly>
                     </div>
                  </div>

                  <div class="col-md-2">
                     <div class="form-group">
                        <label for="">
                          Bairro
                          <span class="red-color fa fa-asterisk"></span>
                        </label>
                        <input type="text" id="bairro" name="bairro" value="<?=$membro['bairro']?>" class="form-control" readonly>
                     </div>
                  </div>

               </div>

               <div class="row">

                   <div class="col-md-2">
                      <div class="form-group">
                         <label for="">
                           Número
                           <span class="red-color fa fa-asterisk"></span>
                         </label>
                         <input type="text" name="numero" value="<?=$membro['numero']?>" class="form-control">
                      </div>
                   </div>

                   <div class="col-md-4">
                      <div class="form-group">
                         <label for="">
                           Complemento
                           <span class="red-color fa fa-asterisk"></span>
                         </label>
                         <input type="text" name="complemento" value="<?=$membro['complemento']?>" class="form-control">
                      </div>
                   </div>

                   <div class="col-md-3">
                     <div class="form-group">
                       <label for="">Telefone</label>
                       <input type="text" name="telefone" value="<?=$membro['telefone']?>" class="form-control">
                     </div>
                   </div>

                   <div class="col-md-3">
                     <div class="form-group">
                       <label for="">Celular</label>
                       <input type="text" name="celular" value="<?=$membro['celular']?>" class="form-control">
                     </div>
                   </div>
               </div>

            </div>
         </div>
         <!-- fim endereço -->

         <div id="filiacao" class="tab-pane fade">
            <div class="panel-body">
               <div class="row">
                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="nomePai">Nome do pai</label>
                        <input type="text" name="nomePai" class="form-control" value="<?=$membro['outrosPaiNome']?>">
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="paiEvangelico">É evangélico?</label>
                        <div class="radio">

                            <?php if ($membro['outrosPaiEvangelico'] == 1): ?>
                                <label for="">
                                    <input type="radio" name="paiEvangelico" value="1" checked> Sim
                                </label>
                            <?php else: ?>
                                <label for="">
                                    <input type="radio" name="paiEvangelico" value="1"> Sim
                                </label>
                            <?php endif ?>

                            <?php if ($membro['outrosPaiEvangelico'] == 0): ?>
                                <label for="">
                                   <input type="radio" name="paiEvangelico" value="0" checked> Não
                                </label>
                            <?php else: ?>
                                <label for="">
                                   <input type="radio" name="paiEvangelico" value="0"> Não
                                </label>
                            <?php endif ?>


                        </div>
                     </div>
                  </div>

                  <div class="col-sm-6">
                     <div class="form-group">
                        <label for="nomePai">Nome da igreja</label>
                        <input type="text" name="igrejaPai" class="form-control" value="<?=$membro['outrosPaiIgreja']?>">
                     </div>
                  </div>

               </div>

               <div class="row">

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="nomePai">Nome da mãe</label>
                        <input type="text" name="nomeMae" class="form-control" value="<?=$membro['outrosMaeNome']?>">
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="maeEvangelica">É evangélica?</label>
                        <div class="radio">

                            <?php if ($membro['outrosMaeIgreja'] == 1): ?>
                                <label for="">
                                   <input type="radio" name="maeEvangelica" value="1" checked> Sim
                                </label>
                            <?php else: ?>
                                <label for="">
                                   <input type="radio" name="maeEvangelica" value="1"> Sim
                                </label>
                            <?php endif ?>

                            <?php if ($membro['outrosMaeIgreja'] == 0): ?>
                                <label for="">
                                   <input type="radio" name="maeEvangelica" value="0" checked> Não
                                </label>
                            <?php else: ?>
                                <label for="">
                                   <input type="radio" name="maeEvangelica" value="0"> Não
                                </label>
                            <?php endif ?>

                        </div>
                     </div>
                  </div>

                  <div class="col-sm-6">
                     <div class="form-group">
                        <label for="nomePai">Nome da igreja</label>
                        <input type="text" name="igrejaMae" class="form-control" value="<?=$membro['outrosMaeIgreja']?>">
                     </div>
                  </div>

               </div>

               <h3 class="page-header">Conjugê</h3>
               <div class="row">

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Nome</label>
                        <input type="text" name="nomeConjuge" class="form-control" value="<?=$membro['outrosConjugeNome']?>">
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="conjugeEvangelico">É evangélico(a)?</label>
                        <div class="radio">

                            <?php if ($membro['outrosConjugeEvangelico'] == 1): ?>
                                <label for="">
                                      <input type="radio" name="conjugeEvangelico" value="1" checked> Sim
                                </label>
                            <?php else: ?>
                                <label for="">
                                      <input type="radio" name="conjugeEvangelico" value="1"> Sim
                                </label>
                            <?php endif ?>

                            <?php if ($membro['outrosConjugeEvangelico'] == 0): ?>
                                <label for="">
                                      <input type="radio" name="conjugeEvangelico" value="0" checked> Não
                                </label>
                            <?php else: ?>
                                <label for="">
                                      <input type="radio" name="conjugeEvangelico" value="0"> Não
                                </label>
                            <?php endif ?>



                        </div>
                     </div>
                  </div>

                  <div class="col-sm-6">
                     <div class="form-group">
                        <label for="nomePai">Nome da igreja</label>
                        <input type="text" name="igrejaConjuge" class="form-control" value="<?=$membro['outrosConjugeIgreja']?>">
                     </div>
                  </div>

               </div>

               <div class="row">

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Data de nascimento</label>
                        <input type="date" name="dataNascimentoConjuge" class="form-control" value="<?=$membro['outrosConjugeDataNascimento']?>">
                     </div>
                  </div>

                  <div class="col-sm-4 col-sm-offset-2">
                     <div class="form-group">
                        <label for="">Data de casamento</label>
                        <input type="date" name="dataCasamento" class="form-control" value="<?=$membro['outrosConjugeDataCasamento']?>">
                     </div>
                  </div>

               </div>
            </div>
         </div>

         <div id="trabalho" class="tab-pane fade">
            <div class="panel-body">
               <div class="row">

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Nome</label>
                        <input type="text" name="empresaNome" class="form-control" value="<?=$membro['empresaNome']?>">
                     </div>
                  </div>

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Cargo</label>
                        <input type="text" name="empresaCargo" class="form-control" value="<?=$membro['empresaCargo']?>">
                     </div>
                  </div>

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Profissão</label>
                        <input type="text" name="profissao" class="form-control" value="<?=$membro['profissao']?>">
                     </div>
                  </div>

               </div>

               <div class="row">

                  <div class="col-sm-2">
                    <div class="form-group">
                      <label for="">Cep</label>
                      <input type="text" name="empresaCep" class="form-control" value="<?=$membro['empresaCep']?>">
                    </div>
                  </div>

                  <div class="col-sm-2">
                    <div class="form-group">
                        <label for="">UF</label>
                        <input type="text" name="empresaEstado" class="form-control" value="<?=$membro['empresaEstado']?>">
                    </div>
                  </div>


                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Endereço</label>
                        <input type="text" name="empresaEndereco" class="form-control" value="<?=$membro['empresaEndereco']?>">
                     </div>
                  </div>

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Cidade</label>
                        <input type="text" name="empresaCidade" class="form-control" value="<?=$membro['empresaCidade']?>">
                     </div>
                  </div>
               </div>

               <div class="row">

                 <div class="col-sm-2">
                    <div class="form-group">
                       <label for="">Número</label>
                       <input type="text" name="empresaNumero" class="form-control" value="<?=$membro['empresaNumero']?>">
                    </div>
                 </div>

                 <div class="col-sm-2">
                   <div class="form-group">
                     <label for="">Bairro</label>
                     <input type="text" name="empresaBairro" class="form-control" value="<?=$membro['empresaBairro']?>">
                   </div>
                 </div>

                 <div class="col-sm-4">
                    <div class="form-group">
                       <label for="">Complemento</label>
                       <input type="text" name="empresaComplemento" class="form-control" value="<?=$membro['empresaComplemento']?>">
                    </div>
                 </div>

                 <div class="col-sm-4">
                    <div class="form-group">
                       <label for=""> Data de admissão</label>
                       <input type="date" name="dataAdmissao" class="form-control" value="<?=$membro['dataAdmissao']?>">
                    </div>
                 </div>


               </div>
            </div>
         </div>

          <div id="igreja" class="tab-pane fade">
            <div class="panel-body">
               <div class="row">
                   <legend>Batismo</legend>
                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Igreja onde foi batizado</label>
                        <input type="text" name="igrejaBatismoNomeIgreja" class="form-control" value="<?=$membro['igrejaBatismoNomeIgreja']?>">
                     </div>
                  </div>

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Data de batismo</label>
                        <input type="date" name="igrejaBatismoDataBatismo" class="form-control datepicker" value="<?=$membro['igrejaBatismoDataBatismo']?>">
                     </div>
                  </div>

               </div>

               <div class="row">
                   <legend>Igreja de origem</legend>

                   <div class="col-sm-4">
                      <div class="form-group">
                         <label for="">Nome</label>
                         <input type="text" name="igrejaOrigemNome" class="form-control" value="<?=$membro['igrejaOrigemNome']?>">
                      </div>
                   </div>

                   <div class="col-sm-4">
                       <div class="form-group">
                           <label for="">Endereço</label>
                           <input type="text" name="igrejaOrigemEndereco" class="form-control" value="<?=$membro['igrejaOrigemEndereco']?>">
                       </div>
                   </div>

                   <div class="col-sm-4">
                       <div class="form-group">
                           <label for="">Cidade</label>
                           <input type="text" name="igrejaOrigemCidade" class="form-control" value="<?=$membro['igrejaOrigemCidade']?>">
                       </div>
                   </div>
               </div>

               <div class="row">

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="">Cep</label>
                        <input type="text" name="igrejaOrigemCep" class="form-control" value="<?=$membro['igrejaOrigemCep']?>">
                     </div>
                  </div>

                  <div class="col-sm-2">
                    <div class="form-group">
                       <label for="">UF</label>
                       <select name="igrejaOrigemEstado" class="form-control">
                           <?php foreach ($estados as $estado):
                               $estadoCorreto = $membro['igrejaOrigemEstado'] === $estado['sigla'];
                               $selecao = $estadoCorreto ? "selected='selected'" : "";
                           ?>
                               <option value="<?=$estado['sigla']?>" <?=$selecao?>>
                                 <?=$estado['descricao']?>
                               </option>
                           <?php endforeach; ?>
                       </select>
                    </div>
                 </div>

                 <div class="col-sm-2">
                    <div class="form-group">
                       <label for="">Número</label>
                       <input type="text" name="igrejaOrigemNumero" class="form-control" value="<?=$membro['igrejaOrigemNumero']?>">
                    </div>
                 </div>

                 <div class="col-sm-2">
                   <div class="form-group">
                     <label for="">Bairro</label>
                     <input type="text" name="igrejaOrigemBairro" class="form-control" value="<?=$membro['igrejaOrigemBairro']?>">
                   </div>
                 </div>

                 <div class="col-sm-4">
                    <div class="form-group">
                       <label for="">Complemento</label>
                       <input type="text" name="igrejaOrigemComplemento" class="form-control" value="<?=$membro['igrejaOrigemComplemento']?>">
                    </div>
                 </div>

             </div>


               <div class="row">

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Telefone</label>
                        <input type="text" name="igrejaOigemTelefone" class="form-control" value="<?=$membro['igrejaOigemTelefone']?>">
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="">Dizimista</label>
                        <select class="form-control" name="igrejaOrigemDizimista" value="<?=$membro['igrejaOrigemDizimista']?>">
                            <?php if ($membro['igrejaOrigemDizimista'] == 1): ?>
                                <option value="1" selected>Sim</option>
                            <?php else: ?>
                                <option value="1">Sim</option>
                            <?php endif ?>

                            <?php if ($membro['igrejaOrigemDizimista'] == 0): ?>
                                <option value="0" selected>Não</option>
                            <?php else: ?>
                                <option value="0">Não</option>
                            <?php endif ?>
                        </select>
                     </div>
                  </div>

                  <div class="col-sm-12">
                     <div class="form-group">
                        <label for="">Atividades desenvolvidas em outras igrejas</label>
                        <textarea class="form-control" name="igrejaOrigemAtividades"><?=$membro['igrejaOrigemAtividades'] ?></textarea>
                     </div>
                  </div>
               </div>

            </div>
         </div>

         <div id="dons" class="tab-pane fade">
            <div class="panel-body">
               <div class="row">

                  <div class="col-sm-3">
                     <div class="form-group">
                        <label for="paiEvangelico">É dizimista?</label>
                        <?php if ($membro['dizimista'] == 1): ?>
                            <label class="col-sm-offset-3 radio-inline">
                                <input type="radio" name="dizimista" value="1" checked>Sim
                            </label>
                        <?php else: ?>
                            <label class="col-sm-offset-3 radio-inline">
                                <input type="radio" name="dizimista" value="1">Sim
                            </label>
                        <?php endif ?>

                        <?php if ($membro['dizimista'] == 0): ?>
                            <label class="col-sm-offset-3 radio-inline">
                                <input type="radio" name="dizimista" value="0" checked>Não
                            </label>
                        <?php else: ?>
                            <label class="col-sm-offset-3 radio-inline">
                                <input type="radio" name="dizimista" value="0">Não
                            </label>
                        <?php endif ?>
                     </div>
                  </div>

               </div>

               <div class="row">

                  <div class="col-sm-12">
                     <div class="form-group">
                        <label for="entrega-dizimo">Compromete-se a entregar os seus dízimos neste Igreja?</label>

                        <label class="radio-inline">
                              <input type="radio" name="entrega-dizimo" value="1">Sim
                        </label>
                        <label class="radio-inline">
                              <input type="radio" name="entrega-dizimo" value="0">Não
                        </label>
                     </div>
                  </div>

               </div>

               <div class="row">

                  <div class="col-sm-12">
                     <div class="form-group">
                        <label for="donsConhece">Conhece os ensinos bíblicos sobre os dons espirituais?</label>

                        <?php if ($membro['donsConhece'] == 1): ?>
                            <label class="radio-inline">
                                <input type="radio" name="donsConhece" value="1" checked>Sim
                            </label>
                        <?php else: ?>
                            <label class="radio-inline">
                                <input type="radio" name="donsConhece" value="1">Sim
                            </label>
                        <?php endif ?>

                        <?php if ($membro['donsConhece'] == 0): ?>
                            <label class="radio-inline">
                                  <input type="radio" name="donsConhece" value="0" checked>Não
                            </label>
                        <?php else: ?>
                            <label class="radio-inline">
                                  <input type="radio" name="donsConhece" value="0">Não
                            </label>
                        <?php endif ?>
                     </div>
                  </div>

               </div>


               <div class="row">

                  <div class="col-md-12">

                     <p>Conhece seus dons?</p>
                     <p>Se os conhece, assinale-os:</p>

                     <div class="form-group">
                        <select id="dom" multiple="multiple" name="seleciona-dons[]">

                        </select>
                     </div>

                     <div class="form-group">
                        <label for="donsPratica">Tem-no(s) praticado?</label>

                        <?php if ($membro['donsPratica'] == 1): ?>
                            <label class="radio-inline">
                                <input type="radio" name="donsPratica" value="1" checked>Sim
                            </label>
                        <?php else: ?>
                            <label class="radio-inline">
                                <input type="radio" name="donsPratica" value="1">Sim
                            </label>
                        <?php endif ?>

                        <?php if ($membro['donsPratica'] == 0): ?>
                            <label class="radio-inline">
                                  <input type="radio" name="donsPratica" value="0" checked>Não
                            </label>
                        <?php else: ?>
                            <label class="radio-inline">
                                  <input type="radio" name="donsPratica" value="0">Não
                            </label>
                        <?php endif ?>

                     </div>
                  </div>

               </div>
            </div>
         </div>

         <div id="ibg2" class="tab-pane fade">
            <div class="panel-body">
               <h3 class="page-header">Entrada</h3>

               <div class="row">
                  <div class="col-md-6">

                     <div class="form-group">
                        <span class="red-color fa fa-asterisk"></span>
                        <label for="">Admissão na IBG2 - Modo: </label>

                        <label class="radio-inline">
                              <input type="radio" name="modoAdmissao" value="Batismo">Batismo
                        </label>

                        <label class="radio-inline">
                              <input type="radio" name="modoAdmissao" value="Carta">Carta
                        </label>

                        <label class="radio-inline">
                              <input type="radio" name="modoAdmissao" value="Recomendação">Recomendação
                        </label>

                        <div class="radio">
                           <label for="">
                                 <input type="radio" name="modoAdmissao">Outro
                            </label>
                           <input type="text" name="modoAdmissao" class="form-control">
                        </div>
                     </div>

                     <div class="form-group form-inline">
                        <span class="red-color fa fa-asterisk"></span>
                        <label for="">Data da Sessão </label>
                        <input type="date" name="dataAdmissao" class="form-control datepicker" value="<?=$membro['dataAdmissao']?>" >
                     </div>
                  </div>

                  <div class="col-sm-12">
                     <div class="form-group">
                        <span class="red-color fa fa-asterisk"></span>
                        <label for="">Atividades desenvolvidas na IBG2</label>
                        <textarea class="form-control" name="atividades" ><?=$membro['atividades']?></textarea>
                     </div>
                  </div>
               </div>

               <h3 class="page-header">Saída</h3>
               <div class="row">
                  <div class="col-md-6">

                     <div class="form-group">
                        <label for="">Saída na IBG2 - Modo: </label>

                        <label class="radio-inline">
                            <input type="radio" name="saidaModo" value="Carta">Carta
                        </label>

                        <label class="radio-inline">
                              <input type="radio" name="saidaModo" value="Desligamento">Desligamento
                        </label>

                        <label class="radio-inline">
                              <input type="radio" name="saidaModo" value="Falecimento">Falecimento
                        </label>

                        <div class="radio">
                           <label for="">
                             <input type="radio">Outro
                            </label>
                           <input type="text" name="saidaModo" class="form-control">
                        </div>
                     </div>

                     <div class="form-group form-inline">
                        <label for="">Data da Sessão </label>
                        <input type="date" name="saidaDate" class="form-control datepicker">
                     </div>
                  </div>

                  <div class="col-sm-12">
                     <div class="form-group">
                        <label for="">Observação</label>
                        <textarea class="form-control" name=""></textarea>
                     </div>
                  </div>
               </div>


               <h3 class="page-header">Readmissão</h3>
               <div class="row">
                  <div class="col-md-6">

                     <div class="form-group">
                        <label for="">Readmissão - Modo: </label>
                        <input type="text" name="readmissaoModo" class="form-control">

                     </div>
                  </div>

                  <div class="col-md-3">
                     <label for="">Data da Sessão </label>
                     <input type="date" name="readmissaoData" class="form-control datepicker">
                  </div>
               </div>
            </div>
         <button type="submit" class="btn btn-success">Salvar</button>
         </div>

      </div>
     </form>
   </section>
   <!-- fim container -->

<?php require_once 'footer.php' ?>
