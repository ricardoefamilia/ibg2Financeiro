<?php

   require_once 'conexao.php';

   function adicionaDestinacao($con, $destinacao)
   {
       $destinacao = mysqli_real_escape_string($con, $destinacao);
       $query = "INSERT INTO destinacao (descricao) values('{$destinacao}')";
       return mysqli_query($con, $query);
   }

   function alteraDestinacao($con, $descricao, $id)
   {
      $descricao = mysqli_real_escape_string($con, $descricao);
      $query = "UPDATE destinacao set descricao = '{$descricao}' WHERE iddestinacao = {$id}";
      return mysqli_query($con, $query);
   }

   function removeDestinacao($con, $id)
   {
       
      $query = "DELETE FROM destinacao where iddestinacao = {$id}";

   	return mysqli_query($con, $query);
   }

   
   
   function buscaDestinacoes($con)
   {
       $destinacoes = [];
       $query = "SELECT iddestinacao, descricao FROM destinacao";
       $result = mysqli_query($con, $query);

       while ($destinacao = mysqli_fetch_assoc($result)) {
           array_push($destinacoes, $destinacao);
       }

       return $destinacoes;
   }

   function buscaDestinacaoPorID($con, $id)
   {
      $query = "SELECT iddestinacao, descricao from destinacao WHERE iddestinacao = {$id}";
      $resultado = mysqli_query($con, $query);
      $destinacao = mysqli_fetch_assoc($resultado);

      return $destinacao;
   }
   
     function selecionaDestinacao($con, $id = [])
   {
       $query = "SELECT descricao FROM destinacao where iddestinacao = {$id}";
       $resultado = mysqli_query($con, $query);
       $destinacao = mysqli_fetch_assoc($resultado);

       return $destinacao;
   }