<?php
require_once 'conexao.php';

function buscaMembrosFamiliares($con)
{
    $familiares = [];
    $query = "SELECT * FROM familiares";
    $resultado = mysqli_query($con, $query);

    while ($familiar = mysqli_fetch_assoc($resultado)) {
        array_push($familiares, $familiar);
    }

    return $familiares;
}

function consultaFamiliaresPorID($con, $idMembro)
{
  $query = "SELECT * FROM familiares WHERE fkPessoa = {$idMembro}";
  $resultado = mysqli_query($con, $query);
  $familiar = mysqli_fetch_assoc($resultado);

  return $familiar;
}