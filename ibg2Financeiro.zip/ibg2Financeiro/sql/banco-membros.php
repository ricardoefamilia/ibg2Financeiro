<?php
// $nomeFamiliar, $parentesco, $familiarEvangelico, $dataNascimentoFamiliar
require_once 'conexao.php';

function inserirMembroCurso($con, $curso,$titulacao,$instituicao,$idPessoas)
{
    $query = "";
	$temp = "";

	$query = $query . "INSERT INTO cursosrealizados (curso,titulacao,instituicao,FKPessoas)  values " ;

	for($i = 0 ; $i < count($curso); $i++){

		$temp = $temp . "('" . $curso[$i] . "','" . $titulacao[$i] . "','" . $instituicao[$i] . "','" . $idPessoas ."')" ;

		if ($i < count($curso) - 1) {$temp = $temp . ",";}
	}

    $query = $query . $temp . ";";

    return mysqli_query($con, $query);
}

function InserirMembroFamiliares($con,$post)
{
	$temp  = "";

	$query = "INSERT INTO membrosFamilares (familiarNome,familiarParentesco,familiarEvangelico,familiarDataNascimento,FKidMembro)  VALUES " ;

	for($i = 0 ; $i < count($post['nomeFamiliar']); $i++){
		$temp = $temp . "( '" . $post['nomeFamiliar'][$i] . "','" . $post['parentesco'][$i] . "','" . $post['familiarEvangelico'][$i]. "','" . $post['dataNascimentoFamiliar'][$i] . "','" . $post['idMembro'] ."')" ;
		if ($i < count($post['nomeFamiliar']) - 1) {
			$temp = $temp . ",";
			}
	}

    $query = $query . $temp . ";";

    return $query ; //mysqli_query($con, $query);

}

function InserirMembro($con,$post = [])
{
	$query = "";
//MEMBROS INCIO
    $query = $query . "insert into pessoas values (null,";
	$query = $query . "'" . $post['tipoPessoa']               . "', " ;
	$query = $query . "'" . $post['nome']                     . "', " ;
	$query = $query . "'" . $post['sexo']                     . "', " ;
	$query = $query . "'" . $post['nascimento']               . "', " ;
    $query = $query . "'" . $post['nascimentoCidade']         . "', " ;
	$query = $query . "'" . $post['nascimentoEstado']         . "', " ;
    $query = $query . "'" . $post['rg']                       . "', " ;
	$query = $query . "'" . $post['orgaoExpedidor']           . "', " ;
	$query = $query . "'" . $post['cpf']                      . "', " ;
	$query = $query . "'" . $post['estadoCivil']              . "', " ;
	$query = $query . "'" . $post['tipoSanguineo']            . "', " ;
	$query = $query . "'" . $post['fatorRh']                  . "', " ;
    $query = $query . "'" . $post['escolaridade']             . "', " ;
    $query = $query . "'" . $post['endereco']                 . "', " ;
	$query = $query . "'" . $post['numero']                   . "', " ;
	$query = $query . "'" . $post['complemento']              . "', " ;
	$query = $query . "'" . $post['bairro']                   . "', " ;
	$query = $query . "'" . $post['cidade']                   . "', " ;
	$query = $query . "'" . $post['estado']                   . "', " ;
	$query = $query . "'" . $post['cep']                      . "', " ;
	$query = $query . "'" . $post['emailPessoal']             . "', " ;
	$query = $query . "'" . $post['telefone']                 . "', " ;
	$query = $query . "'" . $post['celular']                  . "', " ;
	$query = $query . "'" . $post['profissao']                . "', " ;
	$query = $query . "'" . $post['empresaNome']              . "', " ;
	$query = $query . "'" . $post['empresaEndereco']          . "', " ;
	$query = $query . "'" . $post['empresaNumero']            . "', " ;
	$query = $query . "'" . $post['empresaComplemento']       . "', " ;
	$query = $query . "'" . $post['empresaBairro']            . "', " ;
	$query = $query . "'" . $post['empresaCidade']            . "', " ;
	$query = $query . "'" . $post['empresaEstado']            . "', " ;
	$query = $query . "'" . $post['empresaCep']               . "', " ;
	$query = $query . "'" . $post['empresaCargo']             . "', " ;
	$query = $query . "'" . $post['igrejaBatismoNomeIgreja']  . "', " ;
	$query = $query . "'" . $post['igrejaBatismoDataBatismo'] . "', " ;
	$query = $query . "'" . $post['igrejaOrigemNome']         . "', " ;
	$query = $query . "'" . $post['igrejaOrigemEstado']       . "', " ;
    $query = $query . "'" . $post['igrejaOrigemCidade']       . "', " ;
    $query = $query . "'" . $post['igrejaOrigemEndereco']     . "', " ;
	$query = $query . "'" . $post['igrejaOrigemNumero']       . "', " ;
	$query = $query . "'" . $post['igrejaOrigemComplemento']  . "', " ;
	$query = $query . "'" . $post['igrejaOrigemBairro']       . "', " ;
    $query = $query . "'" . $post['igrejaOrigemCep']          . "', " ;
    $query = $query . "'" . $post['igrejaOigemTelefone']      . "', " ;
    $query = $query . "'" . $post['igrejaOrigemAtividades']   . "', " ;
    $query = $query . "'" . $post['igrejaOrigemDizimista']    . "', " ;
    $query = $query . "'" . $post['dizimistaFiel']            . "', " ;
    $query = $query . "'" . $post['donsConhece']              . "', " ;
    $query = $query . "'" . $post['donsPratica']              . "', " ;
    $query = $query . "'" . $post['modoAdmissao']             . "', " ;
    $query = $query . "'" . $post['dataEntrada']              . "', " ;
    $query = $query . "'" . $post['atividades']               . "', " ;
    $query = $query . "null, " ;
    $query = $query . "null, " ;
    $query = $query . "null, " ;
    $query = $query . "null, " ;
    $query = $query . "'1')";
    
    //echo $query;
	mysqli_query($con, $query) or die (mysqli_error());
}

function consultaMembros($con)
{
   $membros = [];

   $query = "SELECT * FROM pessoas";
   $result = mysqli_query($con, $query);

   while ($membro = mysqli_fetch_assoc($result)) {
      array_push($membros, $membro);
   }

   return $membros;
}

function consultaMembrosPorID($con, $idMembros)
{
  $query = "SELECT * FROM pessoas WHERE idPessoas = {$idMembros}";
  $resultado = mysqli_query($con, $query);
  $membro = mysqli_fetch_assoc($resultado);

  return $membro;
}

function ConsultaMembrosParaCadastro($con)
{
   $membros = [];

   $query = "SELECT nome, idPessoas FROM Pessoas WHERE tipoPessoa = 1";
   $result = mysqli_query($con, $query);

   while ($membro = mysqli_fetch_assoc($result)) {
      array_push($membros, $membro);
   }

   return $membros;
}

function removeMembro($con, $id)
{
    $query = "DELETE FROM pessoas WHERE idPessoas = {$id}";
    return mysqli_query($con, $query);
}


function inserirFamiliares($con,$post = [])
{
    $query = "SELECT * FROM pessoas WHERE cpf = '".$post['cpf']."'";
    $resultado = mysqli_query($con, $query);
    $membroId = mysqli_fetch_assoc($resultado);
    $idPessoa = $membroId['idPessoas'];
    if($post['dataNascimentoConjuge']==='' && $post['dataCasamento']===''){
        $query = "insert into familiares values (null,";
        $query = $query . "'" . $post['nomePai']                  . "', " ;
	    $query = $query . "'" . $post['paiEvangelico']            . "', " ;
	    $query = $query . "'" . $post['igrejaPai']                . "', " ;
	    $query = $query . "'" . $post['nomeMae']                  . "', " ;
	    $query = $query . "'" . $post['maeEvangelica']            . "', " ;
	    $query = $query . "'" . $post['igrejaMae']                . "', " ;
	    $query = $query . "'" . $post['nomeConjuge']              . "', " ;
	    $query = $query . "'" . $post['conjugeEvangelico']        . "', " ;
	    $query = $query . "'" . $post['igrejaConjuge']            . "', " ;
 	    $query = $query . "null, " ;
	    $query = $query . "null, " ;
        $query = $query . "'" . $idPessoa                         . "')" ;
        //echo $query;
        mysqli_query($con, $query) or die (mysqli_error());
    }else{
        $query = "insert into familiares values (null,";
        $query = $query . "'" . $post['nomePai']                  . "', " ;
	    $query = $query . "'" . $post['paiEvangelico']            . "', " ;
	    $query = $query . "'" . $post['igrejaPai']                . "', " ;
	    $query = $query . "'" . $post['nomeMae']                  . "', " ;
	    $query = $query . "'" . $post['maeEvangelica']            . "', " ;
	    $query = $query . "'" . $post['igrejaMae']                . "', " ;
	    $query = $query . "'" . $post['nomeConjuge']              . "', " ;
	    $query = $query . "'" . $post['conjugeEvangelico']        . "', " ;
	    $query = $query . "'" . $post['igrejaConjuge']            . "', " ;
 	    $query = $query . "'".$post['dataNascimentoConjuge']      . "', " ;
	    $query = $query . "'" . $post['dataCasamento']            . "', " ;
        $query = $query . "'" . $idPessoa                         . "')" ;
        //echo $query;
        mysqli_query($con, $query) or die (mysqli_error());
    }
}


function AlterarMembro($con,$post = [])
{
    
    $id = $_GET['id'];
    
//MEMBROS INCIO
    $query =  "UPDATE  pessoas SET tipoPessoa = '{$post['tipoPessoa']}' ,
                nome = '{$post['nome']}',
                sexo = '{$post['sexo']}',
                dataNascimento = '{$post['nascimento']}',
                cidadeNascimento = '{$post['nascimentoCidade']}',
                estadoNascimento = '{$post['nascimentoEstado']}',
                rg = '{$post['rg']}',
                orgaoExpedidor = '{$post['orgaoExpedidor']}',
                cpf = '{$post['cpf']}',
                estadoCivil = '{$post['estadoCivil']}',
                tipoSanguineo = '{$post['tipoSanguineo']}',
                fatorRh = '{$post['fatorRh']}',
                escolaridade = '{$post['escolaridade']}',
                logradouroEndereco = '{$post['endereco']}',
                numeroEndereco = '{$post['numero']}',
                complementoEndereco = '{$post['complemento']}',
                bairroEndereco = '{$post['bairro']}',
                cidadeEndereco = '{$post['cidade']}',
                EstadoEndereco = '{$post['estado']}',
                cepEndereco = '{$post['cep']}',
                emailPessoal = '{$post['emailPessoal']}',
                telefone = '{$post['telefone']}',
                celular = '{$post['celular']}',
                profissao = '{$post['profissao']}',
                nomeEmpresa = '{$post['empresaNome']}',
                enderecoEmpresa = '{$post['empresaEndereco']}',
                numeroEmpresa = '{$post['empresaNumero']}',
                complementoEmpresa = '{$post['empresaComplemento']}',
                bairroEmpresa = '{$post['empresaBairro']}',
                cidadeEmpresa = '{$post['empresaCidade']}',
                estadoEmpresa = '{$post['empresaEstado']}',
                cepEmpresa = '{$post['empresaCep']}',
                cargoEmpresa = '{$post['empresaCargo']}',
                nomeIgrejaBatismo = '{$post['igrejaBatismoNomeIgreja']}',
                dataBatismo = '{$post['igrejaBatismoDataBatismo']}',
                igrejaOrigem = '{$post['igrejaOrigemNome']}',
                estadoIgrejaOrigem = '{$post['igrejaOrigemEstado']}',
                cidadeIgrejaOrigem = '{$post['igrejaOrigemCidade']}',
                logradouroIgrejaOrigem = '{$post['igrejaOrigemEndereco']}',
                numeroIgrejaOrigem = '{$post['igrejaOrigemNumero']}',
                complementoIgrejaOrigem = '{$post['igrejaOrigemComplemento']}',
                bairroIgrejaOrigem = '{$post['igrejaOrigemBairro']}',
                cepIgrejaOrigem = '{$post['igrejaOrigemCep']}',
                telefoneIgrejaOigem = '{$post['igrejaOigemTelefone']}',
                atividadesIgrejaOrigem = '{$post['igrejaOrigemAtividades']}',
                dizimistIgrejaOrigem = '{$post['igrejaOrigemDizimista']}',
                dizimistaIgrejaAtual = '{$post['dizimistaFiel']}',
                conheceDons = '{$post['donsConhece']}',
                praticDons = '{$post['donsPratica']}',
                modoAdmissao = '{$post['modoAdmissao']}',
                dataAdmissao = '{$post['dataEntrada']}',
                atividadesIBG2 = '{$post['atividades']}',
                modoSaida = 'null',
                dateSaida = 'null',
                modoReadmissaoIBG2 = 'null',
                dataReadmissao = 'null',
                statusPessoa = 1
                WHERE idPessoas = {$id}";
 
//    echo '<pre>'; 
//    var_dump($query) or die;
//        
return mysqli_query($con, $query);
	//mysqli_query($con, $query) or die (mysqli_error());
}
