<?php
require_once 'conexao.php';

function cadastraUsuario($con, $nome, $senha, $perfil, $FKpessoa)
{
    $usuario=buscaUsuario1($con, $nome);
    if(empty($usuario)){
        $senhaMd5 = MD5($senha);
        $nome = mysqli_real_escape_string($con, $nome);
        $query = "INSERT INTO usuario (nome, senha, perfil, FKPessoas)
                    values ('{$nome}', '{$senhaMd5}', '{$perfil}', '{$FKpessoa}') ";
	    return mysqli_query($con, $query);
    }
}

function buscaUsuario1($con, $nome)
{
    $nome = mysqli_real_escape_string($con, $nome);
    $query = "SELECT * FROM usuario WHERE nome = '{$nome}'";
    $resultado = mysqli_query($con, $query);
    $usuario = mysqli_fetch_assoc($resultado);

    return $usuario;
}

function buscaUsuario($con, $nome, $senha)
{
    $senhaMd5 = MD5($senha);
    $nome = mysqli_real_escape_string($con, $nome);
    $query = "SELECT * FROM usuario WHERE nome = '{$nome}' AND senha = '{$senhaMd5}'";
    $resultado = mysqli_query($con, $query);
    $usuario = mysqli_fetch_assoc($resultado);
    
    return $usuario;
}

function buscaUsuario2($con, $nome, $senha)
{
    $senhaMd5 = MD5($senha);
    $nome = mysqli_real_escape_string($con, $nome);
    $query = "SELECT * FROM usuario WHERE nome = '{$nome}' AND senha = '{$senhaMd5}'";
    $resultado = mysqli_query($con, $query);
    $usuario = mysqli_num_rows($resultado);

    return $usuario;
}

function buscaMembrosParaCadastro($con)
{
    $membros=[];
    $query = "select idPessoas, nome from pessoas where tipoPessoa = 1";
    $resultado=mysqli_query($con,$query);

    while($membro=mysqli_fetch_assoc($resultado)){
        array_push($membros,$membro);
    }
return $membros;
}

function buscaTudoPerfil($con){
    $perfis=[];
    $query="select * from perfil";
    $resultado=mysqli_query($con,$query);

    while($perfil=mysqli_fetch_assoc($resultado)){
        array_push($perfis,$perfil);
    }

    return $perfis;
}