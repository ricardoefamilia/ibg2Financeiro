<?php

require_once 'conexao.php';

function buscaCursosDoMembro($con, $FKIdMembro)
{
    $cursos = [];
    $query = "SELECT * FROM cursosrealizados WHERE FKPessoas = {$FKIdMembro}";
    $resultado = mysqli_query($con, $query);

    while ($curso = mysqli_fetch_assoc($resultado)) {
        array_push($cursos, $curso);
    }

    return $cursos;
}

function buscaCursosPorId($con, $id)
{
    $query = "SELECT * from cursosrealizados where idCursosRealizados = {$id}";
    $resultado = mysqli_query($con, $query);
    $curso = mysqli_fetch_assoc($resultado);
    return $curso;
}

function alteraCurso($con, $curso, $titulacao, $instituicao, $idMembro)
{
    //var_dump($idMembro) or die;
    
    $query = "UPDATE cursosrealizados SET curso = '{$curso}', titulacao = '{$titulacao}', instituicao = '{$instituicao}', FKPessoas = '{$idMembro}'
    WHERE idCursosRealizados = {$idMembro}";

    return mysqli_query($con, $query);
}

function removeCursoPorId($con, $id)
{
    $query = "DELETE FROM cursosrealizados WHERE idCursosRealizados = {$id}";
    return mysqli_query($con, $query);
}
