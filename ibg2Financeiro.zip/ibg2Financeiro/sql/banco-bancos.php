<?php
require_once 'conexao.php';

function buscaBancos($con)
{
    $bancos = [];
    $query = "SELECT * FROM sistemabancos";
    $resultado = mysqli_query($con, $query);

    
    while ($banco = mysqli_fetch_assoc($resultado)) {
        array_push($bancos, $banco);
    }

    return $bancos;

}
