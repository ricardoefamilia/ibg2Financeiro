<?php

    require_once 'conexao.php';

    function cadastraVisitante($con,
    $nome,
    $data,
    $dataNascimento,
    $telefone,
    $celular,
    $endereco,
    $cep,
    $email,
    $suaVisita,
    $tipo,
    $faixaEtaria,
    $minhaDecisao,
    $meuInteresse,
    $precisoOrientacao,
    $pedidoOracao,
    $conheciIBG2,
    $opiniaoMusica,
    $opiniaoRecepcao,
    $opiniaoPregacao)
    {
        if(empty($dataNascimento)){
            $query = "insert into visitantes (nome,data,dataNascimento,telefone,celular,endereco,cep,email,suaVisita,tipo,faixaEtaria,minhaDecisao,meuInteresse,precisoOrientacao,pedidoOracao,conheciIBG2,opiniaoMusica,opiniaoRecepcao,opiniaoPregacao) values(
            '{$nome}',
            '{$data}',
            null,
            '{$telefone}',
            '{$celular}',
            '{$endereco}',
            '{$cep}',
            '{$email}',
            '{$suaVisita}',
            '{$tipo}',
            '{$faixaEtaria}',
            '{$minhaDecisao}',
            '{$meuInteresse}',
            '{$precisoOrientacao}',
            '{$pedidoOracao}',
            '{$conheciIBG2}',
            '{$opiniaoMusica}',
            '{$opiniaoRecepcao}',
            '{$opiniaoPregacao}')";
        }else{
            $query = "insert into visitantes (nome,data,dataNascimento,telefone,celular,endereco,cep,email,suaVisita,tipo,faixaEtaria,minhaDecisao,meuInteresse,precisoOrientacao,pedidoOracao,conheciIBG2,opiniaoMusica,opiniaoRecepcao,opiniaoPregacao) values(
            '{$nome}',
            '{$data}',
            '{$dataNascimento}',
            '{$telefone}',
            '{$celular}',
            '{$endereco}',
            '{$cep}',
            '{$email}',
            '{$suaVisita}',
            '{$tipo}',
            '{$faixaEtaria}',
            '{$minhaDecisao}',
            '{$meuInteresse}',
            '{$precisoOrientacao}',
            '{$pedidoOracao}',
            '{$conheciIBG2}',
            '{$opiniaoMusica}',
            '{$opiniaoRecepcao}',
            '{$opiniaoPregacao}')";
        }

        return mysqli_query($con, $query);
    }

    function buscaVisitantes($con)
    {
        $visitantes = [];
        $query = "SELECT idVisitantes,nome,data FROM visitantes";
        $resultado = mysqli_query($con, $query);

        while ($visitante = mysqli_fetch_assoc($resultado)) {
            array_push($visitantes, $visitante);
        }

        return $visitantes;
    }

    function buscaVisitantesPorID($con, $id)
    {
        $query = "SELECT * FROM visitantes WHERE idVisitantes = {$id}";
        $resultado = mysqli_query($con, $query);
        $visitante = mysqli_fetch_assoc($resultado);

        return $visitante;
    }

    function alteraVisitante($con,
    $nome,
    $data,
    $dataNascimento,
    $telefone,
    $celular,
    $endereco,
    $cep,
    $email,
    $suaVisita,
    $tipo,
    $faixaEtaria,
    $minhaDecisao,
    $meuInteresse,
    $precisoOrientacao,
    $pedidoOracao,
    $conheciIBG2,
    $opiniaoMusica,
    $opiniaoRecepcao,
    $opiniaoPregacao,
    $id)
    {
        if(empty($dataNascimento)){
           $query = "UPDATE visitantes SET nome = '$nome', data ='$data',
    	   dataNascimento = null,telefone='$telefone',	celular='$celular',
    	   endereco = '$endereco', cep = '$cep', email = '$email', suaVisita = '$suaVisita',
    	   tipo = '$tipo',faixaEtaria = '$faixaEtaria', minhaDecisao = '$minhaDecisao',meuInteresse = '$meuInteresse',
    	   precisoOrientacao = '$precisoOrientacao',pedidoOracao = '$pedidoOracao', conheciIBG2 = '$conheciIBG2',
    	   opiniaoMusica = '$opiniaoMusica', opiniaoRecepcao = '$opiniaoRecepcao', opiniaoPregacao = '$opiniaoPregacao' WHERE idVisitantes = '$id'";
        }else{
            $query = "UPDATE visitantes SET nome = '$nome', data ='$data',
    	   dataNascimento = '$dataNascimento',telefone='$telefone',	celular='$celular',
    	   endereco = '$endereco', cep = '$cep', email = '$email', suaVisita = '$suaVisita',
    	   tipo = '$tipo',faixaEtaria = '$faixaEtaria', minhaDecisao = '$minhaDecisao',meuInteresse = '$meuInteresse',
    	   precisoOrientacao = '$precisoOrientacao',pedidoOracao = '$pedidoOracao', conheciIBG2 = '$conheciIBG2',
    	   opiniaoMusica = '$opiniaoMusica', opiniaoRecepcao = '$opiniaoRecepcao', opiniaoPregacao = '$opiniaoPregacao' WHERE idVisitantes = '$id'";
        }
        
        return mysqli_query($con, $query);       

    }

    function removeVisitante($con, $id)
    {
        $query = "DELETE FROM visitantes WHERE idVisitantes = {$id}";
        return mysqli_query($con, $query);
    }
