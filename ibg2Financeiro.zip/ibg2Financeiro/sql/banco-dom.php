<?php

   require_once 'conexao.php';

   function adicionaDom($con, $dom)
   {
       $query = "INSERT INTO dons (nomeDom) values ('{$dom}')";
       return mysqli_query($con, $query);
   }

   function listaDons($con)
   {
       $dons = [];
       $query = "SELECT * FROM dons";
       $result = mysqli_query($con, $query);

       while ($dom = mysqli_fetch_assoc($result)) {
           array_push($dons, $dom);
       }

       return $dons;
   }
