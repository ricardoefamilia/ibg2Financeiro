<?php
  $host    = "localhost";
  $user    = "root";
  $password= "";
  $db      = "ibg2_financeiro";

//  $con =  mysqli_connect('localhost', 'root', 'office', 'financaibg2');
  $con =  mysqli_connect($host, $user, $password, $db);
  mysqli_set_charset($con, 'utf8');
