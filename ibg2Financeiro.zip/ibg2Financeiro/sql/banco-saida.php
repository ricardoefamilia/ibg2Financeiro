<?php

   require_once 'conexao.php';
   
   
   function buscaSaidas($con) {
    $saidas = [];
    $query = "SELECT * FROM saida WHERE especie = 1 AND confirmado = 0 ORDER BY dataSaida DESC";
    $result = mysqli_query($con, $query);

    while ($saida = mysqli_fetch_assoc($result)) {
        array_push($saidas, $saida);
    }

    return $saidas;
}
   

function buscaSaidasDeposito($con) {
    $saidasDeposito = [];
    $query = "SELECT * FROM saida WHERE especie = 2 AND confirmado = 0 ORDER BY dataSaida DESC";
    $result = mysqli_query($con, $query);

    while ($saidaDeposito = mysqli_fetch_assoc($result)) {
        array_push($saidasDeposito, $saidaDeposito);
    }

    return $saidasDeposito;
}


function buscaSaidasCheque($con) {
    $saidasCheque = [];
    $query = "SELECT * FROM saida WHERE especie = 3 AND confirmado = 0 ORDER BY dataSaida DESC";
    $result = mysqli_query($con, $query);

    while ($saidaCheque = mysqli_fetch_assoc($result)) {
        array_push($saidasCheque, $saidaCheque);
    }

    return $saidasCheque;
}

   
   function adicionaSaida($con, $value)
   {
//       
      
       if(isset($value['valor'])){
           $valorTradado = str_replace(',','.',str_replace('.','',$value['valor']));
            $value['valor'] = mysqli_real_escape_string($con, $valorTradado);
        }
       if(isset($value['numero-cheque'])){
            $value['numero-cheque'] = mysqli_real_escape_string($con, $value['numero-cheque']);
        }
       if(isset($value['nome-banco'])){
            $value['nome-banco'] = mysqli_real_escape_string($con, $value['nome-banco']);
        }
       if(isset($value['numero-comprovante'])){
            $value['numero-comprovante'] = mysqli_real_escape_string($con, $value['numero-comprovante']);
        }
       if(isset($value['agencia'])){
            $value['agencia'] = mysqli_real_escape_string($con, $value['agencia']);
        }
       if(isset($value['conta'])){
            $value['conta'] = mysqli_real_escape_string($con, $value['conta']);
        }
        
        if(isset($value['destinacao'])){
            $value['destinacao'] = mysqli_real_escape_string($con, $value['destinacao']);
        }
        
        if(isset($value['obs'])){
            $value['obs'] = mysqli_real_escape_string($con, $value['obs']);
        }
        
         	 	 

       if ($value['especie'] === 1) {
           $query = "INSERT INTO saida
           (valor, especie, nrCheque, bancoCheque, nrTransacaoComprovante, agencia, conta, dataSaida,destinacao,observacao,confirmado ) values (
                  '" . $value['valor'] .  "' ,
                  '" . $value['especie'] . "' ,
                  '" . "-" . "' ,
                  '" . "-" . "' ,
                  '" . "-" . "' ,
                  '" . "-" . "' ,
                  '" . "-" . "' ,
                  '" . $value['data'] . "' ,
                  '" . $value['destinacao'] . "' ,
                  '" . $value['obs'] . "' ,
                  0
               )";
                    
           return mysqli_query($con, $query);
       }

       if ($value['especie'] === 2) {
           
           $query = "INSERT INTO saida
            (valor, especie, nrCheque, bancoCheque, nrTransacaoComprovante, agencia, conta, dataSaida,destinacao,observacao,confirmado) values (
                  '" . $value['valor'] .  "' ,
                  '" . $value['especie'] . "' ,
                  '" . "-" . "' ,
                  '" . "-" . "' ,
                  '" . $value['numero-comprovante'] . "' ,
                  '" . "-" . "' ,
                  '" . "-" . "' ,
                  '" . $value['data'] . "' ,
                  '" . $value['destinacao'] . "' ,
                  '" . $value['obs'] . "' ,
                  0
               )";
        
           return mysqli_query($con, $query);
       }

       if ($value['especie'] === 3) {
           $query = "INSERT INTO saida
           (valor, especie, nrCheque, bancoCheque, nrTransacaoComprovante, agencia, conta, dataSaida,destinacao,observacao,confirmado) values (
                  '" . $value['valor'] .  "' ,
                  '" . $value['especie'] . "' ,
                  '" . $value['numero-cheque'] . "' ,
                  '" . $value['nome-banco'] . "' ,
                  '" . "-" . "' ,
                  '" . $value['agencia'] . "' ,
                  '" . $value['conta'] . "' ,
                  '" . $value['data'] . "' ,
                  '" . $value['destinacao'] . "' ,
                  '" . $value['obs'] . "' ,
                  0
               )";
           
           
           //var_dump($query) or die;
           
           return mysqli_query($con, $query);
       }
   }
   
   function alteraSaidas($con, $saidas) {

    $contador = count($saidas['checkbox']);

    for ($i = 0; $i < $contador; $i++) {

        $query = "UPDATE saida set confirmado = '1' WHERE idSaida = {$saidas['checkbox'][$i]}";

        mysqli_query($con, $query);
    }

    return true;
}
