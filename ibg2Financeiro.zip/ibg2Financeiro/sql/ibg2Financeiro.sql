-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 11-Jun-2018 às 15:42
-- Versão do servidor: 10.1.30-MariaDB
-- PHP Version: 5.6.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ibg2_financeiro`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cursosrealizados`
--

CREATE TABLE `cursosrealizados` (
  `idCursosRealizados` int(11) NOT NULL,
  `curso` varchar(255) NOT NULL,
  `titulacao` varchar(255) NOT NULL,
  `instituicao` varchar(255) DEFAULT NULL,
  `FKPessoas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `destinacao`
--

CREATE TABLE `destinacao` (
  `iddestinacao` int(11) NOT NULL,
  `descricao` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `dons`
--

CREATE TABLE `dons` (
  `idDom` int(11) NOT NULL,
  `nomeDom` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `entradas`
--

CREATE TABLE `entradas` (
  `idEntradas` int(11) NOT NULL,
  `FKdestinacao` int(11) NOT NULL,
  `FKPessoa_Ofertou` int(11) NOT NULL,
  `FKUsuarioLancou` int(11) NOT NULL,
  `FKUsuarioConferiu` int(11) NOT NULL,
  `valor` decimal(18,2) NOT NULL,
  `especie` int(5) NOT NULL,
  `nrCheque` varchar(45) DEFAULT NULL,
  `bancoCheque` varchar(45) DEFAULT NULL,
  `nrDepositoComprovante` varchar(45) DEFAULT NULL,
  `agencia` varchar(45) DEFAULT NULL,
  `conta` varchar(45) DEFAULT NULL,
  `dataLancamentoEntrada` date NOT NULL,
  `horaLancamentoEntrada` time NOT NULL,
  `confirmado` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `familiares`
--

CREATE TABLE `familiares` (
  `idFamiliares` int(11) NOT NULL,
  `nomePai` varchar(255) DEFAULT NULL,
  `paiEvangelico` tinyint(1) DEFAULT NULL,
  `igrejaPai` varchar(255) DEFAULT NULL,
  `nomeMae` varchar(255) DEFAULT NULL,
  `maeEvangelica` tinyint(1) DEFAULT NULL,
  `igrejaMae` varchar(255) DEFAULT NULL,
  `nomeConjuge` varchar(255) DEFAULT NULL,
  `conjugeEvangelico` tinyint(1) DEFAULT NULL,
  `igrejaConjuge` varchar(255) DEFAULT NULL,
  `dataNascimentoConjuge` date DEFAULT NULL,
  `dataCasamento` date DEFAULT NULL,
  `fkPessoa` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pessoas`
--

CREATE TABLE `pessoas` (
  `idPessoas` int(11) NOT NULL,
  `tipoPessoa` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `sexo` int(11) NOT NULL,
  `dataNascimento` date NOT NULL,
  `cidadeNascimento` varchar(255) NOT NULL,
  `estadoNascimento` varchar(255) NOT NULL,
  `rg` varchar(255) NOT NULL,
  `orgaoExpedidor` varchar(255) NOT NULL,
  `cpf` varchar(255) NOT NULL,
  `estadoCivil` varchar(255) NOT NULL,
  `tipoSanguineo` varchar(2) NOT NULL,
  `fatorRh` varchar(255) DEFAULT NULL,
  `escolaridade` varchar(255) NOT NULL,
  `logradouroEndereco` varchar(255) DEFAULT NULL,
  `numeroEndereco` varchar(255) DEFAULT NULL,
  `complementoEndereco` varchar(255) DEFAULT NULL,
  `bairroEndereco` varchar(2555) DEFAULT NULL,
  `cidadeEndereco` varchar(255) DEFAULT NULL,
  `EstadoEndereco` varchar(255) DEFAULT NULL,
  `cepEndereco` varchar(255) DEFAULT NULL,
  `emailPessoal` varchar(255) DEFAULT NULL,
  `telefone` varchar(255) DEFAULT NULL,
  `celular` varchar(255) DEFAULT NULL,
  `profissao` varchar(45) DEFAULT NULL,
  `nomeEmpresa` varchar(45) DEFAULT NULL,
  `enderecoEmpresa` varchar(45) DEFAULT NULL,
  `numeroEmpresa` varchar(255) DEFAULT NULL,
  `complementoEmpresa` varchar(255) DEFAULT NULL,
  `bairroEmpresa` varchar(255) DEFAULT NULL,
  `cidadeEmpresa` varchar(255) DEFAULT NULL,
  `estadoEmpresa` varchar(255) DEFAULT NULL,
  `cepEmpresa` varchar(45) DEFAULT NULL,
  `cargoEmpresa` varchar(45) DEFAULT NULL,
  `nomeIgrejaBatismo` varchar(45) DEFAULT NULL,
  `dataBatismo` date DEFAULT NULL,
  `igrejaOrigem` varchar(45) DEFAULT NULL,
  `estadoIgrejaOrigem` varchar(45) DEFAULT NULL,
  `cidadeIgrejaOrigem` varchar(45) DEFAULT NULL,
  `logradouroIgrejaOrigem` varchar(255) DEFAULT NULL,
  `numeroIgrejaOrigem` varchar(255) DEFAULT NULL,
  `complementoIgrejaOrigem` varchar(255) NOT NULL,
  `bairroIgrejaOrigem` varchar(255) DEFAULT NULL,
  `cepIgrejaOrigem` varchar(45) DEFAULT NULL,
  `telefoneIgrejaOigem` varchar(45) DEFAULT NULL,
  `atividadesIgrejaOrigem` varchar(45) DEFAULT NULL,
  `dizimistIgrejaOrigem` tinyint(1) DEFAULT NULL,
  `dizimistaIgrejaAtual` tinyint(1) DEFAULT NULL,
  `conheceDons` tinyint(1) DEFAULT NULL,
  `praticDons` tinyint(1) DEFAULT NULL,
  `modoAdmissao` varchar(45) NOT NULL,
  `dataAdmissao` date NOT NULL,
  `atividadesIBG2` varchar(255) DEFAULT NULL,
  `modoSaida` varchar(45) DEFAULT NULL,
  `dateSaida` date DEFAULT NULL,
  `modoReadmissaoIBG2` varchar(45) DEFAULT NULL,
  `dataReadmissao` date DEFAULT NULL,
  `statusPessoa` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pessoas_has_dons`
--

CREATE TABLE `pessoas_has_dons` (
  `Pessoas_idPessoas` int(11) NOT NULL,
  `Dons_idDom` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `saida`
--

CREATE TABLE `saida` (
  `idSaida` int(11) NOT NULL,
  `valor` decimal(18,2) NOT NULL,
  `especie` int(1) DEFAULT NULL,
  `nrCheque` varchar(45) DEFAULT NULL,
  `bancoCheque` varchar(45) DEFAULT NULL,
  `nrTransacaoComprovante` varchar(45) DEFAULT NULL,
  `agencia` varchar(45) DEFAULT NULL,
  `conta` varchar(45) DEFAULT NULL,
  `dataSaida` date NOT NULL,
  `destinacao` varchar(255) NOT NULL,
  `observacao` text NOT NULL,
  `confirmado` tinyint(1) NOT NULL,
  `tesoureiro` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `sistemabancos`
--

CREATE TABLE `sistemabancos` (
  `nrBanco` char(10) NOT NULL,
  `banco` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `nome` varchar(45) NOT NULL,
  `senha` varchar(64) NOT NULL,
  `perfil` int(11) NOT NULL,
  `FKPessoas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `visitantes`
--

CREATE TABLE `visitantes` (
  `idVisitantes` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `data` date NOT NULL,
  `dataNascimento` date DEFAULT NULL,
  `telefone` varchar(255) DEFAULT NULL,
  `celular` varchar(255) DEFAULT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `cep` int(11) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `suaVisita` int(11) NOT NULL,
  `tipo` varchar(24) NOT NULL,
  `faixaEtaria` varchar(24) NOT NULL,
  `minhaDecisao` varchar(255) DEFAULT NULL,
  `meuInteresse` varchar(255) DEFAULT NULL,
  `precisoOrientacao` varchar(255) DEFAULT NULL,
  `pedidoOracao` varchar(255) DEFAULT NULL,
  `conheciIBG2` varchar(255) DEFAULT NULL,
  `opiniaoMusica` varchar(24) DEFAULT NULL,
  `opiniaoRecepcao` varchar(24) DEFAULT NULL,
  `opiniaoPregacao` varchar(24) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cursosrealizados`
--
ALTER TABLE `cursosrealizados`
  ADD PRIMARY KEY (`idCursosRealizados`),
  ADD KEY `fk_CursosRealizados_Pessoas1_idx` (`FKPessoas`);

--
-- Indexes for table `destinacao`
--
ALTER TABLE `destinacao`
  ADD PRIMARY KEY (`iddestinacao`);

--
-- Indexes for table `dons`
--
ALTER TABLE `dons`
  ADD PRIMARY KEY (`idDom`);

--
-- Indexes for table `entradas`
--
ALTER TABLE `entradas`
  ADD PRIMARY KEY (`idEntradas`),
  ADD KEY `fk_Entradas_Destinacao1_idx` (`FKdestinacao`),
  ADD KEY `fk_Entradas_PessoasOfertou1_idx` (`FKPessoa_Ofertou`),
  ADD KEY `FKUsuarioLancou` (`FKUsuarioLancou`),
  ADD KEY `FKUsuarioConferiu` (`FKUsuarioConferiu`);

--
-- Indexes for table `familiares`
--
ALTER TABLE `familiares`
  ADD PRIMARY KEY (`idFamiliares`),
  ADD KEY `fkPessoa` (`fkPessoa`);

--
-- Indexes for table `pessoas`
--
ALTER TABLE `pessoas`
  ADD PRIMARY KEY (`idPessoas`);

--
-- Indexes for table `pessoas_has_dons`
--
ALTER TABLE `pessoas_has_dons`
  ADD PRIMARY KEY (`Pessoas_idPessoas`,`Dons_idDom`),
  ADD KEY `fk_Pessoas_has_Dons_Dons1_idx` (`Dons_idDom`),
  ADD KEY `fk_Pessoas_has_Dons_Pessoas1_idx` (`Pessoas_idPessoas`);

--
-- Indexes for table `saida`
--
ALTER TABLE `saida`
  ADD PRIMARY KEY (`idSaida`),
  ADD KEY `fk_saida_pessoas1_idx` (`tesoureiro`);

--
-- Indexes for table `sistemabancos`
--
ALTER TABLE `sistemabancos`
  ADD PRIMARY KEY (`nrBanco`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`nome`),
  ADD KEY `fk_usuario_pessoas1_idx` (`FKPessoas`);

--
-- Indexes for table `visitantes`
--
ALTER TABLE `visitantes`
  ADD PRIMARY KEY (`idVisitantes`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cursosrealizados`
--
ALTER TABLE `cursosrealizados`
  MODIFY `idCursosRealizados` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `destinacao`
--
ALTER TABLE `destinacao`
  MODIFY `iddestinacao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `dons`
--
ALTER TABLE `dons`
  MODIFY `idDom` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `entradas`
--
ALTER TABLE `entradas`
  MODIFY `idEntradas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `familiares`
--
ALTER TABLE `familiares`
  MODIFY `idFamiliares` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pessoas`
--
ALTER TABLE `pessoas`
  MODIFY `idPessoas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `saida`
--
ALTER TABLE `saida`
  MODIFY `idSaida` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `visitantes`
--
ALTER TABLE `visitantes`
  MODIFY `idVisitantes` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `cursosrealizados`
--
ALTER TABLE `cursosrealizados`
  ADD CONSTRAINT `fk_CursosRealizados_Pessoas1` FOREIGN KEY (`FKPessoas`) REFERENCES `pessoas` (`idPessoas`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `entradas`
--
ALTER TABLE `entradas`
  ADD CONSTRAINT `entradas_ibfk_1` FOREIGN KEY (`FKUsuarioLancou`) REFERENCES `pessoas` (`idPessoas`),
  ADD CONSTRAINT `entradas_ibfk_2` FOREIGN KEY (`FKUsuarioConferiu`) REFERENCES `pessoas` (`idPessoas`),
  ADD CONSTRAINT `fk_Entradas_Destinacao1` FOREIGN KEY (`FKdestinacao`) REFERENCES `destinacao` (`iddestinacao`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Entradas_PessoasOfertou1` FOREIGN KEY (`FKPessoa_Ofertou`) REFERENCES `pessoas` (`idPessoas`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `familiares`
--
ALTER TABLE `familiares`
  ADD CONSTRAINT `familiares_ibfk_1` FOREIGN KEY (`fkPessoa`) REFERENCES `pessoas` (`idPessoas`);

--
-- Limitadores para a tabela `pessoas_has_dons`
--
ALTER TABLE `pessoas_has_dons`
  ADD CONSTRAINT `fk_Pessoas_has_Dons_Dons1` FOREIGN KEY (`Dons_idDom`) REFERENCES `dons` (`idDom`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Pessoas_has_Dons_Pessoas1` FOREIGN KEY (`Pessoas_idPessoas`) REFERENCES `pessoas` (`idPessoas`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `saida`
--
ALTER TABLE `saida`
  ADD CONSTRAINT `fk_saida_pessoas1` FOREIGN KEY (`tesoureiro`) REFERENCES `pessoas` (`idPessoas`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `fk_usuario_pessoas1` FOREIGN KEY (`FKPessoas`) REFERENCES `pessoas` (`idPessoas`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
