<?php
require_once 'conexao.php';

 function buscaEntradas($con) {
    $entradas = [];
    $query = "SELECT * FROM entradas WHERE especie = 1 AND confirmado = 0 ORDER BY dataLancamentoEntrada desc";
    $result = mysqli_query($con, $query);

    while ($entrada = mysqli_fetch_assoc($result)) {
        array_push($entradas, $entrada);
    }

    return $entradas;
}


function buscaEntradasDeposito($con) {
    $entradasDeposito = [];
    $query = "SELECT * FROM entradas WHERE especie = 2 AND confirmado = 0 ORDER BY dataLancamentoEntrada desc";
    $result = mysqli_query($con, $query);

    while ($entradaDeposito = mysqli_fetch_assoc($result)) {
        array_push($entradasDeposito, $entradaDeposito);
    }

    return $entradasDeposito;
}


function buscaEntradasCheque($con) {
    $entradasCheque = [];
    $query = "SELECT * FROM entradas WHERE especie = 3 AND confirmado = 0 ORDER BY dataLancamentoEntrada desc";
    $result = mysqli_query($con, $query);

    while ($entradaCheque = mysqli_fetch_assoc($result)) {
        array_push($entradasCheque, $entradaCheque);
    }

    return $entradasCheque;
}

function alteraEntradas($con, $entradas) {

    $contador = count($entradas['checkbox']);

    for ($i = 0; $i < $contador; $i++) {

        $query = "UPDATE entradas set confirmado = '1' WHERE idEntradas = {$entradas['checkbox'][$i]}";

        mysqli_query($con, $query);
    }

    return true;
}
