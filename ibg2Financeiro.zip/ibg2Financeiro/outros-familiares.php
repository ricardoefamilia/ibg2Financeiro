<h3 class="page-header">Outros familiares</h3>
<div class="row">
   <div class="col-sm-12">

       <div class="table-responsive">

           <table class="table">

               <thead>
                   <tr>
                       <th>Nome</th>
                       <th>Parentesco</th>
                       <th>É evangélico?</th>
                       <th>É da IBG2?</th>
                       <th>Data de nascimento</th>
                   </tr>
               </thead>

               <tbody id="tabela-familiar">
                   <tr>
                       <td> <input type="text" name="nomeFamiliar[]" class="form-control"> </td>
                       <td> <input type="text" name="parentesco[]" class="form-control"> </td>
                       <td>
                         <select class="form-control" name="familiarEvangelico[]">
                             <option value="">Selecione...</option>
                             <option value="1">Sim</option>
                             <option value="2">Não</option>
                         </select>
                       </td>
                       <td>
                         <select class="form-control" name="familiarIBG2[]">
                             <option value="">Selecione...</option>
                             <option value="1">Sim</option>
                             <option value="2">Não</option>
                         </select>
                       </td>
                       <td> <input type="date" name="dataNascimentoFamiliar[]" class="form-control datepicker"> </td>
                   </tr>

               </tbody>

           </table>
       </div>

      <button type="button" id="add-familiar" class="btn btn-success pull-right">
         <span class="fa fa-plus"></span> Adicionar
      </button>

   </div>
</div>
