<?php

    require_once 'mostra-alerta.php';
    require_once 'sql/conexao.php';
    require_once 'sql/banco-visitante.php';

    $id = $_GET['id'];

    if (removeVisitante($con, $id)) {
        $_SESSION['warning'] = 'Visitante removido com sucesso';
        header('Location: form-visitante.php');
    }

    die();
