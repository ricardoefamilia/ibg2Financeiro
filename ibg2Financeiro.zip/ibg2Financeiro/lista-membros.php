<?php
require_once 'top.php';
require_once 'sql/banco-membros.php';

  $membros = consultaMembros($con);

?>




  <section class="container">

    <a href="form-membros.php" class="btn btn-success">
      <span class="fa fa-trash"></span>
      Cadastrar
    </a>

    <table class="table table-hover">
        <thead>
          <tr>
            <th>Nome</th>
            <th>E-mail</th>
            <th>Telefone</th>
            <th>Celular</th>
            <th>Ações</th>
          </tr>
        </thead>

        <tbody>
          <?php foreach ($membros as $membro): ?>
            <tr>
              <td><?=$membro['nome']?></td>
              <td><?=$membro['emailPessoal']?></td>
              <td><?=$membro['telefone']?></td>
              <td><?=$membro['celular']?></td>
              <td>

                <a type="button" class="btn btn-danger">
                  <span class="fa fa-trash"></span>
                  Remover
                </a>

                <a href="form-membro-alterar.php?id=<?=$membro['idPessoas']?>" class="btn btn-primary">
                  <span class="fa fa-trash"></span>
                  Alterar
                </a>

                <a type="button" class="btn btn-info">
                  <span class="fa fa-trash"></span>
                  Consultar
                </a>

                <a type="button" class="btn btn-warning">
                  <span class="fa fa-trash"></span>
                  Familiares
                </a>

              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>

    </table>
  </section>

<?php require_once 'footer.php' ?>
