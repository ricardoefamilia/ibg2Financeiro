<?php
    require_once 'top.php';
    require_once 'sql/banco-membros.php';

    $membros = consultaMembros($con);

    $idMembro = $_GET['id'];
?>




<section class="container">
    <h3 class="page-header">Outros familiares</h3>

       <form action="2.php" method="post">

            <input type="hidden" name="idMembro" value="<?=$idMembro?>">
            <table class="table table-hover">

                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Parentesco</th>
                        <th>É evangélico?</th>
                        <th>Data de nascimento</th>
                    </tr>
                </thead>

                <tbody id="tabela-familiar">
                    <tr>
                        <td> <input type="text" name="nomeFamiliar[]" class="form-control"> </td>
                        <td> <input type="text" name="parentesco[]" class="form-control"> </td>
                        <td>
                            <select class="form-control" name="familiarEvangelico[]">
                                <option value="">Selecione...</option>
                                <option value="1">Sim</option>
                                <option value="2">Não</option>
                            </select>
                        </td>
                        <td> <input type="date" name="dataNascimentoFamiliar[]" class="form-control datepicker"> </td>
                    </tr>

                </tbody>
            </table>
            <button type="button" id="add-familiar" class="btn btn-primary pull-right">
                <span class="fa fa-plus"></span> Adicionar
            </button>

    <h3 class="page-header">Outros familiares - Membro IBG2</h3>
       <table class="table table-hover">

           <thead>
               <tr>
                   <th>Nome</th>
                   <th>Parentesco</th>
                   <th>É evangélico?</th>
                   <th>Data de nascimento</th>
               </tr>
           </thead>

           <tbody id="tabela-familiar2">
               <tr>
                   <td> <input type="text" name="nomeFamiliar2[]" class="form-control"> </td>
                   <td> <input type="text" name="parentesco2[]" class="form-control"> </td>
                   <td>
                       <select class="form-control" name="familiarEvangelico2[]">
                           <option value="">Selecione...</option>
                           <option value="1">Sim</option>
                           <option value="2">Não</option>
                       </select>
                   </td>
                   <td> <input type="date" name="dataNascimentoFamiliar2[]" class="form-control datepicker"> </td>
               </tr>

           </tbody>
       </table>

        <button type="button" id="add-familiar2" class="btn btn-primary pull-right">
            <span class="fa fa-plus"></span> Adicionar
        </button>

        <button type="submit" class="btn btn-success">
            <span class="fa fa-check"></span> Concluir
        </button>
    </form>

</section>

<?php require_once 'footer.php' ?>

<script src="js/adiciona-familiar-ibg2.js"></script>
<script src="js/adiciona-familiar.js"></script>
