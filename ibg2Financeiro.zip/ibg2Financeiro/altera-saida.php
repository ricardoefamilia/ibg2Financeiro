<?php

   require_once 'sql/banco-saida.php';
   require_once 'mostra-alerta.php';
   
   //var_dump($_POST) or die;
   
if (isset($_POST['checkbox'])) {
       
       if (alteraSaidas($con, $_POST)) {
            $_SESSION['success'] = '<span class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span> Saida confirmada com sucesso';
            header('Location: form-saidas-listar.php');
        } else {
        echo mysqli_error($con);
        }

        
}else{
       $_SESSION['danger'] = '<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> Nenhuma saida selecionado';
       header('Location: form-saidas-listar.php');
   }
 
   die();
   
