<?php
   require_once 'sql/conexao.php';
   require_once 'sql/banco-destinacao.php';
   session_start();

      

  if (adicionaSaida($con, $_POST["data"] , $_POST["cheque-agencia"], $_POST["cheque-conta"], $_POST["destinacao"], $_POST["nrCheque"], $_POST["obs"], $_POST["nome-banco"], $_POST["valor"])) {
        $_SESSION['success'] = 'Saida cadastrada com sucesso!';
        header('Location: form-saida.php');
    }

    die();
