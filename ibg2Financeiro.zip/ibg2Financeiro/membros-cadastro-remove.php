<?php

    require_once 'sql/conexao.php';
    require_once 'sql/banco-membros.php';
    session_start();

$id = $_GET['id'];

if (removeMembro($con, $id)) {
    $_SESSION['warning'] = 'Membro removido com sucesso';
    header('Location: membros-cadastro-consulta.php');
} else {
    echo mysqli_error($con);
}
