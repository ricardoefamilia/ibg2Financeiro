   <script src="js/jquery.min.js"></script>
   <script src="js/jquery.maskedinput.js"></script>
   <script src="js/jquery.maskMoney.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <script src="js/bootstrap-multiselect.js"></script>
   <script src="js/main.js"></script>
   <script src="js/bootstrap-datepicker.min.js"></script>
   <script src="js/bootstrap-datepicker.pt-BR.min.js"></script>

   <script src="js/busca-cep.js"></script>  
   <script src="js/busca-cep2.js"></script>
   <script src="js/busca-cep3.js"></script>
   <script src="js/chosen.jquery.js"></script>
   <script src="js/prism.js"></script>
   <script src="js/init.js"></script>

   
   </body>
   
   
   <script>
       
       // Formatamos para reais e colocamos o prefixo R$
$(function(){
  $("#dinheiro").maskMoney({prefix:'R$ ', thousands:'.',decimal:','});
  $("#valor-deposito").maskMoney({prefix:'R$ ', thousands:'.',decimal:','});
  $("#valor-cheque").maskMoney({prefix:'R$ ', thousands:'.',decimal:','});
});
       
       </script>
</html>
