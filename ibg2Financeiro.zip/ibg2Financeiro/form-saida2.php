<?php
      require_once 'top.php';
      require_once 'mostra-alerta.php';
      require_once 'sql/banco-teste.php';
      require_once 'sql/banco-membros.php';
      require_once 'sql/banco-bancos.php';

      error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
      session_start();

      $bancos = buscaBancos($con);

//      echo '<pre>';
//      var_dump($_POST['epecie'])or die;
      
?>


   <section class="container margem-bottom">

      <?php
         mostraAlerta('danger');
         mostraAlerta('warning');
         mostraAlerta('success');
      ?>

      <div class="col-md-12">
            <h3 class="page-header text-center">Lançamento das Saidas</h3>
 <form method="post" action="">


      </div>

      <div class="row">
          <div class="col-md-12">



              <!-- CHEQUE -->
              <div class="col-md-5">

                  <div class="col-md-12">
                      <div class="form-group">
                          <label for="numero-cheque">Data da saida</label>
                          <div class="input-group">
                              <span class="input-group-addon">
                                  <i class="fa fa-calendar"></i>
                              </span>
                              <input type="text" class="form-control datepicker" name="data" id="dataS" >
                          </div>
                      </div>
                  </div>



                  <div class="col-md-6">
                      <div class="form-group">
                          <label for="nome-banco">Agência</label>
                          <input type="text" class="form-control" name="cheque-agencia" id="cheque-agencia" >
                      </div>
                  </div>

                  <div class="col-md-6">
                      <div class="form-group">
                          <label for="nome-banco">Conta</label>
                          <input type="text" class="form-control" name="cheque-conta" id="cheque-conta" >
                      </div>
                  </div>


                  <div class="col-md-12">
                      <div class="form-group">
                          <label>Destinação</label>
                          <textarea class="form-control" name="destinacao" ></textarea>
                      </div>
                  </div>
              </div>

              <!-- DEPOSITO -->
              <div class="col-md-4">


                  <label for="numero-cheque">Especie</label>
                  <div class="form-group">
                      <div class="input-group">
                          <span class="input-group-addon">
                              <i class="fa fa-credit-card-alt"></i>
                          </span>
                          <select class="form-control" nome="especie" id="especie">
                              <option value="1">Dinheiro</option>
                              <option value="2">Cheque</option>
                          </select> 
                      </div>
                  </div>


                  <label>Numero Cheque</label>
                  <div class="form-group">
                      <div class="input-group">
                          <span class="input-group-addon">
                              <i class="fa fa-gg"></i>
                          </span>
                          <input type="text" class="form-control" id="cheque" name="nrCheque" >
                      </div>
                  </div>





                  <div class="form-group">
                      <label>Observação</label>
                      <textarea class="form-control" name="obs" ></textarea>
                  </div>

              </div>

              <!-- Banco -->
              <div class="col-md-3">

                  <label for="numero-cheque">Banco</label>
                  <div class="form-group">
                      <div class="input-group">
                          <span class="input-group-addon">
                              <i class="fa fa-bank"></i>
                          </span>
                          <select class="chosen-select" id="banco" name="nome-banco">
                              <?php foreach ($bancos as $banco): ?>
                                  <option value="<?= $banco['nrBanco'] ?> - <?= $banco['banco'] ?>" <?php if ($banco['nrBanco'] === "001") echo"selected"; ?>><?= $banco['nrBanco'] ?> - <?= $banco['banco'] ?> </option>
                              <?php endforeach; ?>

                          </select>
                      </div>
                  </div>

                  <label for="numero-cheque">Valor</label>
                  <div class="form-group">
                      <input type="text" class="form-control" id="valor-deposito" name="valor" >
                  </div>




              </div>

          </div>
      </div>




      <button type="submit" class="btn btn-success center-block">
          <span class="fa fa-save"></span>
          Lançar
      </button>

   </form>


    

    </section>

 
<?php require_once 'footer.php' ?>
<script>
   $(document).ready(function() {
      $('.datepicker').datepicker({
          format: 'dd/mm/yyyy',
          language: 'pt-BR',
          todayHighlight: true
      });

   });

</script>