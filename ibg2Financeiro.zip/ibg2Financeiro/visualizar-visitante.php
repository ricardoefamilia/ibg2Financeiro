<?php
    require_once 'top.php';
    require_once 'sql/conexao.php';
    require_once 'sql/banco-visitante.php';

	$id = $_GET["id"];

    $visitante = buscaVisitantesPorID($con, $id);

?>


    <section class="container">
        <div class="row">
            <div class="col-sm-12">

                <div class="page-header">
                    <h3 class="text-center">Dados dos visitante</h3>
                </div>

                <div class="row">
                    <div class="col-xs-12 col-sm-4">

                        <div class="form-group">
                            <label for="visitantes">Data da visita:</label>
                            <?= date('d/m/Y', strtotime($visitante['data']));?>
                        </div>

                        <div class="form-group">
                            <label for="visitantes">Nome:</label>
                            <?= $visitante['nome'];?>
                        </div>

                        <div class="form-group">
                            <label for="visitantes">Aniversário:</label>
                            <?= date('d/m/Y', strtotime($visitante['dataNascimento']));?>
                        </div>

                        <div class="form-group">
                            <label for="visitantes">Telefone:</label>
                            <?= $visitante['telefone'];?>
                        </div>

                        <div class="form-group">
                            <label for="visitantes">Celular:</label>
                            <?= $visitante['celular'];?>
                        </div>

                        <div class="form-group">
                            <label for="visitantes">Endereço:</label>
                            <?= $visitante['endereco'];?>
                        </div>

                        <div class="form-group">
                            <label for="visitantes">CEP:</label>
                            <?= $visitante['cep'];?>
                        </div>

                        <div class="form-group">
                            <label for="visitantes">E-mail:</label>
                            <?= $visitante['email'];?>
                        </div>


                        <div class="form-group">
                            <label for="visitantes">Sua visita:</label>
                            <?= $visitante['suaVisita'];?>ª vez
                        </div>
                    </div>

                <div class="col-xs-12 col-sm-4">
                    <div class="form-group">
                        <label for="visitantes">Tipo:</label>
                        <?= $visitante['tipo'];?>
                    </div>

                    <div class="form-group">
                        <label for="visitantes">Faixa Etária:</label>
                        <?= $visitante['faixaEtaria'];?>
                    </div>

                    <div class="form-group">
                        <label for="visitantes">Minha decisão:</label>
                        <?= $visitante['minhaDecisao'];?>
                    </div>

                    <div class="form-group">
                        <label for="visitantes">Meu Interesse:</label></br>
                        <?= $visitante['meuInteresse'];?>
                    </div>

                    <div class="form-group">
                        <label for="visitantes">Precisa de Orientação:</label><br/>
                        <?= $visitante['precisoOrientacao'];?>
                    </div>

                    <div class="form-group">
                        <label for="visitantes">Pedido de oração:</label>
                        <?= $visitante['pedidoOracao'];?>
                    </div>

                    <div class="form-group">
                        <label for="visitantes">Como conheceu a IBG2:</label><br>
                        <?= $visitante['conheciIBG2'];?>
                    </div>
                </div>

                <div class="col-xs-12 col-sm-4">

                    <h4>Opiniões sobre a IBG2</h4>

                    <div class="form-group">
                        <label for="visitantes">Música</label>
                        <div class="radio">
                          <label><?=$visitante['opiniaoMusica'];?></label>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="visitantes">Recepção</label>
                        <div class="radio">
                          <label><?=$visitante['opiniaoRecepcao'];?></label>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="visitantes">Pregação</label>
                        <div class="radio">
                          <label><?=$visitante['opiniaoPregacao'];?></label>
                        </div>
                    </div>

                </div>
                </div>
                <a class="btn btn-warning" href="form-visitante.php">
                    <span class="fa fa-angle-double-left"></span>
                    Voltar
                </a>


            </div>
        </div>
    </section>

<?php require_once 'footer.php' ?>
