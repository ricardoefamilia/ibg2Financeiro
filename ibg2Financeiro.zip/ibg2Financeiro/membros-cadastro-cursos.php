<?php
require_once 'top.php';
require_once 'mostra-alerta.php';
require_once 'sql/banco-membros.php';
require_once 'sql/banco-cursos.php';

  $idMembro = $_GET['id'];
  $membro = consultaMembrosPorID($con, $idMembro);
  $cursos = buscaCursosDoMembro($con, $idMembro);

  
?>

  <section class="container">

      <?php mostraAlerta('success'); ?>

      <h3 class="page-header"><?=$membro['nome']?></h3>

    <br>
    <a href="form-membros-cursos.php?id=<?=$membro['idPessoas']?>" class="btn btn-success">
      <span class="fa fa-trash"></span>
      Cadastrar
    </a>
    <br>
    <br>

    <?php if (empty($cursos)): ?>
        <section class="container">
            <p class="alert alert-warning text-center">Nenhum curso cadastrado</p>
            <p class="text-center"> <a href="membros-cadastro-consulta.php">Clique aqui</a> para voltar</p>
        </section>
    <?php else: ?>

    <table class="table table-hover">
        <thead>
          <tr>
            <th class="text-center">Curso</th>
            <th class="text-center">Titulação</th>
            <th class="text-center">Instituição</th>
            <th class="text-center">Ações</th>
          </tr>
        </thead>

        <tbody>
            <?php foreach ($cursos as $curso): ?>
                <tr>
                  <td class="text-center"><?=$curso['curso']?></td>
                  <td class="text-center"><?=$curso['titulacao']?></td>
                  <td class="text-center"><?=$curso['instituicao']?></td>
                  <td class="text-center">

                    <a href="membros-altera-cursos.php?idCurso=<?=$curso['idCursosRealizados']?>&membro=<?=$idMembro?>" class="btn btn-primary">
                      <span class="fa fa-refresh"></span>
                      Alterar
                    </a>

                    <!-- BTN MODAL -->
                    <button type="button" class="btn btn-danger btnModal" data-toggle="modal" data-target="#myModal-<?=$curso['idCursosRealizados']?>">
                       <span class="fa fa-trash"></span>
                       Remover
                    </button>

                 <!-- Modal Remover -->
                 <div class="modal fade" id="myModal-<?=$curso['idCursosRealizados']?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                   <div class="modal-dialog" role="document">

                      <!-- MODAL CONTENT -->
                     <div class="modal-content">

                       <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal">&times</button>
                          <h4>Excluir Curso</h4>
                       </div>

                       <!-- MODAL BODY -->
                       <div class="modal-body">
                          <p>Tem certeza que deseja excluir o curso?</p>
                       </div>

                       <!-- MODAL FOOTER -->
                       <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Não</button>
                          <a class="btn btn-primary" href="membros-remove-cursos.php?id=<?=$curso['idCursosRealizados']?>&idMembro=<?=$idMembro?>">
                             Sim
                          </a>
                       </div>
                     </div>

                   </div>
                 </div>

                  </td>
                </tr>
            <?php endforeach; ?>
        </tbody>

    </table>
    <a href="membros-cadastro-consulta.php" class="btn btn-default">Voltar</a>
    <?php endif ?>
  </section>

<?php require_once 'footer.php' ?>
