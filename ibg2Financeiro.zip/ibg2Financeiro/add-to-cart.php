<?php
   session_start();
   
   if (empty($_SESSION['cart'])) {
       $_SESSION['cart'] = [];
   }


   // Verifica se existe o campo Nome
   if (isset($_POST['nome'])) {
       if (empty($_POST['nome'])) {
           $_SESSION['danger'] = 'O campo NOME não pode ficar em branco!';
           header('Location: form-lancamento.php');
           die();
       }
   }
   // Verifica se existe o campo Dinheiro
   if (isset($_POST['quantidade-dinheiro'])) {
       if (empty($_POST['quantidade-dinheiro'])) {
           $_SESSION['danger'] = 'O campo Dinheiro não pode ficar em branco!';
           header('Location: form-lancamento.php');
           die();
       }
   }
   // Verifica se existe o campo Depósito
   if (isset($_POST['comprovante-deposito']) && isset($_POST['valor-deposito'])) {
       if (empty($_POST['comprovante-deposito']) || empty($_POST['valor-deposito'])) {
           $_SESSION['danger'] = 'Os campos em Depósito não podem ficar em branco!';
           header('Location: form-lancamento.php');
           die();
       }
   }
   // Verifica se existe o campo Cheque
   if (isset($_POST['numero-cheque']) && isset($_POST['valor-cheque']) && isset($_POST['nome-banco'])) {
       if (empty($_POST['numero-cheque']) || empty($_POST['valor-cheque']) || empty($_POST['nome-banco'])) {
           $_SESSION['danger'] = 'Os campos em Cheque não podem ficar em branco!';
           header('Location: form-lancamento.php');
           die();
       }
   }


   // DINHEIRO => Normal
   if (isset($_POST['nome']) && isset($_POST['quantidade-dinheiro'])) {
       if (!empty($_POST['nome']) && !empty($_POST['quantidade-dinheiro'])) {
           array_push($_SESSION['cart'],
           [
              "FKPessoa" => $_POST['nome'],
              "valor" => $_POST['quantidade-dinheiro'],
              "especie" => 1,
              "FKDestinacao" => $_POST['destinacao']
           ]);
       }
   }


    // DEPOSITO => Normal
    if (isset($_POST['nome']) && isset($_POST['comprovante-deposito']) && isset($_POST['valor-deposito'])) {
        if (!empty($_POST['nome']) && !empty($_POST['comprovante-deposito']) && !empty($_POST['valor-deposito'])) {
            array_push($_SESSION['cart'],
           [
               "FKPessoa" => $_POST['nome'],
               "numero-comprovante" => $_POST['comprovante-deposito'],
               "valor" => $_POST['valor-deposito'],
               "especie" => 2,
               "FKDestinacao" => $_POST['destinacao']
           ]);
        }
    }

   // CHEQUE => Normal
   if (isset($_POST['nome']) && isset($_POST['numero-cheque']) && isset($_POST['valor-cheque']) && isset($_POST['nome-banco'])) {
       if (!empty($_POST['nome']) && !empty($_POST['numero-cheque']) && !empty($_POST['valor-cheque']) && !empty($_POST['nome-banco'])) {
           array_push($_SESSION['cart'],
           [
              "FKPessoa" => $_POST['nome'],
              "numero-cheque" => $_POST['numero-cheque'],
              "agencia" => $_POST['cheque-agencia'],
              "conta" => $_POST['cheque-conta'],
              "valor" => $_POST['valor-cheque'],
              "nome-banco" => $_POST['nome-banco'],
              "especie" => 3,
              "FKDestinacao" => $_POST['destinacao']
           ]);
       }
   }


   header('Location: form-lancamento.php');
   die();
