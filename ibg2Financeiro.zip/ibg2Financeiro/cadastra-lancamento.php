<?php
require_once 'sql/conexao.php';
require_once 'sql/banco-teste.php';
require_once 'mostra-alerta.php';

//echo '<pre>';
//var_dump($_SESSION['cart']) or die;

foreach ($_SESSION['cart'] as $key => $value) :
   if (adicionaLancamento($con, $value)) {
       $_SESSION['success'] = 'Lançamentos cadastrados com sucesso';
       header('Location: form-lancamento.php');
   } else {
       echo mysqli_error($con) . "<br>";
   }
endforeach;
unset($_SESSION['cart']);
die();
