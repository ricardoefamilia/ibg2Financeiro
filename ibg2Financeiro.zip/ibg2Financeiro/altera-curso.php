<?php

    require_once 'sql/conexao.php';
    require_once 'sql/banco-cursos.php';
    session_start();
    
    

    $idMembro = $_POST['idMembro'];

    if (alteraCurso($con, $_POST['curso'],$_POST['titulacao'],$_POST['instituicao'], $idMembro)) {
        $_SESSION['success'] = 'Curso alterado com sucesso';
        header('Location: membros-cadastro-cursos.php?id='.$idMembro);
    } else {
        echo mysqli_error($con);
    }

    die();
