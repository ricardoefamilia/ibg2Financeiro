<?php

   require_once 'top.php';
   require_once 'sql/banco-usuario.php';
   $membros= buscaMembrosParaCadastro($con);
   //$perfis= buscaTudoPerfil($con);
?>

<div class="container">
<div class="row">
<div class="col-xs-12 col-md-offset-3 col-md-6">
    <div class="page-header">
        
          <?php mostraAlerta('success'); ?>
        
    	<h3 class="text-primary"><i class="fa fa-user-plus"></i> Cadastro de Usuário</h3>
	</div>
</div>
<div class="col-xs-12 col-md-offset-3 col-md-6">
<form method="POST" action="cadastra-usuario.php">
<div class="form-group">
   <label for="membro">Membro</label>
   <select class="chosen-select" name="membro">
      <?php foreach ($membros as $membro): ?>
         <option value="<?=$membro['idPessoas']?>"> <?=$membro['nome'] ?> </option>
      <?php endforeach; ?>

   </select>
</div>
<div class="form-group">
<label for="user">Usuário: </label>
<input type="text" name="user" class="form-control"/>
<br>
<label for="senha">Senha: </label>
<input type="password" name="senha" class="form-control"/>
</div>
<div class="form-group">
   <label for="perfil">Perfil:</label>
   <select class="chosen-select" name="perfil">
       <option value="1">Presidente</option>
       <option value="2">Secretário (a)</option>
       <option value="3">Tesoureiro (a)</option>
       <option value="4">Departamento de Finanças</option>
       <option value="5">Secretário (a) e Tesoureiro</option>
       <option value="6">Secretário (a) e Ministro de Finanças</option>
   </select><br><br>
<input type="submit" value="&nbsp;&nbsp; CADASTRAR &nbsp;&nbsp;" class="btn btn-success btn-lg"/> &nbsp;
<input type="reset" value="&nbsp;&nbsp; LIMPAR &nbsp;&nbsp;" class="btn btn-danger btn-lg"/>
</div>
</form>
</div>    
</div>
</div>

<?php require_once 'footer.php' ?>
