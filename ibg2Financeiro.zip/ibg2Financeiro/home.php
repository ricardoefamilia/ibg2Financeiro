<?php
require_once 'top.php';
require_once 'mostra-alerta.php';
?>
<style type="text/css">

    body { padding-top:20px; }
    .panel-body .btn:not(.btn-block) { width:120px;margin-bottom:10px; }

</style>

<section class="container">

    <?php mostraAlerta('success'); ?>

            <h3 class="page-header">Bem-vindo, <?php echo $_COOKIE['nomePessoa']; ?>!</h3> 
    
    
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <span class="glyphicon glyphicon-bookmark"></span> Acesso Rápido</h3>
                </div>
                <div class="panel-body">





                    <div class="row">


                        <div class="col-xs-6 col-md-3">
                            <a href="form-usuario.php" class="thumbnail">
                                <div class="text-center">
                                    <i class="fa fa-users fa-3x" ></i>
                                </div>
                                <p class="text-center"><i class="fa fa-plus-circle"></i> Usuário</p>
                            </a>
                        </div>


                        <div class="col-xs-6 col-md-3">
                            <a href="form-lancamento.php" class="thumbnail">
                                <div class="text-center">
                                    <i class="fa fa-calculator fa-3x" ></i>
                                </div>
                                <p class="text-center"><i class="fa fa-plus-circle"></i> Lançamentos</p>
                            </a>
                        </div>
                        
                        
                        <div class="col-xs-6 col-md-3">
                            <a href="form-saida.php" class="thumbnail">
                                <div class="text-center">
                                    <i class="fa fa-hand-o-down fa-3x" ></i>
                                </div>
                                <p class="text-center"><i class="fa fa-plus-circle"></i> Saidas</p>
                            </a>
                        </div>

                        <div class="col-xs-6 col-md-3">
                            <a href="membros-cadastro-consulta.php" class="thumbnail">
                                <div class="text-center">
                                    <i class="fa fa-address-card-o fa-3x" ></i>
                                </div>
                                <p class="text-center"><i class="fa fa-plus-circle"></i> Membros</p>
                            </a>
                        </div>


                    </div>

                    <div class="row">


                        <div class="col-xs-6 col-md-3">
                            <a href="form-visitante.php" class="thumbnail">
                                <div class="text-center">
                                    <i class="fa fa-address-book-o fa-3x" ></i>
                                </div>
                                <p class="text-center"><i class="fa fa-plus-circle"></i> Visitante</p>
                            </a>
                        </div>


                        <div class="col-xs-6 col-md-3">
                            <a href="form-entradas-listar.php" class="thumbnail">
                                <div class="text-center">
                                    <i class="fa fa-check-square-o fa-3x" ></i>
                                </div>
                                <p class="text-center"><i class="fa fa-plus-circle"></i> Confirmar Lançamentos</p>
                            </a>
                        </div>

                        <div class="col-xs-6 col-md-3">
                            <a href="form-saidas-listar.php" class="thumbnail">
                                <div class="text-center">
                                    <i class="fa fa-check-square fa-3x" ></i>
                                </div>
                                <p class="text-center"><i class="fa fa-plus-circle"></i> Confirmar Saidas</p>
                            </a>
                        </div>

                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <div class="text-center">
                                    <i class="fa fa-file-text-o fa-3x" ></i>
                                </div>
                                <p class="text-center"><i class="fa fa-plus-circle"></i> Relátorios</p>
                            </a>
                        </div>


                    </div>
                    
                    <div class="row">
                        
                         <div class="col-xs-6 col-md-3">
                            <a href="form-destinacao.php" class="thumbnail">
                                <div class="text-center">
                                    <i class="fa fa-list fa-3x" ></i>
                                </div>
                                <p class="text-center"><i class="fa fa-plus-circle"></i> Destinação</p>
                            </a>
                        </div>
                        
                    </div>

                </div>
            </div>
        </div>
    </div>



</section>

<?php require_once 'footer.php' ?>
