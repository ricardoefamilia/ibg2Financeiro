<?php

   require_once 'sql/conexao.php';
   require_once 'sql/banco-usuario.php';
   require_once 'mostra-alerta.php';
   
//   echo '<pre>';
//   var_dump($_POST) or die;


   if (cadastraUsuario($con, $_POST['user'], $_POST['senha'], $_POST['perfil'], $_POST['membro'])) {
       $_SESSION['success'] = 'Usuário cadastrado com sucesso';
       header('Location: form-usuario.php');
   } else {
       echo mysqli_error($con);
   }

   die();
