<?php

  require_once 'mostra-alerta.php';

?>

<!DOCTYPE html>
<html>

<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login</title>
   <link href="css/bootstrap.min.css" rel="stylesheet">
   <link href="css/fonts-awesome.min.css" rel="stylesheet">
   <link href="css/master.css" rel="stylesheet">
</head>

<body>


   <section class="container margem-topo">

      <div class="col-sm-4 col-sm-offset-4">

         <?php mostraAlerta('danger'); ?>

         <h2 class="page-header text-center"><i class="fa fa-bank"></i> Financeiro IBG2</h2>
         <form action="teste_login.php" method="POST">
            <div class="form-group input-group">
               <span class="input-group-addon">
                  <i class="fa fa-user"></i>
               </span>
               <input class="form-control" type="text" name="nome" placeholder="Usuário" />
            </div>

            <div class="form-group input-group">
               <span class="input-group-addon">
                  <i class="fa fa-lock"></i>
               </span>
               <input class="form-control" type="password" name="senha" placeholder="Senha" />
            </div>

            <div class="form-group">
               <button type="submit" class="btn btn-info btn-block">Login</button>
            </div>
         </form>
      </div>

   </section>

</body>

</html>
