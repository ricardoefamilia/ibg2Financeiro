<?php
    require_once 'sql/conexao.php';
    require_once 'sql/banco-membros.php';
    session_start();

    $dados = $_POST;
    $idMembro = $dados['idMembro'];
    unset($dados['idMembro']);

//    echo "<pre>";
//        print_r($dados);
//    echo "</pre>";

    if (inserirMembroCurso($con, $dados['curso'], $dados['titulacao'], $dados['instituicao'], $idMembro)) {
        $_SESSION['success'] = 'Cursos adicionados com sucesso';
        header('Location: membros-cadastro-cursos.php?id='.$idMembro);
    } else {
        echo mysqli_error($con);
    }
