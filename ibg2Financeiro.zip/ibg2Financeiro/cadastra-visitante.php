<?php
    require_once("sql/conexao.php");
    require_once("sql/banco-visitante.php");
    require_once 'mostra-alerta.php';

    function dataAmericana($data, $separador = '/') {
        $data = explode('/', $data);
        if (checkdate ($data[1], $data[0], $data[2]) )
            return $data[2] . $separador . $data[1] . $separador . $data[0];
    }

    //1- Recuperar dados HTML
    $nome = $_POST["nome-visitante"];
    $data = dataAmericana($_POST["data"], '-');
    if(!empty($_POST["nascimento"])){
        $dataNascimento = dataAmericana($_POST["nascimento"], '-');
    }else{
         $dataNascimento = null;
    }
    $telefone = $_POST["telefone"];
    $celular = $_POST["cel"];
    $endereco = $_POST["endereco"];
    $cep = $_POST["cep"];
    $email = $_POST["email"];
    $suaVisita = $_POST["sua-visita"];
    $tipo = $_POST["tipo"];
    $faixaEtaria = $_POST["faixa"];
    $minhaDecisao = $_POST["decisao"];
    $meuInteresse = $_POST["interesse"];
    $precisoOrientacao = $_POST["orientacao"];
    $pedidoOracao = $_POST["oracao"];
    $conheciIBG2 = $_POST["conheceu"];
    $opiniaoMusica = $_POST["musica"];
    $opiniaoRecepcao = $_POST["recepcao"];
    $opiniaoPregacao = $_POST["pregacao"];

    if ($telefone === "") {
        $telefone = 0;
    }
    if ($celular === "") {
        $celular = 0;
    }
    if ($endereco === "") {
        $endereco = "NÃO PREENCHIDO";
    }
    if ($cep === "") {
        $cep = 0;
    }
    if ($email === "") {
        $email = "-@-.com";
    }
    if ($minhaDecisao === "") {
        $minhaDecisao = "NÃO PREENCHIDO";
    }
    if ($meuInteresse === "") {
        $meuInteresse = "NÃO PREENCHIDO";
    }
    if ($precisoOrientacao === "") {
        $precisoOrientacao = "NÃO PREENCHIDO";
    }
    if ($pedidoOracao === "") {
        $pedidoOracao = "NÃO PREENCHIDO";
    }
    if ($conheciIBG2 === "") {
        $conheciIBG2 = "NÃO PREENCHIDO";
    }
    if ($opiniaoMusica === "") {
        $opiniaoMusica = "NÃO PREENCHIDO";
    }
    if ($opiniaoRecepcao === "") {
        $opiniaoRecepcao = "NÃO PREENCHIDO";
    }
    if ($opiniaoPregacao === "") {
        $opiniaoPregacao = "NÃO PREENCHIDO";
    }

    if (cadastraVisitante($con,
    $nome,
    $data,
    $dataNascimento,
    $telefone,
    $celular,
    $endereco,
    $cep,
    $email,
    $suaVisita,
    $tipo,
    $faixaEtaria,
    $minhaDecisao,
    $meuInteresse,
    $precisoOrientacao,
    $pedidoOracao,
    $conheciIBG2,
    $opiniaoMusica,
    $opiniaoRecepcao,
    $opiniaoPregacao))
    {
        $_SESSION['success'] = 'Visitante cadastrado com sucesso';
        header('Location: form-visitante.php');
    } else {
        echo mysqli_error($con);
    }



    //2- Validar campos obrigatórios
    if (($nome === "")
        || ($data === "")
        || ($dataNascimento === "")
        || ($suaVisita === "")
        || ($tipo === "")
        || ($faixaEtaria === "")) {
        $_SESSION['danger'] = 'É preciso preencher todos os campos obrigatórios';
        header('Location: form-visitante.php');
        die();
    }


//    	echo "<pre>";
//    	print_r($_POST);
//    	echo "</pre>";


    // $query = "insert into visitantes (nome,data,dataNascimento,telefone,celular,endereco,cep,email,suaVisita,tipo,faixaEtaria,minhaDecisao,meuInteresse,precisoOrientacao,pedidoOracao,conheciIBG2,opiniaoMusica,opiniaoRecepcao,opiniaoPregacao) values('$nome','$data','$dataNascimento','$telefone','$celular','$endereco','$cep','$email','$suaVisita','$tipo','$faixaEtaria','$minhaDecisao','$meuInteresse','$precisoOrientacao','$pedidoOracao','$conheciIBG2','$opiniaoMusica','$opiniaoRecepcao','$opiniaoPregacao')");
    //
    // mysqli_query($conexao,
    //
    // $msg =  "Visitante cadastrado com sucesso";
    // header("Location: form-visitante.php");
