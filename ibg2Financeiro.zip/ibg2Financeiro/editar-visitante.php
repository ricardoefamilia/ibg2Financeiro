<?php
    require_once 'top.php';
    require_once 'sql/banco-visitante.php';

    $id = $_GET['id'];
    $visitante = buscaVisitantesPorID($con, $id);
   
   

?>


<section class="container">
    <div class="row">

        <div class="col-sm-12">
            <div class="page-header">
                <h3 class="text-center">Editar Visitante</h3>
            </div>
        </div>

        <div class="col-sm-12">

            <div class="col-xs-12 col-md-6">
                <form id="form-lancamento" method="post" action="altera-visitante.php">

                <div class="row">
                    <div class="col-xs-12 col-md-8">
                        <div class="form-group">



                        <div class="form-group">
                            <label>Data da visita:</label>
                            <input type="date" name="data" class="form-control datepicker" value="<?= date('d/m/Y', strtotime($visitante['data']));?>">
                        </div>

                        Identificação do Visitante: <?=$visitante['idVisitantes'];?>
                        <input type="hidden" name="idVisitantes" value="<?=$visitante['idVisitantes'];?>">


                        <div class="form-group">
                            <label>Nome:</label>
                            <input type="text" name="nomeVisitante" class="form-control" value="<?=$visitante['nome'];?>">
                        </div>

                        <div class="form-group">
                            <label>Aniversário:</label>
                            <input type="date" name="nascimento" class="form-control datepicker" value="<?=$visitante['dataNascimento'];?>">
                        </div>

                        <div class="form-group">
                            <label>Telefone:</label>
                            <input type="text" name="telefone" class="form-control" value="<?=$visitante['telefone'];?>">
                        </div>

                        <div class="form-group">
                            <label>Celular:</label>
                            <input type="text" name="cel" class="form-control" value="<?=$visitante['celular'];?>">
                        </div>

                        <div class="form-group">
                            <label>Endereço:</label>
                            <input type="text" name="endereco" class="form-control" value="<?=$visitante['endereco'];?>">
                        </div>

                        <div class="form-group">
                            <label>CEP:</label>
                            <input type="text" name="cep" class="form-control" value="<?=$visitante['cep'];?>">
                        </div>

                        <div class="form-group">
                            <label>E-mail:</label>
                            <input type="text" name="email" class="form-control" value="<?=$visitante['email'];?>">
                        </div>

                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label>Sua visita:</label>


                    <?php if ($visitante['suaVisita'] === '1') : ?>
                        <input type="radio" name="suaVisita" id="suaVisita" value="1" checked> 1ª vez
                    <?php else : ?>
                        <input type="radio" name="suaVisita" id="suaVisita" value="1"> 1ª vez
                    <?php endif ?>


                    <?php if ($visitante['suaVisita'] === '2') : ?>
                        <input type="radio" name="suaVisita" id="suaVisita" value="2" checked> 2ª vez
                    <?php else : ?>
                        <input type="radio" name="suaVisita" id="suaVisita" value="2"> 2ª vez
                    <?php endif ?>


                    <?php if ($visitante['suaVisita'] === '3') : ?>
                        <input type="radio" name="suaVisita" id="suaVisita" value="3" checked> 3ª vez <br>
                    <?php else : ?>
                        <input type="radio" name="suaVisita" id="suaVisita" value="3"> 3ª vez <br>
                    <?php endif ?>

                </div>

                <div class="form-group">
                    <label>Tipo:</label>
                    <?php if($visitante['tipo'] === "Frequentador") : ?>
                        <input type="radio" name="tipo" id="tipo" value="Frequentador" checked> Frequentador
                    <?php else : ?>
                        <input type="radio" name="tipo" id="tipo" value="Frequentador"> Frequentador
                    <?php endif ?>

                    <?php if($visitante['tipo'] === "Membro") : ?>
                        <input type="radio" name="tipo" id="tipo" value="Membro" checked> Membro
                    <?php else : ?>
                        <input type="radio" name="tipo" id="tipo" value="Membro"> Membro
                    <?php endif ?>
                </div>

                <div class="form-group">
                    <label for="faixa">Faixa Etária:</label>
                    <select name="faixa" id="faixa" class="form-control">
                        <option value="<?=$visitante['faixaEtaria']?>"><?=$visitante['faixaEtaria']?></option>
                        <option value="Adolescente">Adolescente</option>
                        <option value="Jovem">Jovem</option>
                        <option value="Adulto">Adulto</option>
                        <option value="Idoso">Idoso</option>
                    </select>
                </div>

            </div>

        <div class="col-sm-6">

            <div class="form-group">
                <label>Minha decisão:</label>
                <input type="text" name="decisao" class="form-control" value="<?=$visitante['minhaDecisao']?>">
            </div>

            <div class="form-group">
            <label>Meu Interesse:</label><br />

            <?php
                $a = "Entrego minha vida para Cristo";
                $b ="Quero me reconciliar com Cristo";
                $c = "Quero ser batizado";
                $d ="Quero participar do curso";
                $e = "Apenas conhecer a igreja e a celebração do culto";

                if($visitante['meuInteresse'] === $a) :
            ?>

                <input type="radio" name="interesse" value="<?=$a;?>" checked> Entrego minha vida para Cristo<br />
            <?php else : ?>
                <input type="radio" name="interesse" value="<?=$a;?>"> Entrego minha vida para Cristo<br />
            <?php endif ?>

            <?php if ($visitante['meuInteresse'] === $b) : ?>
                <input type="radio" name="interesse" value="<?=$b;?>" checked> Quero me reconciliar com Cristo<br />
            <?php else : ?>
                <input type="radio" name="interesse" value="<?=$b;?>"> Quero me reconciliar com Cristo<br />
            <?php endif ?>

            <?php if ($visitante['meuInteresse'] === $c) : ?>
                <input type="radio" name="interesse" value="<?=$c;?>" checked> Quero ser batizado<br />
            <?php else : ?>
                <input type="radio" name="interesse" value="<?=$c;?>"> Quero ser batizado<br />
            <?php endif ?>

            <?php if ($visitante['meuInteresse'] === $d) : ?>
                <input type="radio" name="interesse" value="<?=$d;?>"> Quero participar do curso<br />
            <?php else : ?>
                <input type="radio" name="interesse" value="<?=$d;?>"> Quero participar do curso<br />
            <?php endif ?>
            
            <?php if ($visitante['meuInteresse'] === $e) : ?>
                <input type="radio" name="interesse" value="<?=$e;?>"> Apenas conhecer a igreja e a celebração do culto<br />
            <?php else : ?>
                <input type="radio" name="interesse" value="<?=$e;?>"> Apenas conhecer a igreja e a celebração do culto<br />
            <?php endif ?>

            </div>

            <div class="form-group">
                <label>Precisa de Orientação:</label>
                <textarea name="orientacao" class="form-control"><?=$visitante['precisoOrientacao']?></textarea>
            </div>

            <div class="form-group">
                <label>Pedido de oração:</label>
                <textarea name="oracao"class="form-control" ><?=$visitante['pedidoOracao']?></textarea>
            </div>

            <div class="form-group">
                <label>Como conheceu a IBG2:</label>
                <textarea name="conheceu" class="form-control" > <?=$visitante['conheciIBG2']?></textarea>
            </div>

            <div class="form-group"><br>
                <h4>Opiniões sobre a IBG2</h4>
                <label for="visitantes">Música:</label>

                <?php if ($visitante['opiniaoMusica'] === "Boa") : ?>
                    <input type="radio" name="musica" value="Boa" checked> Boa
                <?php else : ?>
                    <input type="radio" name="musica" value="Boa"> Boa
                <?php endif ?>

                <?php if ($visitante['opiniaoMusica'] === "Razoavel") : ?>
                    <input type="radio" name="musica" id="musica" value="Razoavel" checked> Razoável
                <?php else : ?>
                    <input type="radio" name="musica" id="musica" value="Razoavel"> Razoável
                <?php endif ?>

                <?php if ($visitante['opiniaoMusica'] === "Ruim") : ?>
                    <input type="radio" name="musica" value="Ruim"> Ruim
                <?php else : ?>
                    <input type="radio" name="musica" value="Ruim"> Ruim
                <?php endif ?>


                <label for="visitantes">Recepção:</label>
                <?php if ($visitante['opiniaoRecepcao'] === "Boa") : ?>
                    <input type="radio" name="recepcao" value="Boa" checked> Boa
                <?php else : ?>
                    <input type="radio" name="recepcao" value="Boa"> Boa
                <?php endif ?>

                <?php if ($visitante['opiniaoRecepcao'] === "Razoavel") : ?>
                    <input type="radio" name="recepcao" value="Razoavel" checked> Razoável
                <?php else : ?>
                    <input type="radio" name="recepcao" value="Razoavel"> Razoável
                <?php endif ?>

                <?php if ($visitante['opiniaoRecepcao'] === "Ruim") : ?>
                    <input type="radio" name="recepcao" value="Ruim" checked> Ruim
                <?php else : ?>
                    <input type="radio" name="recepcao" value="Ruim"> Ruim
                <?php endif ?>

                <label for="visitantes">Pregação:</label>
                <?php if ($visitante['opiniaoPregacao'] == "Boa") : ?>
                    <input type="radio" name="pregacao" value="Boa" checked> Boa
                <?php else : ?>
                    <input type="radio" name="pregacao" value="Boa"> Boa
                <?php endif ?>

                <?php if ($visitante['opiniaoPregacao'] === "Razoavel") : ?>
                    <input type="radio" name="pregacao" value="Razoavel" checked> Razoável
                <?php else : ?>
                    <input type="radio" name="pregacao" value="Razoavel"> Razoável
                <?php endif ?>

                <?php if ($visitante['opiniaoPregacao'] === "Ruim") : ?>
                    <input type="radio" name="pregacao" value="Ruim" checked> Ruim
                <?php else : ?>
                    <input type="radio" name="pregacao" value="Ruim"> Ruim
                <?php endif ?>
            </div>
        </div>

        <button type="submit" class="btn btn-info">
            <span class="fa fa-check"></span>
            Confirmar alteração
        </button>

        </form>
        <a class="btn btn-warning" href="form-visitante.php">
            <span class="fa fa-angle-double-left"></span>
            Voltar
        </a>

        </div>
    </div>
</section>

<?php require_once 'footer.php' ?>

<script>
   $(document).ready(function() {
      $('#dom').multiselect();

      $('.datepicker').datepicker({
          format: 'dd/mm/yyyy',
          language: 'pt-BR',
          todayHighlight: true
      });

   });

</script>