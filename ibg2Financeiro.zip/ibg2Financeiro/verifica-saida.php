<?php
require_once 'top.php';
require_once 'sql/banco-saida.php';
require_once 'sql/banco-usuario.php';

  error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);

  session_start();


// echo "<pre>";
// print_r($_SESSION['cart']);
// echo "</pre>";


if (empty($_SESSION['cart-saida'])) : ?>
    <section class="container">
        <p class="alert alert-warning text-center">Nenhum lançamento cadastrado</p>
        <p class="text-center"> <a href="form-saida.php">Clique aqui</a> para voltar </p>
    </section>
<?php else:

foreach ($_SESSION['cart-saida'] as $key => $value)
{

  if ($value['especie'] === 1) {
    $totalDinheiro += str_replace(',','.',str_replace('.','',$value['valor']));
  }

  if ($value['especie'] === 2) {
    $totalDeposito += str_replace(',','.',str_replace('.','',$value['valor']));
  }

  if ($value['especie'] === 3) {
    $totalCheque += str_replace(',','.',str_replace('.','',$value['valor']));
  }

}
?>

<section class="container margem-bottom">

    <div class="row">

    <h2 class="page-header text-center">Confirmação do lançamento</h2>

    <form action="cadastra-saida.php" method="post"> 

        <div class="table-responsive">

            <table class="table table-hover table-bordered">

                <thead>
                    <tr>
                        <!-- <th>ID</th> -->
                        <th>Destinação</th>
                        <th>Valor</th>
                        <th>Pagamento</th>
                        <th>N. do comprovante</th>
                        <th>N. do cheque</th>
                        <th>Agência</th>
                        <th>Conta</th>
                        <th>Banco</th>
                        <th>Observações</th>
                    </tr>
                </thead>
    <?php
        foreach ($_SESSION['cart-saida'] as $key => $value):
        
    ?>

                <tbody>

                    <tr>
                        <td class="col-sm-3"><?=$value['destinacao'] ?></td>
                        <td class="col-sm-1">R$ <?=$value['valor'] ?></td>


                        <!-- Verifica qual a espécie do pagamento -->
                        <td class="col-sm-1">
                            <?php if ($value["especie"] === 1): ?>
                                Dinheiro
                            <?php endif; ?>

                            <?php if ($value["especie"] === 2): ?>
                                Depósito
                            <?php endif; ?>

                            <?php if ($value["especie"] === 3): ?>
                                Cheque
                            <?php endif; ?>
                        </td>

                        <!-- Completar os campos em brancos -->
                        <?php if ($value["especie"] === 1): ?>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                        <?php endif; ?>

                        <!-- Caso o pagamento seja DEPOSITO, irá mostrar o número do comprovante -->
                        <?php if ($value["especie"] === 2): ?>
                            <td><?=$value['numero-comprovante'] ?></td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                        <?php endif; ?>

                        <!-- Caso o pagamento seja CHEQUE, irá mostra Numero do cheque, Agencia, Conta, Nome do Banco -->
                        <?php if ($value["especie"] === 3): ?>
                            <td>-</td>
                            <td><?=$value['numero-cheque']?></td>
                            <td><?=$value['agencia']?></td>
                            <td><?=$value['conta']?></td>
                            <td><?=$value['nome-banco']?></td>
                        <?php endif; ?>

                        <td><?=$value['obs']?></td>
                    </tr>

                <?php endforeach; ?>
                </tbody>

            </table>
        </div>

            <h3 class="page-header text-center">Total</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th class="text-center">Dinheiro</th>
                        <th class="text-center">Depósito</th>
                        <th class="text-center">Cheque</th>
                    </tr>
                </thead>

                <tbody>
                    <tr>
                        <td class="text-center">R$ <?= number_format($totalDinheiro, 2, ',', '.');?> </td>
                        <td class="text-center">R$ <?= number_format($totalDeposito, 2, ',', '.');?> </td>
                        <td class="text-center">R$ <?= number_format($totalCheque, 2, ',', '.');?> </td>
                    </tr>
                </tbody>
            </table>

                <div class="form-group text-center">
                    <input type="checkbox" id="confirma-lancamento">
                    <label for="confirma-lancamento">Os dados estão corretos?</label>
                </div>

            <button class="btn btn-success center-block"  id="lancamento" disabled>
                <span class="fa fa-check"></span>
                Confirmar lançamento
            </button>
    </form>
                    
            <a href="form-saida.php">
                <button type="button" name="button" class="btn btn-primary center-block">
                    <span class="fa fa-angle-double-left"></span>
                    Voltar
                </button>
            </a>

    </div>
</section>
<?php endif;?>

<?php require_once 'footer.php' ?>
<script src="js/verifica-lancamento.js"></script>
