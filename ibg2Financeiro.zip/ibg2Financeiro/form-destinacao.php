<?php
    require_once 'top.php';
    require_once 'mostra-alerta.php';
    require_once 'sql/banco-destinacao.php';

    $destinacoes = buscaDestinacoes($con);
?>


   <section class="container">

      <?php
         mostraAlerta('danger');
         mostraAlerta('success');
      ?>

      <div class="row">


         <div class="col-sm-5">
            <div class="page-header">
               <h3> <i class="fa fa-arrows"></i> Adicionar Destinação</</h3>
            </div>
             <form method="post" action="cadastro-destinacao.php">
               <div class="row">
                  <div class="col-xs-8">
                     <div class="form-group">
                        <label for="destinacao">Nome da destinação</label>
                        <input type="text" name="destinacao" id="destinacao" class="form-control">
                     </div>
                  </div>
               </div>
               <button type="submit" class="btn btn-success">
                  <span class="fa fa-plus"></span>
                  Cadastrar
               </button>
            </form>
         </div>
         <div class="col-xs-7">
            <div class="page-header">
               <h3><i class="fa fa-list"></i> Lista de Destinações </h3>
            </div>

            <table class="text-center table table-bordered table-hover">

               <thead>
                  <tr>
                     <th class="text-center">#</th>
                     <th class="text-center">Descrição</th>
                     <th class="text-center">Ações</th>
                  </tr>
               </thead>

               <tbody class="text-center">

                  <?php foreach ($destinacoes as $destinacao) : ?>
                     <tr>
                        <td><?=$destinacao['iddestinacao']?></td>
                        <td><?=$destinacao['descricao']?></td>
                        <td>
                           <a class="btn btn-info" href="form-altera-destinacao.php?id=<?=$destinacao['iddestinacao']?>">
                              <span class="fa fa-pencil-square-o"></span>
                              Alterar
                           </a>

                           <a class="btn btn-danger" href="excluir-destinacao.php?id=<?=$destinacao['iddestinacao'] ?>">
                              <span class="fa fa-trash"></span>
                              Remover
                           </a>
                        </td>
                     </tr>
                  <?php endforeach ?>

               </tbody>

            </table>

         </div>
      </div>

   </section>

<?php require_once 'footer.php' ?>
