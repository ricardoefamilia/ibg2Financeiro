<?php

require_once 'sql/conexao.php';
require_once 'sql/banco-cursos.php';
session_start();

$id = $_GET['id'];
$idMembro = $_GET['idMembro'];

if (removeCursoPorId($con, $id)) {
    $_SESSION['success'] = 'Curso removido com sucesso';
    header('Location: membros-cadastro-cursos.php?id='.$idMembro);
} else {
    echo mysqli_error($con);
}

die();
