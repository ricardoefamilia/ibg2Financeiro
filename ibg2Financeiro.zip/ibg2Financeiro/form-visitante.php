<?php
    require_once 'top.php';
    require_once 'mostra-alerta.php';
    require_once 'sql/banco-visitante.php';

    $visitantes = buscaVisitantes($con);
    
      
    
?>

    <section class="container">

        <?php
            mostraAlerta('success');
            mostraAlerta('warning');
            mostraAlerta('danger');
       ?>

       <div class="col-md-5">

          <div class="page-header">
              <h3><i class="fa fa-user-o"></i> Cadastrar Visitantes</h3>
          </div>

          <form method="post" action="cadastra-visitante.php">
             <div class="col-xs-12 col-md-12">
                 <div class="row">
                     <div class="col-xs-11">

                         <div class="form-group">
                             <label>
                                 <span class="red-color fa fa-asterisk"></span>
                                 Data da visita
                             </label>
                             <input type="date" name="data" id="data" class="form-control datepicker">
                         </div>

                         <div class="form-group">
                             <label>
                                 <span class="red-color fa fa-asterisk"></span>
                                 Nome
                             </label>
                             <input type="text" name="nome-visitante" class="form-control">
                         </div>

                         <div class="form-group">
                             <label>
                                 <span class="red-color fa fa-asterisk"></span>
                                 Aniversário
                             </label>
                             <input type="date" name="nascimento" id="nascimento" class="form-control datepicker">
                         </div>

                         <div class="form-group">
                             <label>Telefone</label>
                             <input type="text" name="telefone" id="telefone" class="form-control">
                         </div>

                         <div class="form-group">
                             <label>Celular</label>
                             <input type="text" name="cel" id="celular" class="form-control">
                         </div>

                         <div class="form-group">
                             <label>Endereço</label>
                             <input type="text" name="endereco" id="endereco" class="form-control">
                         </div>

                         <div class="form-group">
                             <label>CEP</label>
                             <input type="text" name="cep" id="cep" class="form-control">
                         </div>

                         <div class="form-group">
                             <label>E-mail</label>
                             <input type="text" name="email" id="email" class="form-control">
                         </div>


                         <div class="form-group">
                             <label>
                                 <span class="red-color fa fa-asterisk"></span>
                                 Sua visita
                             </label><br>
                             <input type="radio" name="sua-visita" id="suaVisita" value="1" checked> 1ª vez
                             <input type="radio" name="sua-visita" id="suaVisita" value="2"> 2ª vez
                             <input type="radio" name="sua-visita" id="suaVisita" value="3"> 3ª vez
                         </div>

                         <div class="form-group">
                             <label>
                                 <span class="red-color fa fa-asterisk"></span>
                                 Tipo
                             </label><br>
                             <input type="radio" name="tipo" id="tipo" value="Frequentador" checked> Frequentador
                             <input type="radio" name="tipo" id="tipo" value="Membro"> Membro ????
                         </div>

                         <div class="form-group">
                             <label for="faixa">
                                 <span class="red-color fa fa-asterisk"></span>
                                 Faixa Etária
                             </label>

                             <select id="faixa" name="faixa" class="form-control">
                                 <option  value="Adolescente">Adolescente</option>
                                 <option  value="Jovem">Jovem</option>
                                 <option  value="Adulto">Adulto</option>
                                 <option  value="Idoso">Idoso</option>
                             </select>
                         </div>

                         <div class="form-group">
                             <label>Minha decisão</label>
                             <input type="text" name="decisao" id="decisao" class="form-control">
                         </div>

                         <div class="form-group">
                             <label>Meu Interesse</label></br>

                             <?php
                                 $a = "Entrego minha vida para Cristo";
                                 $b ="Quero me reconciliar com Cristo";
                                 $c = "Quero ser batizado";
                                 $d ="Quero participar do curso";
                                 $e = "Apenas conhecer a igreja e a celebração do culto";
                             ?>

                             <input type="radio" name="interesse" value="<?=$a?>" id="interesse" checked> Entrego minha vida para Cristo<br />
                             <input type="radio" name="interesse" value="<?=$b?>" id="interesse"> Quero me reconciliar com Cristo<br />
                             <input type="radio" name="interesse" value="<?=$c?>" id="interesse"> Quero ser batizado<br />
                             <input type="radio" name="interesse" value="<?=$d?>" id="interesse"> Quero participar do curso<br />
                             <input type="radio" name="interesse" value="<?=$e?>" id="interesse"> Apenas conhecer a igreja e a celebração do culto<br />
                         </div>

                         <div class="form-group">
                             <label>Precisa de Orientação:</label><br/>
                             <textarea name="orientacao" id="orientacao" class="form-control"></textarea>
                         </div>

                         <div class="form-group">
                             <label>Pedido de oração:</label>
                             <textarea name="oracao" id="oracao" class="form-control"></textarea>
                         </div>

                         <div class="form-group">
                             <label>Como conheceu a IBG2:</label>
                             <textarea name="conheceu" id="conheceu" class="form-control"> </textarea>
                         </div>

                         <div class="form-group"><br>
                             <h4>Opiniões sobre a IBG2</h4>

                             <label>Música</label>
                             <div class="radio">
                                 <label class="radio-inline"><input type="radio" name="musica" value="Boa" checked>Boa</label>
                                 <label class="radio-inline"><input type="radio" name="musica" value="Razoavel">Razoável</label>
                                 <label class="radio-inline"><input type="radio" name="musica" value="Ruim">Ruim</label>
                             </div>
                         </div>

                         <div class="form-group">
                             <label>Recepção</label>
                             <div class="radio">
                                 <label class="radio-inline"><input type="radio" name="recepcao" value="Boa" checked>Boa</label>
                                 <label class="radio-inline"><input type="radio" name="recepcao" value="Razoavel">Razoável</label>
                                 <label class="radio-inline"><input type="radio" name="recepcao" value="Ruim">Ruim</label>
                             </div>
                         </div>

                         <div class="form-group">
                             <label>Pregação</label>
                             <div class="radio">
                                 <label class="radio-inline"><input type="radio" name="pregacao" value="Boa" checked>Boa</label>
                                 <label class="radio-inline"><input type="radio" name="pregacao" value="Razoavel">Razoável</label>
                                 <label class="radio-inline"><input type="radio" name="pregacao" value="Ruim">Ruim</label>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>

             <button type="submit" class="btn btn-success">
                 <span class="fa fa-check"></span>
                 Cadastrar
             </button>
         </form>
     </div>

        <div class="col-xs-12 col-md-7">
            <div class="page-header">
                <h3>Lista de Visitantes</h3>
            </div>

            <div class="table-responsive">
                <table class='table table-bordered table-hover'>
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>Data da visita</th>
                            <th class="text-center">Ação</th>
                        </tr>
                    </thead>

                    <tbody id='lancamento-cadastrado'>

                        <?php foreach ($visitantes as $visitante): ?>
                            <tr>
                                <td><?=$visitante['nome']?></td>
                                <td><?= date('d/m/Y', strtotime($visitante['data']));?></td>

                                <td class="text-center">
                                    <a class="btn btn-primary" href="visualizar-visitante.php?id=<?=$visitante['idVisitantes']?>">
                                        <span class="fa fa-eye"></span>
                                        Visualizar
                                    </a>

                                    <a class="btn btn-info" href="editar-visitante.php?id=<?=$visitante['idVisitantes']?>">
                                        <span class="fa fa-pencil-square-o"></span>
                                        Alterar
                                    </a>

                                    <a class="btn btn-danger" href="remove-visitante.php?id=<?=$visitante['idVisitantes']?>">
                                        <span class="fa fa-trash"></span>
                                        Excluir
                                    </a>
                                </td>

                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </section>

    <?php require_once 'footer.php' ?>

<script>
   $(document).ready(function() {
      $('#dom').multiselect();

      $('.datepicker').datepicker({
          format: 'dd/mm/yyyy',
          language: 'pt-BR',
          todayHighlight: true
      });

   });

</script>
<script>
jQuery(function($){
   $("#cep").mask("99.999-999");
   $("#telefone").mask("(99) 9999-9999");
   $("#celular").mask("(99) 9 9999-9999");
   $("#cpf").mask("999.999.999-99");   
});

</script>