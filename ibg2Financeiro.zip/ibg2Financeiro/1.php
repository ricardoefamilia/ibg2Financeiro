<?php

require_once 'sql/conexao.php';
require_once 'sql/banco-membros.php';
require_once 'mostra-alerta.php';

    function dataAmericana($data, $separador = '/') {
        $data = explode('/', $data);
        if (checkdate ($data[1], $data[0], $data[2]) )
            return $data[2] . $separador . $data[1] . $separador . $data[0];
    }

    $dados = $_POST;
    /*
    $dons = $dados['seleciona-dons'];
    unset($dados['seleciona-dons']);
    */

    if(!empty($dados['nascimento'])){
        $dataNascimentoMembro = dataAmericana($dados['nascimento'], '-');
        $dados['nascimento'] = $dataNascimentoMembro;
    }
        
    if(!empty($dados['dataNascimentoConjuge'])){
        $nascimentoConjuge = dataAmericana($dados['dataNascimentoConjuge'], '-');
        $dados['dataNascimentoConjuge'] = $nascimentoConjuge;
    }

    if (!empty($dados['dataCasamento'])) {
        $dataCasamentoConjuge = dataAmericana($dados['dataCasamento'], '-');    
        $dados['dataCasamento'] = $dataCasamentoConjuge;

    }

    if (!empty($dados['igrejaBatismoDataBatismo'])) {
        $igrejaBatismoDataBatismo = dataAmericana($dados['igrejaBatismoDataBatismo'], '-');
        $dados['igrejaBatismoDataBatismo'] = $igrejaBatismoDataBatismo;
    }

    if (!empty($dados['dataEntrada'])) {
        $dataEntrada = dataAmericana($dados['dataEntrada'], '-');
        $dados['dataEntrada'] = $dataEntrada;
    }

    if (empty($dados['emailPessoal'])) {
        $dados['emailPessoal'] = "";
    }

    if (empty($dados['telefone'])) {
        $dados['telefone'] = "";
    }

    if (empty($dados['celular'])) {
        $dados['celular'] = "";
    }

    if (empty($dados['nomePai'])) {
        $dados['nomePai'] = "";
    }

    if (empty($dados['igrejaPai'])) {
        $dados['igrejaPai'] = "";
    }

    if (empty($dados['nomeMae'])) {
        $dados['nomeMae'] = "";
    }

    if (empty($dados['igrejaMae'])) {
        $dados['igrejaMae'] = "";
    }

    if (empty($dados['nomeConjuge'])) {
        $dados['nomeConjuge'] = "";
    }

    if (empty($dados['igrejaConjuge'])) {
        $dados['nomeConjuge'] = "";
    }


    if (empty($dados['dataNascimentoConjuge'])) {
        $dados['nomeConjuge'] = '';
    }

    if (empty($dados['dataCasamento'])) {
        $dados['dataCasamento'] = '';
    }

    if (empty($dados['dataEntrada'])) {
        $dados['dataEntrada'] = '';
    }

    if (empty($dados['empresaNome'])) {
        $dados['empresaNome'] = "";
    }


    if (empty($dados['empresaCargo'])) {
        $dados['empresaCargo'] = "";
    }

    if (empty($dados['profissao'])) {
        $dados['profissao'] = "";
    }

    if (empty($dados['empresaCep'])) {
        $dados['empresaCep'] = "";
    }

    if (empty($dados['empresaEstado'])) {
        $dados['empresaEstado'] = "";
    }

    if (empty($dados['empresaEndereco'])) {
        $dados['empresaEndereco'] = "";
    }

    if (empty($dados['empresaCidade'])) {
        $dados['empresaCidade'] = "";
    }

    if (empty($dados['empresaNumero'])) {
        $dados['empresaNumero'] = "";
    }

    if (empty($dados['empresaBairro'])) {
        $dados['empresaBairro'] = "";
    }

    if (empty($dados['empresaComplemento'])) {
        $dados['empresaComplemento'] = "";
    }

    if (empty($dados['igrejaBatismoNomeIgreja'])) {
        $dados['igrejaBatismoNomeIgreja'] = "";
    }

    if (empty($dados['igrejaBatismoDataBatismo'])) {
        $dados['igrejaBatismoDataBatismo'] = "";
    }

    if (empty($dados['igrejaOrigemNome'])) {
        $dados['igrejaOrigemNome'] = "";
    }

    if (empty($dados['igrejaOrigemEndereco'])) {
        $dados['igrejaOrigemEndereco'] = "";
    }

    if (empty($dados['igrejaOrigemCidade'])) {
        $dados['igrejaOrigemCidade'] = "";
    }

    if (empty($dados['igrejaOrigemCep'])) {
        $dados['igrejaOrigemCep'] = "";
    }

    if (empty($dados['igrejaOrigemEstado'])) {
        $dados['igrejaOrigemEstado'] = "";
    }


    if (empty($dados['igrejaOrigemNumero'])) {
        $dados['igrejaOrigemNumero'] = "";
    }

    if (empty($dados['igrejaOrigemBairro'])) {
        $dados['igrejaOrigemBairro'] = "";
    }

    if (empty($dados['igrejaOrigemComplemento'])) {
        $dados['igrejaOrigemComplemento'] = "";
    }

    if (empty($dados['igrejaOigemTelefone'])) {
        $dados['igrejaOigemTelefone'] = "";
    }
    
    if (empty($dados['igrejaOrigemAtividades'])) {
        $dados['igrejaOrigemAtividades'] = "";
    }


    InserirMembro($con,$dados);
    
    if(!empty($dados['seleciona-dons'])){
        $query = "SELECT * FROM pessoas WHERE cpf = '".$dados['cpf']."'";
        $resultado = mysqli_query($con, $query);
        $membroId = mysqli_fetch_assoc($resultado);
        $idMembro = $membroId['idPessoas'];
        foreach($dados['seleciona-dons'] as $dons){
            $sql = "insert into pessoas_has_dons values ('$idMembro','$dons')";
            mysqli_query($con, $sql) or die (mysqli_error());
        }
    }
    if(!empty($dados['nomePai'])||!empty($dados['nomeMae'])||!empty($dados['nomeConjuge'])){
        inserirFamiliares($con,$dados);
    }
    header("Location: membros-cadastro-consulta.php"); exit;