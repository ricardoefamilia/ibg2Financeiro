<?php

     require_once 'top.php';
     require_once 'mostra-alerta.php';
     require_once 'sql/banco-teste.php';

    $id = $_GET['id'];

    $destinacoes = buscaDestinacoes($con);
    $pessoa = selecionaPessoa($con, $_SESSION['cart'][$id]['FKPessoa']);


    if ($_SESSION['cart'][$id]['especie'] == 1) {
        $tipoPagamento = "Dinheiro";
        $especie = 1;
    }

    if ($_SESSION['cart'][$id]['especie'] == 2) {
        $tipoPagamento = "Depósito";
        $especie = 2;
    }

    if ($_SESSION['cart'][$id]['especie'] == 3) {
        $tipoPagamento = "Cheque";
        $especie = 3;
    }

?>

    <section class="container">

        <?php mostraAlerta('danger') ?>

        <h3>Alterar lançamento - <?=$pessoa['nome']?></h3>

        <div class="row">
            <div class="col-md-12">

            <h3 class="page-header text-center">Tipo da Oferta / Dízimo - <?=$tipoPagamento ?></h3>
            <form action="confirma-alteracao.php" method="post">

                <input type="hidden" name="id" value="<?=$id?>">
                <input type="hidden" name="especie" value="<?=$especie?>">

                <?php if ($_SESSION['cart'][$id]['especie'] == 1): ?>
                    <!-- DINHEIRO -->
                    <div class="col-md-12">
                        <label for="numero-cheque">Valor</label>
                        <div class="form-group">
                            <input type="text" class="form-control" name="dinheiro" value="<?=$_SESSION['cart'][$id]['valor']?>">
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ($_SESSION['cart'][$id]['especie'] == 2): ?>
                    <!-- DEPOSITO -->
                    <div class="col-md-6">
                        <label for="numero-cheque">N. do comprovante</label>
                        <div class="form-group">
                            <input type="text" class="form-control" name="deposito-comprovante" value="<?=$_SESSION['cart'][$id]['numero-comprovante']?>">
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label for="numero-cheque">Valor</label>
                        <div class="form-group">
                            <input type="text" class="form-control" name="deposito-valor" value="<?=$_SESSION['cart'][$id]['valor']?>">
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ($_SESSION['cart'][$id]['especie'] == 3): ?>
                    <!-- CHEQUE -->
                    <div class="col-md-12">

                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="numero-cheque">N. do cheque</label>
                                <input type="text" class="form-control" name="cheque-numero" value="<?=$_SESSION['cart'][$id]['numero-cheque']?>">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="nome-banco">Agência</label>
                                <input type="text" class="form-control" name="cheque-agencia" value="<?=$_SESSION['cart'][$id]['agencia']?>">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="nome-banco">Conta</label>
                                <input type="text" class="form-control" name="cheque-conta" value="<?=$_SESSION['cart'][$id]['conta']?>">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="nome-banco">Banco</label>
                                <select class="form-control" name="nome-banco">
                                    <option>Banco do Brasil</option>
                                    <option>Bradesco</option>
                                    <option>Caixa</option>
                                    <option>Itaú</option>
                                    <option>Santander</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="nome-banco">Valor</label>
                                <input type="text" class="form-control" name="cheque-valor" id="valor-cheque" value="<?=$_SESSION['cart'][$id]['valor']?>">
                            </div>
                        </div>
                    </div>
                <?php endif; ?>


                </div>
            </div>

            <div class="col-md-12">
                <h3 class="page-header text-center">Destinação</h3>
                <div class="form-group">
                    <select class="form-control" name="destinacao">
                        <?php foreach ($destinacoes as $destinacao):
                            $destinacaoCorreta = $_SESSION['cart'][$id]['FKDestinacao'] === $destinacao['iddestinacao'];
                            $selecao = $destinacaoCorreta ? "selected='selected'" : "";
                        ?>
                            <option value="<?=$destinacao['iddestinacao']?>" <?=$selecao?>>
                                <?=$destinacao['descricao']?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <button type="submit" class="btn btn-success">
                <span class="fa fa-thumbs-o-up"></span>
                Alterar
            </button>
        </form>

        <a href="form-lancamento.php" class="btn btn-primary">
            <span class="fa fa-angle-double-left"></span>
            Voltar
        </a>

    </section>

<?php require_once 'footer.php' ?>
