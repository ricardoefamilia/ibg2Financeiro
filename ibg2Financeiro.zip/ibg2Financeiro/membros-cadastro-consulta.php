<?php
require_once 'top.php';
require_once 'mostra-alerta.php';
require_once 'sql/banco-membros.php';

  $membros = consultaMembros($con);
?>

  <section class="container">

      <?php mostraAlerta('success'); ?>
      <?php mostraAlerta('warning'); ?>

    <br>
    <a href="form-membros.php" class="btn btn-success">
      <span class="fa fa-user-plus"></span>
      Cadastrar
    </a>
    <br>
    <br>

    <?php if (empty($membros)): ?>
        <p class="alert alert-warning text-center">Nenhum membro cadastrado</p>
    <?php else: ?>

        <table id="datatables" class="table table-hover">
            <thead>
              <tr>
                  <th class="text-center">Tipo</th>
                  <th class="text-center">Nome</th>
                  <th class="text-center">Telefone</th>
                  <th class="text-center">Ações</th>
              </tr>
            </thead>

            <tbody>
              <?php foreach ($membros as $membro): ?>
                <tr>
                    <td class="text-center">
                        <?php if ($membro['tipoPessoa'] == 1): ?>
                            Membro
                        <?php endif; ?>

                        <?php if ($membro['tipoPessoa'] == 0): ?>
                            Congregado
                        <?php endif; ?>
                    </td>
                  <td  class="text-center"><?=$membro['nome']?></td>
                  <td  class="text-center"><?=$membro['telefone']?></td>
                  <td class="text-center">

                    <a href="form-membros-alterar.php?id=<?=$membro['idPessoas']?>" class="btn btn-primary">
                      <span class="fa fa-refresh"></span>
                      Alterar
                    </a>


                    <a href="membros-cadastro-familiares.php?id=<?=$membro['idPessoas']?>" class="btn btn-primary">
                      <span class="fa fa-user-plus"></span>
                      Familiares
                    </a>

                    <a href="membros-cadastro-cursos.php?id=<?=$membro['idPessoas']?>" class="btn btn-primary">
                      <span class="fa fa-graduation-cap"></span>
                      Cursos
                    </a>

                       <!-- BTN MODAL -->
                       <button type="button" class="btn btn-danger btnModal" data-toggle="modal" data-target="#myModal-<?=$membro['idPessoas']?>">
                          <span class="fa fa-trash"></span>
                          Remover
                       </button>

                    <!-- Modal Remover -->
                    <div class="modal fade" id="myModal-<?=$membro['idPessoas']?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                      <div class="modal-dialog" role="document">

                         <!-- MODAL CONTENT -->
                        <div class="modal-content">

                          <div class="modal-header">
                             <button type="button" class="close" data-dismiss="modal">&times</button>
                             <h4>Excluir Membro</h4>
                          </div>

                          <!-- MODAL BODY -->
                          <div class="modal-body">
                             <p>Tem certeza que deseja excluir o membro?</p>
                          </div>

                          <!-- MODAL FOOTER -->
                          <div class="modal-footer">
                             <button type="button" class="btn btn-default" data-dismiss="modal">Não</button>
                             <a class="btn btn-primary" href="membros-cadastro-remove.php?id=<?=$membro['idPessoas']?>">
                                Sim
                             </a>
                          </div>
                        </div>

                      </div>
                    </div>

                  </td>
                </tr>
            <?php endforeach; ?>
            </tbody>

        </table>
    <?php endif; ?>
  </section>

<?php require_once 'footer.php' ?>
<script src="js/jquery.dataTables.js"></script>
<script src="js/dataTables.bootstrap.js"></script>

<script>
    $(document).ready(function () {
        $('#datatables').dataTable();
    })
</script>
