<?php
require_once 'top.php';
require_once 'mostra-alerta.php';
require_once 'sql/banco-membros.php';
require_once 'sql/banco-familiares.php';

  $id = $_GET['id'];
  $membro = consultaMembrosPorID($con, $id);

  $familiares = buscaMembrosFamiliares($con);
?>

  <section class="container">

      <?php mostraAlerta('success'); ?>

      <h3 class="page-header"><?=$membro['nome']?></h3>

    <br>
    <a href="form-membros-familiar.php?id=<?=$membro['idPessoas']?>" class="btn btn-success">
        <span class="fa fa-trash"></span>
        Cadastrar
    </a>
    <br>
    <br>

    <?php if (empty($familiares)): ?>
        <section class="container">
            <p class="alert alert-warning text-center">Nenhum familiar cadastrado</p>
            <p class="text-center"> <a href="membros-cadastro-consulta.php">Clique aqui</a> para voltar</p>
        </section>
    <?php else: ?>

        <table class="table table-hover">
            <thead>
              <tr>
                <th class="text-center">Nome</th>
                <th class="text-center">Parentesco</th>
                <th class="text-center">Ações</th>
              </tr>
            </thead>

            <tbody>
                <tr>
                  <td class="text-center">1</td>
                  <td class="text-center">1</td>
                  <td class="text-center">

                    <a href="" class="btn btn-primary">
                      <span class="fa fa-refresh"></span>
                      Alterar
                    </a>

                    <a href="" class="btn btn-primary">
                      <span class="fa fa-search"></span>
                      Consultar
                    </a>

                    <a type="button" class="btn btn-danger">
                      <span class="fa fa-trash"></span>
                      Remover
                    </a>

                  </td>
                </tr>
            </tbody>

        </table>
    <?php endif; ?>
  </section>

<?php require_once 'footer.php' ?>
