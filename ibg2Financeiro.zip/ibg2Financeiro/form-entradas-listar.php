<?php
require_once 'top.php';
require_once 'mostra-alerta.php';
require_once 'sql/banco-entradas.php';

$entradas = buscaEntradas($con);
$entradasCheque = buscaEntradasCheque($con);
$entradasDeposito = buscaEntradasDeposito($con);
//  echo '<pre>';
//  var_dump($_POST) or die;
?>
   <style type="text/css">
      .btn span.glyphicon {    			
           opacity: 0;				
   }
   .btn.active span.glyphicon {				
           opacity: 1;				
   }
   
   </style>

<section class="container">

    <?php
    mostraAlerta('danger');
    mostraAlerta('success');
    ?>

    <div class="row">



        <div class="col-xs-12">
            <div class="page-header">
                <h3> <i class="fa fa-list-alt"></i> Lista de Entradas a ser conferida! </h3>
            </div>

            <ul class="nav nav-tabs">
                <li class="active"><a data-toggle="tab" href="#dinheiro"><i class="fa fa-book"></i> Dinheiro</a></li>
                <li><a data-toggle="tab" href="#cheque"><i class="fa fa-book"></i> Cheque</a></li>
                <li><a data-toggle="tab" href="#doc"><i class="fa fa-book"></i> Transferências /  DOC</a></li>

            </ul>


            <form  method="POST" action="altera-lancamento.php" >
                <div class="tab-content">

                    <div id="dinheiro" class="tab-pane fade in active">
                        <div class="panel-body">
                           
                           
                            <table id="datatables" class="text-center table table-bordered table-hover">

                                <thead>
                                    <tr class="bg-primary">
                                        <th class="text-center">Especie</th>
                                        <th class="text-center">Valor</th>
                                        <th class="text-center">Data Lançamento</th>
                                        <th class="text-center">Confirmar </th>

                                        
                                    </tr>
                                </thead>

                                <tbody class="text-center">

                                    <?php $tot = 0; foreach ($entradas as $entrada) : ?>
                                        <tr>
                                            <td>
                                                <?php if ($entrada['especie'] == 1): ?>
                                                    Dinheiro
                                                <?php endif; ?>

                                                <?php if ($entrada['especie'] == 2): ?>
                                                    Depósito
                                                <?php endif; ?>

                                                <?php if ($entrada['especie'] == 3): ?>
                                                    Cheque
                                                <?php endif; ?>

                                            </td>
                                            <td>R$ <?= number_format($entrada['valor'], 2, ',', '.'); ?></td>
                                            <td> <?= date('d / m / Y', strtotime($entrada['dataLancamentoEntrada']));?><td>
                                                                                            
                                                
                                                <div class="btn-group" data-toggle="buttons">

                                                        <label class="btn btn-success">
                                                            <input type="checkbox" name="checkbox[]" value="<?= $entrada['idEntradas']; ?>" autocomplete="off">
                                                            <span class="glyphicon glyphicon-ok"></span>
                                                        </label>
                                                    </div>
                                                         
                                                
                                                         
                                            </td>

                                        </tr>

                                    <?php $tot += $entrada['valor'];  endforeach ?>
                                       
                                </tbody>

                            </table>
                            
                            
                            
                            <div class = "panel panel-primary">
                                <div class = "panel-heading">
                                    <h3 class = "panel-title">Valor total em Dinheiro:</h3>
                                </div>

                                <div class = "panel-body">
                                    <strong>  R$<?= number_format($tot, 2, ',', '.'); ?></strong>
                                </div>
                            </div> 
                            
                            
                        </div>
                    </div>
                   
                    <!--FIM DINHEIRO-->



                    <!--INICIO CHEQUE-->
                    <div id="cheque" class="tab-pane fade ">
                        <div class="panel-body">
                                                      
                            <table id="datatables2" class="text-center table table-bordered table-hover">

                                <thead>
                                    <tr class="bg-info">
                                        <th class="text-center">Especie</th>
                                        <th class="text-center">Valor</th>
                                        <th class="text-center">Data Lançamento</th>
                                        <th class="text-center">Confirmar</th>

                                    </tr>
                                </thead>

                                <tbody class="text-center">

                                    <?php foreach ($entradasCheque as $entradaCheque) : ?>
                                        <tr>
                                            <td>
                                                <?php if ($entradaCheque['especie'] == 3): ?>
                                                    Cheque
                                                <?php endif; ?>


                                            </td>
                                            <td>R$ <?= number_format($entradaCheque['valor'], 2, ',', '.'); ?></td>
                                            <td><?=date('d / m / Y', strtotime($entradaCheque['dataLancamentoEntrada']));?></td>
                                            <td>
                                             
                                                <div class="btn-group" data-toggle="buttons">

                                                        <label class="btn btn-success">
                                                            <input type="checkbox" name="checkbox[]" value="<?= $entradaCheque['idEntradas']; ?>" autocomplete="off">
                                                            <span class="glyphicon glyphicon-ok"></span>
                                                        </label>
                                                    </div>

                                            </td>

                                        </tr>

                                    <?php endforeach ?>

                                </tbody>

                            </table>


                        </div>
                    </div>
                   
                    <!--FIM CHEQUE-->


                    <!--INICIO DEPOSIT / DOC-->
                    <div id="doc" class="tab-pane fade">
                        <div class="panel-body">

                            <table id="datatables3" class="text-center table table-bordered table-hover">

                                <thead>
                                    <tr class="bg-warning">
                                        <th class="text-center">Nº Comprovante</th>
                                        <th class="text-center">Valor</th>
                                        <th class="text-center">Data Lançamento</th>
                                        <th class="text-center">Confirmar</th>

                                    </tr>
                                </thead>

                                <tbody class="text-center">

                                    <?php foreach ($entradasDeposito as $entradaDeposito) : ?>
                                        <tr>
                                            <td>
                                                <?= $entradaDeposito['nrDepositoComprovante'] ?>


                                            </td>
                                            <td>R$ <?= number_format($entradaDeposito['valor'], 2, ',', '.'); ?></td>
                                            <td><?= date('d / m / Y', strtotime($entradaDeposito['dataLancamentoEntrada']));?></td>
                                            <td>
                                                

                                                <div class="btn-group" data-toggle="buttons">
                                                    <label class="btn btn-success">
                                                         <input type="checkbox" name="checkbox[]" value="<?= $entradaDeposito['idEntradas']; ?>" autocomplete="off">
                                                         <span class="glyphicon glyphicon-ok"></span>
                                                    </label>
                                                </div>

                                            </td>

                                        </tr>

                                    <?php endforeach ?>

                                </tbody>

                            </table>

                        </div>
                    </div>
                    <!--FIM DOC-->
                </div>


<!-- Button trigger modal -->
<button type="button" class="btn btn-success center-block" data-toggle="modal" data-target="#Modal">
  <span class="fa fa-check"></span>
    Confirma lançamento
</button>
                

<!-- Modal -->
<div class="modal fade" id="Modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Deseja confirmar?</h4>
      </div>
      <div class="modal-body">
        Deseja realmente confirmar lançamentos selecionados?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
        <button type="submit" class="btn btn-success">Confirmar</button>
      </div>
    </div>
  </div>
</div>

                
            </form>

        </div>


</section>



<?php require_once 'footer.php' ?>
<script src="js/jquery.dataTables.js"></script>
<script src="js/dataTables.bootstrap.js"></script>

<script>
    $(document).ready(function () {
        $('#datatables').dataTable();
    })
    
    
     $(document).ready(function () {
        $('#datatables2').dataTable();
    })
    
     $(document).ready(function () {
        $('#datatables3').dataTable();
    })
    
    
</script>