<?php
   require_once 'top.php';
   require_once 'sql/banco-membros.php';
   require_once 'sql/banco-familiares.php';
   
   //require_once 'sql/banco-uf.php';
   //require_once 'sql/banco-orgao.php';
   require_once 'sql/banco-dom.php';


   $id = $_GET['id'];
   $membro = consultaMembrosPorID($con, $id);
   
   $familiar = consultaFamiliaresPorID($con, $id);
//   echo'<pre>';
//   var_dump($membro) or die;
  
   //  $estados = buscaEstados($con);
  //$orgaos = buscaOrgaos($con);
   $dons = listaDons($con);

  //  echo "<pre>";
  //   print_r($orgaos);
  //  echo "</pre>";
?>


   <section class="container">
      <h2 class="page-header">Alterar - <?=$membro['nome'] ?> </h2>

      <ul class="nav nav-tabs">
         <li class="active"><a data-toggle="tab" href="#dados-pessoais">Dados pessoais</a></li>
         <li><a data-toggle="tab" href="#enderecoTab">Endereço</a></li>
         <li><a data-toggle="tab" href="#filiacao">Filiação</a></li>
         <li><a data-toggle="tab" href="#trabalho">Trabalho</a></li>
         <li><a data-toggle="tab" href="#igreja">Igreja</a></li>
         <li><a data-toggle="tab" href="#dons">Dons</a></li>
         <li><a data-toggle="tab" href="#ibg2">IBG2</a></li>
      </ul>

      <form action="membros-cadastro-alterar.php?id=<?=$membro['idPessoas'] ?>" method="post" id="form-membros">
      <div class="tab-content">

         <div id="dados-pessoais" class="tab-pane fade in active">
            <div class="panel-body">

               <div class="row">

                     <div class="col-sm-12">
                        <div class="form-group">
                           <label for="tipo-pessoa">
                              Tipo de pessoa
                              <span class="red-color fa fa-asterisk"></span>
                           </label>
                           <div class="radio">
                               <?php if ($membro['tipoPessoa'] == 1): ?>
                                   <label for="">
                                       <input type="radio" name="tipoPessoa" value="1" checked>Membro
                                   </label>
                               <?php else: ?>
                                   <label for="">
                                       <input type="radio" name="tipoPessoa" value="1">Membro
                                   </label>
                               <?php endif ?>

                               <?php if ($membro['tipoPessoa'] == 0): ?>
                                   <label for="">
                                       <input type="radio" name="tipoPessoa" value="0" checked>Congregado
                                   </label>
                               <?php else: ?>
                                   <label for="">
                                       <input type="radio" name="tipoPessoa" value="0">Congregado
                                   </label>
                               <?php endif ?>
                           </div>
                        </div>
                     </div>

                     <div class="col-sm-5">
                        <div class="form-group">
                           <label for="nome">
                              Nome
                              <span class="red-color fa fa-asterisk"></span>
                           </label>
                           <input type="text" name="nome" id="nome" value="<?=$membro['nome']?>" class="form-control" >
                        </div>
                     </div>

                     <div class="col-md-4">
                        <div class="form-group">
                           <label for="">E-mail</label>
                           <input type="text" name="emailPessoal" value="<?=$membro['emailPessoal']?>" class="form-control">
                        </div>
                     </div>

                     <div class="col-sm-3">
                        <label for="sexo">
                           Sexo
                           <span class="red-color fa fa-asterisk"></span>
                        </label>
                        <div class="radio">
                            <?php if ($membro['sexo'] == 1): ?>
                                <label for="">
                                    <input type="radio" name="sexo" value="1" checked>Masculino
                                </label>
                            <?php else: ?>
                                <label for="">
                                    <input type="radio" name="sexo" value="1">Masculino
                                </label>
                            <?php endif ?>

                            <?php if ($membro['sexo'] == 0): ?>
                                <label for="">
                                    <input type="radio" name="sexo" value="0" checked>Feminino
                                </label>
                            <?php else : ?>
                                <label for="">
                                    <input type="radio" name="sexo" value="0">Feminino
                                </label>
                            <?php endif ?>
                        </div>
                     </div>
               </div>

               <div class="row">

                 <div class="col-sm-5">
                    <div class="form-group">
                       <label for="orgaoExpedidor">
                          Órgão expedidor
                          <span class="red-color fa fa-asterisk"></span>
                       </label>
                      <input type="text" name="orgaoExpedidor"  value="<?=$membro['orgaoExpedidor']?>" class="form-control" >
                    </div>
                 </div>

                  <div class="col-sm-3">
                     <div class="form-group">
                        <label for="rg">
                           Nº da identidade
                           <span class="red-color fa fa-asterisk"></span>
                        </label>
                        <input type="text" name="rg" id="rg" value="<?=$membro['rg']?>" class="form-control" >
                     </div>
                  </div>



                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="">
                           CPF
                           <span class="red-color fa fa-asterisk"></span>
                        </label>
                        <input type="text" name="cpf" id="cpf" value="<?=$membro['cpf']?>" class="form-control" >
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="dataNascimento">
                            Data de Nascimento
                            <span class="red-color fa fa-asterisk"></span>
                         </label>
                         <input type="date" name="nascimento" id="nascimento" value="<?=$membro['dataNascimento']?>" class="form-control datepicker" >
                     </div>
                  </div>


               </div>


               <div class="row">
                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="">
                              Nascimento - UF
                              <span class="red-color fa fa-asterisk"></span>
                           </label>
                        <select name="nascimentoEstado" id="nascimentoEstado" class="form-control" >
                             <option value="AC"<?php if ($membro['estadoNascimento'] == "AC") {echo "selected";} ?>>Acre</option>
                             <option value="AL"<?php if ($membro['estadoNascimento'] == "AL") {echo "selected";} ?>>Alagoas</option>
                             <option value="AP"<?php if ($membro['estadoNascimento'] == "AP") {echo "selected";} ?>>Amapá</option>
                             <option value="AM"<?php if ($membro['estadoNascimento'] == "AM") {echo "selected";} ?>>Amazonas</option>
                             <option value="BA"<?php if ($membro['estadoNascimento'] == "BA") {echo "selected";} ?>>Bahia</option>
                             <option value="CE"<?php if ($membro['estadoNascimento'] == "CE") {echo "selected";} ?>>Ceará</option>
                             <option value="DF"<?php if ($membro['estadoNascimento'] == "DF") {echo "selected";} ?>>Distrito Federal</option>
                             <option value="ES"<?php if ($membro['estadoNascimento'] == "ES") {echo "selected";} ?>>Espírito Santo</option>
                             <option value="GO"<?php if ($membro['estadoNascimento'] == "GO") {echo "selected";} ?>>Goiás</option>
                             <option value="MA"<?php if ($membro['estadoNascimento'] == "MA") {echo "selected";} ?>>Maranhão</option>
                             <option value="MT"<?php if ($membro['estadoNascimento'] == "MT") {echo "selected";} ?>>Mato Grosso</option>
                             <option value="MS"<?php if ($membro['estadoNascimento'] == "MS") {echo "selected";} ?>>Mato Grosso do Sul</option>
                             <option value="MG"<?php if ($membro['estadoNascimento'] == "MG") {echo "selected";} ?>>Minas Gerais</option>
                             <option value="PA"<?php if ($membro['estadoNascimento'] == "PA") {echo "selected";} ?>>Pará</option>
                             <option value="PB"<?php if ($membro['estadoNascimento'] == "PB") {echo "selected";} ?>>Paraíba</option>
                             <option value="PR"<?php if ($membro['estadoNascimento'] == "PR") {echo "selected";} ?>>Paraná</option>
                             <option value="PE"<?php if ($membro['estadoNascimento'] == "PE") {echo "selected";} ?>>Pernambuco</option>
                             <option value="PI"<?php if ($membro['estadoNascimento'] == "PI") {echo "selected";} ?>>Piauí</option>
                             <option value="RJ"<?php if ($membro['estadoNascimento'] == "RJ") {echo "selected";} ?>>Rio de Janeiro</option>
                             <option value="RN"<?php if ($membro['estadoNascimento'] == "RN") {echo "selected";} ?>>Rio Grande do Norte</option>
                             <option value="RS"<?php if ($membro['estadoNascimento'] == "RS") {echo "selected";} ?>>Rio Grande do Sul</option>
                             <option value="RO"<?php if ($membro['estadoNascimento'] == "RO") {echo "selected";} ?>>Rondônia</option>
                             <option value="RR"<?php if ($membro['estadoNascimento'] == "RR") {echo "selected";} ?>>Roraima</option>
                             <option value="SC"<?php if ($membro['estadoNascimento'] == "SC") {echo "selected";} ?>>Santa Catarina</option>
                             <option value="SP"<?php if ($membro['estadoNascimento'] == "SP") {echo "selected";} ?>>São Paulo</option>
                             <option value="SE"<?php if ($membro['estadoNascimento'] == "SE") {echo "selected";} ?>>Sergipe</option>
                             <option value="TO"<?php if ($membro['estadoNascimento'] == "TO") {echo "selected";} ?>>Tocantins</option>

                           </select>
                     </div>
                  </div>

                  <div class="col-sm-3">
                     <div class="form-group">
                        <label for="">
                              Nascimento - Cidade
                              <span class="red-color fa fa-asterisk"></span>
                           </label>
                        <input type="text" name="nascimentoCidade" id="cidade-nascimento" value="<?=$membro['cidadeNascimento']?>" class="form-control" >
                     </div>
                  </div>

                  <div class="col-sm-3">
                     <div class="form-group">
                        <label for="">
                              Estado Civil
                              <span class="red-color fa fa-asterisk"></span>
                           </label>
                        <select class="form-control" name="estadoCivil" id="estado-civil" >
                            <?php if ($membro['estadoCivil'] == 1) : ?>
                              <option value="1" selected>Solteiro(a)</option>
                            <?php else : ?>
                              <option value="1">Solteiro(a)</option>
                            <?php endif ?>

                            <?php if ($membro['estadoCivil'] == 2) : ?>
                              <option value="2" selected>Casado(a)</option>
                            <?php else: ?>
                              <option value="2">Casado(a)</option>
                            <?php endif ?>

                            <?php if ($membro['estadoCivil'] == 3) : ?>
                              <option value="3" selected>Divorciado(a)</option>
                            <?php else: ?>
                              <option value="3">Divorciado(a)</option>
                            <?php endif ?>

                            <?php if ($membro['estadoCivil'] == 4) : ?>
                              <option value="4" selected>Separado(a)</option>
                            <?php else: ?>
                              <option value="4">Separado(a)</option>
                            <?php endif ?>

                            <?php if ($membro['estadoCivil'] == 5) : ?>
                              <option value="5" selected>Viúvo(a)</option>
                            <?php else: ?>
                              <option value="5">Viúvo(a)</option>
                            <?php endif ?>
                        </select>
                     </div>
                  </div>


                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="">
                              Tipo sanguineo
                              <span class="red-color fa fa-asterisk"></span>
                           </label>
                        <select class="form-control" name="tipoSanguineo" id="tipo-sanguineo" >

                            <?php if ($membro['tipoSanguineo'] == 1): ?>
                                <option value="1" selected>O</option>
                            <?php else: ?>
                                <option value="1">O</option>
                            <?php endif ?>

                            <?php if ($membro['tipoSanguineo'] == 2): ?>
                                <option value="2" selected>A</option>
                            <?php else: ?>
                                <option value="2">A</option>
                            <?php endif ?>

                            <?php if ($membro['tipoSanguineo'] == 3): ?>
                                <option value="3" selected>B</option>
                            <?php else: ?>
                                <option value="3">B</option>
                            <?php endif; ?>

                            <?php if ($membro['tipoSanguineo'] == 4): ?>
                                <option value="4" selected>AB</option>
                            <?php else: ?>
                                <option value="4">AB</option>
                            <?php endif; ?>
                        </select>
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="">Fator RH</label>
                        <input type="text" name="fatorRh" value="<?=$membro['fatorRh']?>" class="form-control">
                     </div>
                  </div>

               </div>

               <div class="row">


                  <div class="col-sm-4">
                     <div class="form-group">
                        <label>
                              Grau de instrução
                              <span class="red-color fa fa-asterisk"></span>
                           </label>

                        <select class="form-control" name="escolaridade" id="escolaridade" >
                             <optgroup label="Ensino Fundamental">
                                 <?php if ($membro['escolaridade'] == 1): ?>
                                     <option value="1" selected>Ensino Fundamental incompleto</option>
                                 <?php else: ?>
                                     <option value="1">Ensino Fundamental incompleto</option>
                                 <?php endif ?>

                                 <?php if ($membro['escolaridade'] == 2): ?>
                                     <option value="2" selected>Ensino Fundamental cursando</option>
                                 <?php else: ?>
                                     <option value="2">Ensino Fundamental cursando</option>
                                 <?php endif ?>

                                 <?php if ($membro['escolaridade'] == 3): ?>
                                     <option value="3" selected>Ensino Fundamental completo</option>
                                 <?php else: ?>
                                     <option value="3">Ensino Fundamental completo</option>
                                 <?php endif ?>
                             </optgroup>

                             <optgroup label="Ensino Médio">
                                 <?php if ($membro['escolaridade'] == 4): ?>
                                     <option value="4" selected>Ensino Médio incompleto</option>
                                 <?php else: ?>
                                     <option value="4">Ensino Médio incompleto</option>
                                 <?php endif ?>

                                 <?php if ($membro['escolaridade'] == 5): ?>
                                     <option value="5" selected>Ensino Médio cursando</option>
                                 <?php else: ?>
                                     <option value="5">Ensino Médio cursando</option>
                                 <?php endif ?>

                                 <?php if ($membro['escolaridade'] == 6): ?>
                                     <option value="6" selected>Ensino Médio completo</option>
                                 <?php else: ?>
                                     <option value="6">Ensino Médio completo</option>
                                 <?php endif ?>
                             </optgroup>

                             <optgroup label="Ensino Superior">

                                 <?php if ($membro['escolaridade'] == 7): ?>
                                     <option value="7" selected>Ensino Superior incompleto</option>
                                 <?php else: ?>
                                     <option value="7">Ensino Superior incompleto</option>
                                 <?php endif ?>

                                 <?php if ($membro['escolaridade'] == 8): ?>
                                     <option value="8" selected>Ensino Superior cursando</option>
                                 <?php else: ?>
                                     <option value="8">Ensino Superior cursando</option>
                                 <?php endif ?>

                                 <?php if ($membro['escolaridade'] == 9): ?>
                                     <option value="9" selected>Ensino Superior completo</option>
                                 <?php else: ?>
                                     <option value="9">Ensino Superior completo</option>
                                 <?php endif ?>

                             </optgroup>
                          </select>
                     </div>
                  </div>

               </div>
            </div>
         </div>
         <!-- fim dados pessoais -->

         <div id="enderecoTab" class="tab-pane fade">
            <div class="panel-body">

               <div class="row">

                  <div class="col-md-2">
                     <div class="form-group">
                        <label for="cep">
                           CEP
                           <span class="red-color fa fa-asterisk"></span>
                        </label>
                        <input type="text" id="cep" name="cep" value="<?=$membro['cepEndereco']?>" class="form-control" onblur="pesquisacep(this.value);"  >
                     </div>
                  </div>

                  <div class="col-md-4">
                     <div class="form-group">
                        <label for="endereco">
                           Endereço
                           <span class="red-color fa fa-asterisk"></span>
                        </label>
                        <input type="text" id="endereco" name="endereco" value="<?=$membro['logradouroEndereco']?>" class="form-control" readonly>
                     </div>
                  </div>

                  <div class="col-md-3">
                     <div class="form-group">
                        <label for="">
                           Cidade
                           <span class="red-color fa fa-asterisk"></span>
                           </label>
                        <input type="text" id="cidade" name="cidade" value="<?=$membro['cidadeEndereco']?>" class="form-control" readonly>
                     </div>
                  </div>

                  <div class="col-md-1">
                     <div class="form-group">
                        <label for="">
                           UF
                           <span class="red-color fa fa-asterisk"></span>
                           </label>
                        <input type="text" name="estado" id="estado" value="<?=$membro['EstadoEndereco']?>" class="form-control" readonly>
                     </div>
                  </div>

                  <div class="col-md-2">
                     <div class="form-group">
                        <label for="">
                          Bairro
                          <span class="red-color fa fa-asterisk"></span>
                        </label>
                        <input type="text" id="bairro" name="bairro" value="<?=$membro['bairroEndereco']?>" class="form-control" readonly>
                     </div>
                  </div>

               </div>

               <div class="row">

                   <div class="col-md-2">
                      <div class="form-group">
                         <label for="">
                           Número
                           <span class="red-color fa fa-asterisk"></span>
                         </label>
                         <input type="text" name="numero" value="<?=$membro['numeroEndereco']?>" class="form-control">
                      </div>
                   </div>

                   <div class="col-md-4">
                      <div class="form-group">
                         <label for="">
                           Complemento
                           <span class="red-color fa fa-asterisk"></span>
                         </label>
                         <input type="text" name="complemento" value="<?=$membro['complementoEndereco']?>" class="form-control">
                      </div>
                   </div>

                   <div class="col-md-3">
                     <div class="form-group">
                       <label for="">Telefone</label>
                       <input type="text" id="telefone" name="telefone" value="<?=$membro['telefone']?>" class="form-control">
                     </div>
                   </div>

                   <div class="col-md-3">
                     <div class="form-group">
                       <label for="">Celular</label>
                       <input type="text" id="celular" name="celular" value="<?=$membro['celular']?>" class="form-control">
                     </div>
                   </div>
               </div>

            </div>
         </div>
         <!-- fim endereço -->

         <div id="filiacao" class="tab-pane fade">
            <div class="panel-body">
               <div class="row">
                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="nomePai">Nome do pai</label>
                        <input type="text" name="nomePai" class="form-control" value="<?=$familiar['nomePai']?>">
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="paiEvangelico">É evangélico?</label>
                        <div class="radio">

                            <?php if ($familiar['paiEvangelico'] == 1): ?>
                                <label for="">
                                    <input type="radio" name="paiEvangelico" value="1" checked> Sim
                                </label>
                            <?php else: ?>
                                <label for="">
                                    <input type="radio" name="paiEvangelico" value="1"> Sim
                                </label>
                            <?php endif ?>

                            <?php if ($familiar['paiEvangelico'] == 0): ?>
                                <label for="">
                                   <input type="radio" name="paiEvangelico" value="0" checked> Não
                                </label>
                            <?php else: ?>
                                <label for="">
                                   <input type="radio" name="paiEvangelico" value="0"> Não
                                </label>
                            <?php endif ?>


                        </div>
                     </div>
                  </div>

                  <div class="col-sm-6">
                     <div class="form-group">
                        <label for="nomePai">Nome da igreja</label>
                        <input type="text" name="igrejaPai" class="form-control" value="<?=$familiar['igrejaPai']?>">
                     </div>
                  </div>

               </div>

               <div class="row">

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="nomePai">Nome da mãe</label>
                        <input type="text" name="nomeMae" class="form-control" value="<?=$familiar['nomeMae']?>">
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="maeEvangelica">É evangélica?</label>
                        <div class="radio">

                            <?php if ($familiar['maeEvangelica'] == 1): ?>
                                <label for="">
                                   <input type="radio" name="maeEvangelica" value="1" checked> Sim
                                </label>
                            <?php else: ?>
                                <label for="">
                                   <input type="radio" name="maeEvangelica" value="1"> Sim
                                </label>
                            <?php endif ?>

                            <?php if ($familiar['maeEvangelica'] == 0): ?>
                                <label for="">
                                   <input type="radio" name="maeEvangelica" value="0" checked> Não
                                </label>
                            <?php else: ?>
                                <label for="">
                                   <input type="radio" name="maeEvangelica" value="0"> Não
                                </label>
                            <?php endif ?>

                        </div>
                     </div>
                  </div>

                  <div class="col-sm-6">
                     <div class="form-group">
                        <label for="nomePai">Nome da igreja</label>
                        <input type="text" name="igrejaMae" class="form-control" value="<?=$familiar['igrejaMae']?>">
                     </div>
                  </div>

               </div>

               <h3 class="page-header">Conjugê</h3>
               <div class="row">

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Nome</label>
                        <input type="text" name="nomeConjuge" class="form-control" value="<?=$familiar['nomeConjuge']?>">
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="conjugeEvangelico">É evangélico(a)?</label>
                        <div class="radio">

                            <?php if ($familiar['conjugeEvangelico'] == 1): ?>
                                <label for="">
                                      <input type="radio" name="conjugeEvangelico" value="1" checked> Sim
                                </label>
                            <?php else: ?>
                                <label for="">
                                      <input type="radio" name="conjugeEvangelico" value="1"> Sim
                                </label>
                            <?php endif ?>

                            <?php if ($familiar['conjugeEvangelico'] == 0): ?>
                                <label for="">
                                      <input type="radio" name="conjugeEvangelico" value="0" checked> Não
                                </label>
                            <?php else: ?>
                                <label for="">
                                      <input type="radio" name="conjugeEvangelico" value="0"> Não
                                </label>
                            <?php endif ?>



                        </div>
                     </div>
                  </div>

                  <div class="col-sm-6">
                     <div class="form-group">
                        <label for="nomePai">Nome da igreja</label>
                        <input type="text" name="igrejaConjuge" class="form-control" value="<?=$familiar['igrejaConjuge']?>">
                     </div>
                  </div>

               </div>

               <div class="row">

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Data de nascimento</label>
                        <input type="date" name="dataNascimentoConjuge" class="form-control" value="<?=$familiar['dataNascimentoConjuge']?>">
                     </div>
                  </div>

                  <div class="col-sm-4 col-sm-offset-2">
                     <div class="form-group">
                        <label for="">Data de casamento</label>
                        <input type="date" name="dataCasamento" class="form-control" value="<?=$familiar['dataCasamento']?>">
                     </div>
                  </div>

               </div>
            </div>
         </div>

         <div id="trabalho" class="tab-pane fade">
            <div class="panel-body">
               <div class="row">

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Nome</label>
                        <input type="text" name="empresaNome" class="form-control" value="<?=$membro['nomeEmpresa']?>">
                     </div>
                  </div>

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Cargo</label>
                        <input type="text" name="empresaCargo" class="form-control" value="<?=$membro['cargoEmpresa']?>">
                     </div>
                  </div>

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Profissão</label>
                        <input type="text" name="profissao" class="form-control" value="<?=$membro['profissao']?>">
                     </div>
                  </div>

               </div>

               <div class="row">

                  <div class="col-sm-2">
                    <div class="form-group">
                      <label for="">Cep</label>
                      <input type="text" name="empresaCep" class="form-control" value="<?=$membro['cepEmpresa']?>">
                    </div>
                  </div>

                  <div class="col-sm-2">
                    <div class="form-group">
                        <label for="">UF</label>
                        <input type="text" name="empresaEstado" class="form-control" value="<?=$membro['estadoEmpresa']?>">
                    </div>
                  </div>


                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Endereço</label>
                        <input type="text" name="empresaEndereco" class="form-control" value="<?=$membro['enderecoEmpresa']?>">
                     </div>
                  </div>

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Cidade</label>
                        <input type="text" name="empresaCidade" class="form-control" value="<?=$membro['cidadeEmpresa']?>">
                     </div>
                  </div>
               </div>

               <div class="row">

                 <div class="col-sm-2">
                    <div class="form-group">
                       <label for="">Número</label>
                       <input type="text" name="empresaNumero" class="form-control" value="<?=$membro['numeroEmpresa']?>">
                    </div>
                 </div>

                 <div class="col-sm-2">
                   <div class="form-group">
                     <label for="">Bairro</label>
                     <input type="text" name="empresaBairro" class="form-control" value="<?=$membro['bairroEmpresa']?>">
                   </div>
                 </div>

                 <div class="col-sm-4">
                    <div class="form-group">
                       <label for="">Complemento</label>
                       <input type="text" name="empresaComplemento" class="form-control" value="<?=$membro['complementoEmpresa']?>">
                    </div>
                 </div>

                 <div class="col-sm-4">
                    <div class="form-group">
                       <label for=""> Data de admissão</label>
                       <input type="date" name="dataAdmissao" class="form-control" value="<?=$membro['dataAdmissao']?>">
                    </div>
                 </div>


               </div>
            </div>
         </div>

          <div id="igreja" class="tab-pane fade">
            <div class="panel-body">
               <div class="row">
                   <legend>Batismo</legend>
                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Igreja onde foi batizado</label>
                        <input type="text" name="igrejaBatismoNomeIgreja" class="form-control" value="<?=$membro['nomeIgrejaBatismo']?>">
                     </div>
                  </div>

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Data de batismo</label>
                        <input type="date" name="igrejaBatismoDataBatismo" class="form-control datepicker" value="<?=$membro['dataBatismo']?>">
                     </div>
                  </div>

               </div>

               <div class="row">
                   <legend>Igreja de origem</legend>

                   <div class="col-sm-4">
                      <div class="form-group">
                         <label for="">Nome</label>
                         <input type="text" name="igrejaOrigemNome" class="form-control" value="<?=$membro['igrejaOrigem']?>">
                      </div>
                   </div>

                   <div class="col-sm-4">
                       <div class="form-group">
                           <label for="">Endereço</label>
                           <input type="text" name="igrejaOrigemEndereco" class="form-control" value="<?=$membro['logradouroIgrejaOrigem']?>">
                       </div>
                   </div>

                   <div class="col-sm-4">
                       <div class="form-group">
                           <label for="">Cidade</label>
                           <input type="text" name="igrejaOrigemCidade" class="form-control" value="<?=$membro['cidadeIgrejaOrigem']?>">
                       </div>
                   </div>
               </div>

               <div class="row">

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="">Cep</label>
                        <input type="text" id="cepp" name="igrejaOrigemCep" class="form-control" value="<?=$membro['cepIgrejaOrigem']?>">
                     </div>
                  </div>

                  <div class="col-sm-2">
                    <div class="form-group">
                       <label for="">UF</label>
                       <select name="igrejaOrigemEstado" class="form-control">
                            <option value="AC"<?php if ($membro['estadoIgrejaOrigem'] == "AC") {echo "selected";} ?>>Acre</option>
                             <option value="AL"<?php if ($membro['estadoIgrejaOrigem'] == "AL") {echo "selected";} ?>>Alagoas</option>
                             <option value="AP"<?php if ($membro['estadoIgrejaOrigem'] == "AP") {echo "selected";} ?>>Amapá</option>
                             <option value="AM"<?php if ($membro['estadoIgrejaOrigem'] == "AM") {echo "selected";} ?>>Amazonas</option>
                             <option value="BA"<?php if ($membro['estadoIgrejaOrigem'] == "BA") {echo "selected";} ?>>Bahia</option>
                             <option value="CE"<?php if ($membro['estadoIgrejaOrigem'] == "CE") {echo "selected";} ?>>Ceará</option>
                             <option value="DF"<?php if ($membro['estadoIgrejaOrigem'] == "DF") {echo "selected";} ?>>Distrito Federal</option>
                             <option value="ES"<?php if ($membro['estadoIgrejaOrigem'] == "ES") {echo "selected";} ?>>Espírito Santo</option>
                             <option value="GO"<?php if ($membro['estadoIgrejaOrigem'] == "GO") {echo "selected";} ?>>Goiás</option>
                             <option value="MA"<?php if ($membro['estadoIgrejaOrigem'] == "MA") {echo "selected";} ?>>Maranhão</option>
                             <option value="MT"<?php if ($membro['estadoIgrejaOrigem'] == "MT") {echo "selected";} ?>>Mato Grosso</option>
                             <option value="MS"<?php if ($membro['estadoIgrejaOrigem'] == "MS") {echo "selected";} ?>>Mato Grosso do Sul</option>
                             <option value="MG"<?php if ($membro['estadoIgrejaOrigem'] == "MG") {echo "selected";} ?>>Minas Gerais</option>
                             <option value="PA"<?php if ($membro['estadoNascimento'] == "PA") {echo "selected";} ?>>Pará</option>
                             <option value="PB"<?php if ($membro['estadoIgrejaOrigem'] == "PB") {echo "selected";} ?>>Paraíba</option>
                             <option value="PR"<?php if ($membro['estadoIgrejaOrigem'] == "PR") {echo "selected";} ?>>Paraná</option>
                             <option value="PE"<?php if ($membro['estadoIgrejaOrigem'] == "PE") {echo "selected";} ?>>Pernambuco</option>
                             <option value="PI"<?php if ($membro['estadoIgrejaOrigem'] == "PI") {echo "selected";} ?>>Piauí</option>
                             <option value="RJ"<?php if ($membro['estadoIgrejaOrigem'] == "RJ") {echo "selected";} ?>>Rio de Janeiro</option>
                             <option value="RN"<?php if ($membro['estadoIgrejaOrigem'] == "RN") {echo "selected";} ?>>Rio Grande do Norte</option>
                             <option value="RS"<?php if ($membro['estadoIgrejaOrigem'] == "RS") {echo "selected";} ?>>Rio Grande do Sul</option>
                             <option value="RO"<?php if ($membro['estadoIgrejaOrigem'] == "RO") {echo "selected";} ?>>Rondônia</option>
                             <option value="RR"<?php if ($membro['estadoIgrejaOrigem'] == "RR") {echo "selected";} ?>>Roraima</option>
                             <option value="SC"<?php if ($membro['estadoIgrejaOrigem'] == "SC") {echo "selected";} ?>>Santa Catarina</option>
                             <option value="SP"<?php if ($membro['estadoIgrejaOrigem'] == "SP") {echo "selected";} ?>>São Paulo</option>
                             <option value="SE"<?php if ($membro['estadoIgrejaOrigem'] == "SE") {echo "selected";} ?>>Sergipe</option>
                             <option value="TO"<?php if ($membro['estadoIgrejaOrigem'] == "TO") {echo "selected";} ?>>Tocantins</option>

                       </select>
                    </div>
                 </div>

                 <div class="col-sm-2">
                    <div class="form-group">
                       <label for="">Número</label>
                       <input type="text" name="igrejaOrigemNumero" class="form-control" value="<?=$membro['numeroIgrejaOrigem']?>">
                    </div>
                 </div>

                 <div class="col-sm-2">
                   <div class="form-group">
                     <label for="">Bairro</label>
                     <input type="text" name="igrejaOrigemBairro" class="form-control" value="<?=$membro['bairroIgrejaOrigem']?>">
                   </div>
                 </div>

                 <div class="col-sm-4">
                    <div class="form-group">
                       <label for="">Complemento</label>
                       <input type="text" name="igrejaOrigemComplemento" class="form-control" value="<?=$membro['complementoIgrejaOrigem']?>">
                    </div>
                 </div>

             </div>


               <div class="row">

                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Telefone</label>
                        <input type="text" id="igrejaOigemTelefone" name="igrejaOigemTelefone" class="form-control" value="<?=$membro['telefoneIgrejaOigem']?>">
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <div class="form-group">
                        <label for="">Dizimista</label>
                        <select class="form-control" name="igrejaOrigemDizimista" value="<?=$membro['igrejaOrigemDizimista']?>">
                            <?php if ($membro['dizimistaIgrejaOrigem'] == 1): ?>
                                <option value="1" selected>Sim</option>
                            <?php else: ?>
                                <option value="1">Sim</option>
                            <?php endif ?>

                            <?php if ($membro['dizimistaIgrejaOrigem'] == 0): ?>
                                <option value="0" selected>Não</option>
                            <?php else: ?>
                                <option value="0">Não</option>
                            <?php endif ?>
                        </select>
                     </div>
                  </div>

                  <div class="col-sm-12">
                     <div class="form-group">
                        <label for="">Atividades desenvolvidas em outras igrejas</label>
                        <textarea class="form-control" name="igrejaOrigemAtividades"><?=$membro['atividadesIgrejaOrigem'] ?></textarea>
                     </div>
                  </div>
               </div>

            </div>
         </div>

         <div id="dons" class="tab-pane fade">
            <div class="panel-body">
               <div class="row">

               <div class="row">

                  <div class="col-sm-12">
                     <div class="form-group">
                        <label for="entrega-dizimo">Compromete-se a entregar os seus dízimos neste Igreja?</label>

                        <?php if ($membro['dizimistaIgrejaAtual'] == 1): ?>
                            <label class="radio-inline">
                                <input type="radio" name="dizimistaFiel" value="1" checked>Sim
                            </label>
                        <?php else: ?>
                            <label class="radio-inline">
                                <input type="radio" name="dizimistaFiel" value="1">Sim
                            </label>
                        <?php endif ?>

                        <?php if ($membro['dizimistaIgrejaAtual'] == 0): ?>
                            <label class="radio-inline">
                                  <input type="radio" name="dizimistaFiel" value="0" checked>Não
                            </label>
                        <?php else: ?>
                            <label class="radio-inline">
                                  <input type="radio" name="dizimistaFiel" value="0">Não
                            </label>
                        <?php endif ?>

                     </div>
                  </div>

               </div>

               <div class="row">

                  <div class="col-sm-12">
                     <div class="form-group">
                        <label for="donsConhece">Conhece os ensinos bíblicos sobre os dons espirituais?</label>

                        <?php if ($membro['conheceDons'] == 1): ?>
                            <label class="radio-inline">
                                <input type="radio" name="donsConhece" value="1" checked>Sim
                            </label>
                        <?php else: ?>
                            <label class="radio-inline">
                                <input type="radio" name="donsConhece" value="1">Sim
                            </label>
                        <?php endif ?>

                        <?php if ($membro['conheceDons'] == 0): ?>
                            <label class="radio-inline">
                                  <input type="radio" name="donsConhece" value="0" checked>Não
                            </label>
                        <?php else: ?>
                            <label class="radio-inline">
                                  <input type="radio" name="donsConhece" value="0">Não
                            </label>
                        <?php endif ?>
                     </div>
                  </div>

               </div>


               <div class="row">

                  <div class="col-md-12">

                     <p>Conhece seus dons?</p>
                     <p>Se os conhece, assinale-os:</p>

                     <div class="form-group">
                       <select id="dom" multiple="multiple" name="seleciona-dons[]">

                           <?php foreach ($dons as $dom): ?>
                               <option value="<?=$dom['idDom']?>">
                                   <?=$dom['nomeDom']?>
                               </option>
                           <?php endforeach ?>

                       </select>
                     </div>

                     <div class="form-group">
                        <label for="donsPratica">Tem-no(s) praticado?</label>

                        <?php if ($membro['praticDons'] == 1): ?>
                            <label class="radio-inline">
                                <input type="radio" name="donsPratica" value="1" checked>Sim
                            </label>
                        <?php else: ?>
                            <label class="radio-inline">
                                <input type="radio" name="donsPratica" value="1">Sim
                            </label>
                        <?php endif ?>

                        <?php if ($membro['praticDons'] == 0): ?>
                            <label class="radio-inline">
                                  <input type="radio" name="donsPratica" value="0" checked>Não
                            </label>
                        <?php else: ?>
                            <label class="radio-inline">
                                  <input type="radio" name="donsPratica" value="0">Não
                            </label>
                        <?php endif ?>

                     </div>
                  </div>

               </div>
            </div>
         </div>
       </div>

         <div id="ibg2" class="tab-pane fade">
            <div class="panel-body">
               <h3 class="page-header">Entrada</h3>

               <div class="row">
                  <div class="col-md-6">

                     <div class="form-group">
                        <span class="red-color fa fa-asterisk"></span>
                        <label for="">Admissão na IBG2 - Modo: </label>
                        
                        
                        
                         <?php if ($membro['modoAdmissao'] == 'Batismo'): ?>
                            <label class="radio-inline">
                                <input type="radio" name="modoAdmissao" value="Batismo" checked>Batismo
                            </label>
                        <?php else: ?>
                            <label class="radio-inline">
                                <input type="radio" name="modoAdmissao" value="Batismo">Batismo
                            </label>
                        <?php endif ?>

                        
                        
                         <?php if ($membro['modoAdmissao'] == 'Carta'): ?>
                            <label class="radio-inline">
                                <input type="radio" name="modoAdmissao" value="Carta" checked>Carta
                            </label>
                        <?php else: ?>
                            <label class="radio-inline">
                                <input type="radio" name="modoAdmissao" value="Carta">Carta
                            </label>
                        <?php endif ?>
                        
                        
                        
                        
                        <?php if ($membro['modoAdmissao'] == 'Aclamação'): ?>
                            <label class="radio-inline">
                                  <input type="radio" name="modoAdmissao" value="Aclamação" checked>Aclamação
                            </label>
                        <?php else: ?>
                            <label class="radio-inline">
                                  <input type="radio" name="modoAdmissao" value="Aclamação">Aclamação
                            </label>
                        <?php endif ?>
                        
                        

                        <div class="radio">
                           <label for="">
                                 <input type="radio" name="modoAdmissao">Outro
                            </label>
                            <input type="text" name="modoAdmissao" class="form-control" value="">
                        </div>
                     </div>

                     <div class="form-group form-inline">
                        <span class="red-color fa fa-asterisk"></span>
                        <label for="">Data da Sessão </label>
                        <input type="date" name="dataEntrada" class="form-control datepicker" value="<?=$membro['dataAdmissao']?>" >
                     </div>
                  </div>

                  <div class="col-sm-12">
                     <div class="form-group">
                        <span class="red-color fa fa-asterisk"></span>
                        <label for="">Atividades desenvolvidas na IBG2</label>
                        <textarea class="form-control" name="atividades" ><?=$membro['atividadesIBG2']?></textarea>
                     </div>
                  </div>
               </div>

               <h3 class="page-header">Saída</h3>
               <div class="row">
                  <div class="col-md-6">

                     <div class="form-group">
                        <label for="">Saída na IBG2 - Modo: </label>

                        <label class="radio-inline">
                            <input type="radio" name="saidaModo" value="Carta">Carta
                        </label>

                        <label class="radio-inline">
                              <input type="radio" name="saidaModo" value="Desligamento">Desligamento
                        </label>

                        <label class="radio-inline">
                              <input type="radio" name="saidaModo" value="Falecimento">Falecimento
                        </label>

                        <div class="radio">
                           <label for="">
                             <input type="radio">Outro
                            </label>
                           <input type="text" name="saidaModo" class="form-control">
                        </div>
                     </div>

                     <div class="form-group form-inline">
                        <label for="">Data da Sessão </label>
                        <input type="date" name="saidaDate" class="form-control datepicker">
                     </div>
                  </div>

                  <div class="col-sm-12">
                     <div class="form-group">
                        <label for="">Observação</label>
                        <textarea class="form-control" name=""></textarea>
                     </div>
                  </div>
               </div>


               <h3 class="page-header">Readmissão</h3>
               <div class="row">
                  <div class="col-md-6">

                     <div class="form-group">
                        <label for="">Readmissão - Modo: </label>
                        <input type="text" name="readmissaoModo" class="form-control">

                     </div>
                  </div>

                  <div class="col-md-3">
                     <label for="">Data da Sessão </label>
                     <input type="date" name="readmissaoData" class="form-control datepicker">
                  </div>
               </div>
            </div>
         </div>
         <button type="submit" class="btn btn-success">Salvar</button>
         <a href="membros-cadastro-consulta.php" class="btn btn-default">Voltar</a>

      </div>
     </form>
   </section>
   <!-- fim container -->

<?php require_once 'footer.php' ?>
   <script>
   jQuery(function($){
   $("#igrejaOigemTelefone").mask("(99) 9999-9999");
   $("#telefone").mask("(99) 9999-9999");
   $("#celular").mask("(99) 9 9999-9999");
   $("#cpf").mask("999.999.999-99");
   $("#cepp").mask("99.999-999");  
});

</script>