<?php
   session_start();

   require_once 'sql/conexao.php';
   require_once 'sql/banco-usuario.php';
   require_once 'sql/banco-membros.php';

   $usuario = buscaUsuario($con, $_POST['nome'], $_POST['senha']);
   
   
  

   if ($usuario === null) {
       $_SESSION["danger"] = "Usuário ou senha inválida";
       header("Location: index.php");
   } 
   
   else {
	$usu = $usuario['FKPessoas'];
        $resposta = consultaMembrosPorID($con, $usu);
       
        
        $nomePessoa = $resposta['nome'];
        
        $_SESSION['usuarioLogado'] = $resposta['idPessoas'];
        $_SESSION['perfil'] = $usuario['perfil'];
        
        setcookie('usuario', $usu);
        setcookie('nomePessoa', $nomePessoa);
		if($usuario){
			
			header("Location:home.php");
		}else{
			$_SESSION["danger"] = "Verifique o usuário, seu privilegio é inválido!";
			header("Location: index.php");
		}
		
		
	  
   }

	die();
