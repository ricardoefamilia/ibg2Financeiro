<?php
   session_start();
   // session_destroy();

   error_reporting(E_ALL ^ E_NOTICE);


echo "<pre>";
   print_r($_SESSION['cart']);
echo "</pre>";



if ($_GET['acao'] == 'del') {
    $id = intval($_GET['id']);
    unset($_SESSION['cart'][$id]);
    header('Location: lancamento.php');
    die();
}

require_once 'sql/banco-teste.php';
require_once 'sql/conexao.php';


?>



<br>
<br>
<a href="form-lancamento.php">Index.php</a>

<table border="1">

   <thead>
      <tr>
         <th>#</th>
         <th>Nome</th>
         <th>Valor</th>
         <th>Pagamento</th>
         <th>Destinação</th>
      </tr>
   </thead>


<tbody>

   <?php foreach ($_SESSION['cart'] as $key => $value) : ?>

      <tr>
         <td>
            <a href="<?=$_SERVER['PHP_SELF']?>?acao=del&id=<?=$key ?>">
               <?=$key?>
            </a>
         </td>
         <td>
            <?php
               $pessoa = selecionaPessoa($con, $value["FKPessoa"]);
               echo $pessoa['nome'];
            ?>
         </td>
         <td><?=$value["valor"]?></td>

         <td>
            <?php if ($value["TipoEntrada"] === 1): ?>
               Dinheiro
            <?php endif; ?>

            <?php if ($value["TipoEntrada"] === 2): ?>
               Depósito
            <?php endif; ?>

            <?php if ($value["TipoEntrada"] === 3): ?>
               Cheque
            <?php endif; ?>
         </td>

         <th>
            <?php
               $destinacao = selecionaDestinacao($con, $value['especie']);
               echo $destinacao['descricao'];
            ?>
         </th>

      </tr>

   <?php endforeach ?>

</tbody>

</table>

<?php

foreach ($_SESSION['cart'] as $key => $value) :
   if (adicionaLancamento($con, $value)) {
      echo "OK" . "<br>";
   } else {
      echo mysqli_error($con) . "<br>";
   }
endforeach;


// foreach ($_SESSION['cart'] as $key => $value) :
//    if ($value["dinheiro"]) {
//        echo "INSERT INTO Entradas (TipoEntrada, Fkdestinacao, valor, especie) VALUES (
//           " . 1 . ", "
//           . $value["nomeDestinacao"] . ", "
//           . 1 . ", "
//           . $value["dinheiro"] . ")" . "<br>";
//    } elseif ($value["numero-cheque"]) {
//        echo "INSERT INTO teste (TipoEntrada, Fkdestinacao, valor, bancoCheque, nrCheque) VALUES (
//           " . 2 . ", "
//           . $value["nomeDestinacao"] . ", "
//           . $value["valor-cheque"] . ", '"
//           . $value['nome-banco'] . "', '"
//           . $value['numero-cheque'] . "', "
//           . 1 . ")" . "<br>";
//    } elseif ($value["numero-comprovante"]) {
//        echo "INSERT INTO teste (nome, nrDepositoComprovante, valor, fkDestinacao) VALUES (
//         '" . $value["nome"] . "', '"
//         . $value["numero-comprovante"] . "', "
//         . $value["valor-deposito"] . ", "
//         . $value["nomeDestinacao"] . ")" . "<br>";
//    }
// endforeach;
//
//
// if ($value["dinheiro"]) {
//     echo "INSERT INTO teste (nome, valor) VALUES ('" . $value["nome"] . "'," . $value["dinheiro"] . ")" . "<br>";
// } elseif ($value["numero-cheque"]) {
//     echo "INSERT INTO teste (nome, numeroCheque, valor, nomeBanco) VALUES (
//       '" . $value["nome"] . "', '"
//       . $value["numero-cheque"] . "', "
//       . $value["valor-cheque"] . ", '"
//       . $value['nome-banco'] . "')" . "<br>";
// } elseif ($value["numero-comprovante"]) {
//     echo "INSERT INTO teste (nome, numeroDeposito, valor) VALUES (
//      '" . $value["nome"] . "', '"
//      . $value["numero-comprovante"] . "', "
//      . $value["valor-deposito"] . ")" . "<br>";
// }
