<?php

    session_start();

    $id = $_POST['id'];

    if ($_POST['especie'] == 1) {

        if ($_POST['dinheiro'] < 1) {
            $_SESSION['danger'] = "Não é possível colocar valor abaixo de 0";
            header('Location: form-saida-altera.php?id='.$id);
        } else {
            $_SESSION['cart-saida'][$id]['especie'] = 1;
            $_SESSION['cart-saida'][$id]['valor'] = $_POST['dinheiro'];
            $_SESSION['cart-saida'][$id]['destinacao'] = $_POST['destinacao'];
            $_SESSION['cart-saida'][$id]['obs'] = $_POST['obs'];

            $_SESSION['success'] = 'Saida alterado com sucesso';
            header('Location: form-saida.php');
        }
    }

    if ($_POST['especie'] == 2) {

        if ($_POST['deposito-valor'] < 1) {
            $_SESSION['danger'] = "Não é possível colocar valor abaixo de 0";
            header('Location: form-saida-altera.php?id='.$id);
        } else {
            $_SESSION['cart-saida'][$id]['especie'] = 2;
            $_SESSION['cart-saida'][$id]['valor'] = $_POST['deposito-valor'];
            $_SESSION['cart-saida'][$id]['numero-comprovante'] = $_POST['deposito-comprovante'];
            $_SESSION['cart-saida'][$id]['destinacao'] = $_POST['destinacao'];
            $_SESSION['cart-saida'][$id]['obs'] = $_POST['obs'];

            $_SESSION['success'] = 'Saida alterado com sucesso';
            header('Location: form-saida.php');
        }
    }

    if ($_POST['especie'] == 3) {

        if ($_POST['cheque-valor'] < 1) {
            $_SESSION['danger'] = "Não é possível colocar valor abaixo de 0";
            header('Location: form-saida-altera.php?id='.$id);
        } else {
            $_SESSION['cart-saida'][$id]['especie'] = 3;
            $_SESSION['cart-saida'][$id]['numero-cheque'] = $_POST['cheque-numero'];
            $_SESSION['cart-saida'][$id]['agencia'] = $_POST['cheque-agencia'];
            $_SESSION['cart-saida'][$id]['conta'] = $_POST['cheque-conta'];
            $_SESSION['cart-saida'][$id]['valor'] = $_POST['cheque-valor'];
            $_SESSION['cart-saida'][$id]['nome-banco'] = $_POST['nome-banco'];
            $_SESSION['cart-saida'][$id]['destinacao'] = $_POST['destinacao'];
            $_SESSION['cart-saida'][$id]['obs'] = $_POST['obs'];

            $_SESSION['success'] = 'Saida alterado com sucesso';
            header('Location: form-saida.php');
        }
    }

 ?>
