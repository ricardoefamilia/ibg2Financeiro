<?php
   session_start();
   
     
   $dataOld = addslashes($_POST['data']);
	
	$dataP = explode('/', $dataOld);
	$data = $dataP[2].'-'.$dataP[1].'-'.$dataP[0];

   
   if (empty($_SESSION['cart-saida'])) {
       $_SESSION['cart-saida'] = [];
   }

 
   
   // Verifica se existe o campo data
   if (isset($data)) {
       if (empty($data)) {
           $_SESSION['danger'] = 'O campo Data da Saida não pode ficar em branco!';
           header('Location: form-saida.php');
           die();
       }
   }
   // Verifica se existe o campo Dinheiro
   if (isset($_POST['especie'])) {
       if (empty($_POST['especie'])) {
           $_SESSION['danger'] = 'O campo especie não pode ficar em branco!';
           header('Location: form-saida.php');
           die();
       }
   }
    //Verifica se existe o campo Depósito
   if (isset($_POST['comprovante-deposito']) && isset($_POST['valor-deposito'])) {
       if (empty($_POST['comprovante-deposito']) || empty($_POST['valor-deposito'])) {
           $_SESSION['danger'] = 'Os campos em Depósito não podem ficar em branco!';
           header('Location: form-saida.php');
           die();
       }
   }

   
   // Verifica se existe o campo Cheque
   if (isset($_POST['numero-cheque']) && isset($_POST['valor-cheque']) && isset($_POST['nome-banco'])) {
       if (empty($_POST['numero-cheque']) || empty($_POST['valor-cheque']) || empty($_POST['nome-banco'])) {
           $_SESSION['danger'] = 'Os campos em Cheque não podem ficar em branco!';
           header('Location: form-saida.php');
           die();
       }
   }


   // DINHEIRO => Normal
   if (isset($data) && isset($_POST['quantidade-dinheiro'])) {
       if (!empty($data) && !empty($_POST['quantidade-dinheiro'])) {
           array_push($_SESSION['cart-saida'],
           [
              
              "valor" => $_POST['quantidade-dinheiro'],
              "especie" => 1,
               "data" => $data,
              "destinacao" => $_POST['destinacao'],
              "obs" => $_POST['obs']
           ]);
       }
   }


    // DEPOSITO => Normal
    if (isset($data) && isset($_POST['comprovante-deposito']) && isset($_POST['valor-deposito'])) {
        if (!empty($data) && !empty($_POST['comprovante-deposito']) && !empty($_POST['valor-deposito'])) {
            array_push($_SESSION['cart-saida'],
           [
               "data" => $data,
               "numero-comprovante" => $_POST['comprovante-deposito'],
               "valor" => $_POST['valor-deposito'],
               "especie" => 2,
               "destinacao" => $_POST['destinacao'],
               "obs" => $_POST['obs']
           ]);
        }
    }

   // CHEQUE => Normal
   if (isset($data) && isset($_POST['numero-cheque']) && isset($_POST['valor-cheque']) && isset($_POST['nome-banco'])) {
       if (!empty($data) && !empty($_POST['numero-cheque']) && !empty($_POST['valor-cheque']) && !empty($_POST['nome-banco'])) {
           array_push($_SESSION['cart-saida'],
           [
              
              "numero-cheque" => $_POST['numero-cheque'],
              "agencia" => $_POST['cheque-agencia'],
              "conta" => $_POST['cheque-conta'],
              "valor" => $_POST['valor-cheque'],
              "nome-banco" => $_POST['nome-banco'],
              "especie" => 3,
              "data" => $data,
              "destinacao" => $_POST['destinacao'],
              "obs" => $_POST['obs']
           ]);
       }
   }


   header('Location: form-saida.php');
   die();

   
