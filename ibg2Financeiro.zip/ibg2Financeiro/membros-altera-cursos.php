<?php
    require_once 'top.php';
    require_once 'sql/banco-cursos.php';
    $idCurso = $_GET['idCurso'];
    $idMembro = $_GET['membro'];
    $curso = buscaCursosPorId($con, $idCurso);
?>

<section class="container">
    <h3 class="page-header">Especialização</h3>
    <div class="row">
        <div class="col-sm-12">
            <div class="table-responsive">
                <form action="altera-curso.php" method="post">
                    <input type="hidden" name="idMembro" value="<?=$idMembro?>">
                    <input type="hidden" name="idCursoRealizado" value="<?=$curso['idCursosRealizados']?>">
                <table class="table">

                    <thead>
                        <tr>
                            <th class="text-center">Curso</th>
                            <th class="text-center">Titulação</th>
                            <th class="text-center">Instituição</th>
                        </tr>
                    </thead>

                    <tbody id="tabela-especializacao">
                        <tr>
                            <td> <input type="text" name="curso" class="form-control" value="<?=$curso['curso']?>" > </td>
                            <td> <input type="text" name="titulacao" class="form-control" value="<?=$curso['titulacao']?>"> </td>
                            <td> <input type="text" name="instituicao" class="form-control" value="<?=$curso['instituicao']?>"> </td>
                        </tr>
                    </tbody>

                </table>
            </div>
                    <button type="submit" class="btn btn-success">
                        <span class="fa fa-check"></span> Alterar
                    </button>
                    <a href="membros-cadastro-cursos.php?id=<?=$idMembro?>" class="btn btn-default">
                        <span class="fa fa-angle-double-left"></span> Voltar
                    </a>
                </form>
        </div>
    </div>

</section>

<?php require_once 'footer.php' ?>
