let checkLancamento = document.querySelector('#confirma-lancamento');
let botaoConfirmacao = document.querySelector('#lancamento');

checkLancamento.addEventListener('change', function() {
    if (checkLancamento.checked) {
        botaoConfirmacao.removeAttribute('disabled', false);
    } else {
        botaoConfirmacao.setAttribute('disabled', true);
    }
})
