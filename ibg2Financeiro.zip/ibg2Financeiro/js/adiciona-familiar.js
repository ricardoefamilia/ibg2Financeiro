let corpoTabela = document.querySelector('#tabela-familiar');
let botaoAdicionaFamiliar = document.querySelector('#add-familiar');

botaoAdicionaFamiliar.addEventListener('click', function(event) {
    event.preventDefault();


    let familiarTr = document.createElement('tr');

    let familiarNome = document.createElement('td');
    familiarNome.innerHTML = '<input type="text" name="nomeFamiliar[]" class="form-control">';

    let familiarParentesco = document.createElement('td');
    familiarParentesco.innerHTML = '<input type="text" name="parentesco[]" class="form-control">';

    let familiarEvangelico = document.createElement('td');
    familiarEvangelico.innerHTML = `
        <select class="form-control" name="familiarEvangelico[]">
            <option value="">Selecione...</option>
            <option value="1">Sim</option>
            <option value="2">Não</option>
        </select>
    `;

    // let familiarMembroIbg2 = document.createElement('td');
    // familiarMembroIbg2.innerHTML = `
    //     <select class="form-control" name="familiarIBG2[]">
    //         <option value="">Selecione...</option>
    //         <option value="1">Sim</option>
    //         <option value="2">Não</option>
    //     </select>
    // `;

    let familiarDataNascimentoFamiliar = document.createElement('td');
    familiarDataNascimentoFamiliar.innerHTML = '<input type="date" name="dataNascimentoFamiliar[]" class="form-control datepicker">';


    familiarTr.appendChild(familiarNome);
    familiarTr.appendChild(familiarParentesco);
    familiarTr.appendChild(familiarEvangelico);
    // familiarTr.appendChild(familiarMembroIbg2);
    familiarTr.appendChild(familiarDataNascimentoFamiliar);

    corpoTabela.appendChild(familiarTr);
});
