$('#form-membros').validate({

    errorElement: 'span',
    errorClass: 'error',

    errorPlacement: function (error, element) {
        if (element.is(":radio")) {
            error.insertBefore(element.closest("label"));
        } else {
            error.insertAfter(element);
        }
    },


    rules: {
        tipoPessoa: {
            required: true
        },
        nome: {
            required: true
        },
        sexo: {
            required: true
        },
        rg: {
            required: true
        },
        orgaoExpedidor: {
            required: true
        },
        cpf: {
            required: true
        },
        dataNascimento: {
            required: true
        },
        nascimentoEstado: {
            required: true
        },
        nascimentoCidade: {
            required: true
        },
        estadoCivil: {
            required: true
        },
        tipoSanguineo: {
            required: true
        },
        escolaridade: {
            required: true
        },
        "curso[]": {
            required: true
        },
        "titulacao[]": {
            required: true
        },
        cep: {
            required: true
        },
        endereco: {
            required: true
        },
        estado: {
            required: true
        },
        atividades: {
            required: true
        }
    },

    messages: {
        tipoPessoa: {
            required: 'Campo obrigatório'
        },
        nome: {
            required: 'Campo obrigatório'
        },
        sexo: {
            required: 'Campo obrigatório'
        },
        rg: {
            required: 'Campo obrigatório'
        },
        orgaoExpedidor: {
            required: 'Campo obrigatório'
        },
        cpf: {
            required: 'Campo obrigatório'
        },
        dataNascimento: {
            required: 'Campo obrigatório'
        },
        nascimentoEstado: {
            required: 'Campo obrigatório'
        },
        nascimentoCidade: {
            required: 'Campo obrigatório'
        },
        estadoCivil: {
            required: 'Campo obrigatório'
        },
        tipoSanguineo: {
            required: 'Campo obrigatório'
        },
        escolaridade: {
            required: 'Campo obrigatório'
        },
        "curso[]": {
            required: 'Campo obrigatório'
        },
        "titulacao[]": {
            required: 'Campo obrigatório'
        },
        cep: {
            required: 'Campo obrigatório'
        },
        endereco: {
            required: 'Campo obrigatório'
        },
        estado: {
            required: 'Campo obrigatório'
        },
        atividades: {
            required: 'Campo obrigatório'
        }
    }

});
