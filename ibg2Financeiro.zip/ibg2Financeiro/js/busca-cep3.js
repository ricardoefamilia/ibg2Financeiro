function limpa_formulário_cep3() {
    //Limpa valores do formulário de cep.
    document.getElementById('igrejaOrigemBairro').value = ("");
    document.getElementById('igrejaOrigemEndereco').value = ("");
    document.getElementById('igrejaOrigemCidade').value = ("");
    document.getElementById('igrejaOrigemEstado').value = ("");
}

function meu_callback3(conteudo) {
    if (!("erro" in conteudo)) {
        //Atualiza os campos com os valores.
        document.getElementById('igrejaOrigemEndereco').value = (conteudo.logradouro);
        document.getElementById('igrejaOrigemBairro').value = (conteudo.bairro);
        document.getElementById('igrejaOrigemCidade').value = (conteudo.localidade);
        document.getElementById('igrejaOrigemEstado').value = (conteudo.uf);
    } //end if.
    else {
        //CEP não Encontrado.
        limpa_formulário_cep3();
        alert("CEP não encontrado.");
    }
}

function pesquisacep3(valor3) {

    //Nova variável "cep" somente com dígitos.
    var cep3 = valor3.replace(/\D/g, '');

    //Verifica se campo cep possui valor informado.
    if (cep3 != "") {

        //Expressão regular para validar o CEP.
        var validacep3 = /^[0-9]{8}$/;

        //Valida o formato do CEP.
        if (validacep3.test(cep3)) {

            //Preenche os campos com "..." enquanto consulta webservice.
            document.getElementById('igrejaOrigemBairro').value = "...";
            document.getElementById('igrejaOrigemEndereco').value = "...";
            document.getElementById('igrejaOrigemCidade').value = "...";
            document.getElementById('igrejaOrigemEstado').value = "...";

            //Cria um elemento javascript.
            var script = document.createElement('script');

            //Sincroniza com o callback.
            script.src = '//viacep.com.br/ws/' + cep3 + '/json/?callback=meu_callback3';

            //Insere script no documento e carrega o conteúdo.
            document.body.appendChild(script);

        } //end if.
        else {
            //cep é inválido.
            limpa_formulário_cep3();
            alert("Formato de CEP inválido.");
        }
    } //end if.
    else {
        //cep sem valor, limpa formulário.
        limpa_formulário_cep3();
    }
}