$('#check-dinheiro').click(function() {

   let campoDinheiro = $('#dinheiro');

   if ($('#check-dinheiro').is(':checked')) {
      campoDinheiro.prop('disabled', false);
      campoDinheiro.prop('placeholder', 'Valor em dinheiro');
      campoDinheiro.attr('name', 'quantidade-dinheiro');
   } else {
      campoDinheiro.prop('disabled', true);
      campoDinheiro.removeAttr('placeholder');
      campoDinheiro.removeAttr('name');
   }

});

$('#check-deposito').click(function() {

   let comprovanteDeposito = $('#comprovante-deposito');
   let valorDeposito = $('#valor-deposito');

   if ($('#check-deposito').is(':checked')) {
      comprovanteDeposito.prop('disabled', false);
      comprovanteDeposito.prop('placeholder', 'Número do comprovante');
      comprovanteDeposito.attr('name', 'comprovante-deposito');

      valorDeposito.prop('disabled', false);
      valorDeposito.prop('placeholder', 'Valor do depósito');
      valorDeposito.attr('name', 'valor-deposito');
   } else {
      comprovanteDeposito.prop('disabled', true);
      comprovanteDeposito.removeAttr('placeholder');
      comprovanteDeposito.removeAttr('name');

      valorDeposito.prop('disabled', true);
      valorDeposito.removeAttr('placeholder');
      valorDeposito.removeAttr('name');
   }

});

$('#check-cheque').click(function() {

   let numeroCheque = $('#cheque');
   let agencia = $('#cheque-agencia');
   let conta = $('#cheque-conta');
   let nomeBanco = $('#banco');
   let valorCheque = $('#valor-cheque');

   if ($('#check-cheque').is(':checked')) {
      numeroCheque.prop('disabled', false);
      numeroCheque.prop('placeholder', 'Número do cheque');
      numeroCheque.attr('name', 'numero-cheque');

      agencia.prop('disabled', false);
      agencia.prop('placeholder', 'Agência');
      agencia.attr('name', 'cheque-agencia');

      conta.prop('disabled', false);
      conta.prop('placeholder', 'Conta');
      conta.attr('name', 'cheque-conta');

      nomeBanco.prop('disabled', false);
      nomeBanco.attr('name', 'nome-banco');

      valorCheque.prop('disabled', false);
      valorCheque.prop('placeholder', 'Valor do cheque');
      valorCheque.attr('name', 'valor-cheque');

   } else {
      numeroCheque.prop('disabled', true);
      numeroCheque.removeAttr('placeholder');
      numeroCheque.removeAttr('name');

      agencia.prop('disabled', true);
      agencia.removeAttr('placeholder');
      agencia.removeAttr('name');

      conta.prop('disabled', true);
      conta.removeAttr('placeholder');
      conta.removeAttr('name');

      nomeBanco.prop('disabled', true);
      nomeBanco.removeAttr('placeholder');
      nomeBanco.removeAttr('name');

      valorCheque.prop('disabled', true);
      valorCheque.removeAttr('placeholder');
      valorCheque.removeAttr('name');

   }

});
