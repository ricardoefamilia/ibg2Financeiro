let corpoTabela2 = document.querySelector('#tabela-familiar2');
let botaoAdicionaFamiliarIbg2 = document.querySelector('#add-familiar2');

botaoAdicionaFamiliarIbg2.addEventListener('click', function(event) {
    event.preventDefault();


    let familiarTr2 = document.createElement('tr');

    let familiarNome2 = document.createElement('td');
    familiarNome2.innerHTML = '<input type="text" name="nomeFamiliar2[]" class="form-control">';

    let familiarParentesco2 = document.createElement('td');
    familiarParentesco2.innerHTML = '<input type="text" name="parentesco2[]" class="form-control">';

    let familiarEvangelico2 = document.createElement('td');
    familiarEvangelico2.innerHTML = `
        <select class="form-control" name="familiarEvangelico2[]">
            <option value="">Selecione...</option>
            <option value="1">Sim</option>
            <option value="2">Não</option>
        </select>
    `;

    // let familiarMembroIbg2 = document.createElement('td');
    // familiarMembroIbg2.innerHTML = `
    //     <select class="form-control" name="familiarIBG2[]">
    //         <option value="">Selecione...</option>
    //         <option value="1">Sim</option>
    //         <option value="2">Não</option>
    //     </select>
    // `;

    let familiarDataNascimentoFamiliar2 = document.createElement('td');
    familiarDataNascimentoFamiliar2.innerHTML = '<input type="date" name="dataNascimentoFamiliar2[]" class="form-control datepicker">';


    familiarTr2.appendChild(familiarNome2);
    familiarTr2.appendChild(familiarParentesco2);
    familiarTr2.appendChild(familiarEvangelico2);
    // familiarTr.appendChild(familiarMembroIbg2);
    familiarTr2.appendChild(familiarDataNascimentoFamiliar2);

    corpoTabela2.appendChild(familiarTr2);
});
