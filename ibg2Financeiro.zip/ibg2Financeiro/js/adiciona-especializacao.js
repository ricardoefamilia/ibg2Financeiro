let adicionaEspecializacao = document.querySelector('#adiciona-especializacao');

adicionaEspecializacao.addEventListener('click', function (event) {

    event.preventDefault();

    let especializacaoTr = document.createElement('tr');
    let corpoTabela = document.querySelector('#tabela-especializacao');


    let cursoTd = document.createElement('td');
    cursoTd.innerHTML = "<input type='text' name='curso[]' id='curso' class='form-control'>";

    let titulacaoTd = document.createElement('td');
    titulacaoTd.innerHTML = "<input type='text' name='titulacao[]' id='titulacao' class='form-control'>";

    let instituicaoTd = document.createElement('td');
    instituicaoTd.innerHTML = "<input type='text' name='instituicao[]' id='instituicao' class='form-control'>";

    especializacaoTr.appendChild(cursoTd);
    especializacaoTr.appendChild(titulacaoTd);
    especializacaoTr.appendChild(instituicaoTd);

    corpoTabela.appendChild(especializacaoTr);
});
