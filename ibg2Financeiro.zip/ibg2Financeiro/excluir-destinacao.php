<?php
   session_start();

   require_once 'sql/conexao.php';
   require_once 'sql/banco-destinacao.php';

   $id = $_GET['id'];
   
   if (removeDestinacao($con, $id)) {
       $_SESSION['success'] = 'Destinação excluida com sucesso.';
       header('Location: form-destinacao.php');
   }

   die();
