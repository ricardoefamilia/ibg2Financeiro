<?php

require_once 'sql/conexao.php';
require_once 'sql/banco-membros.php';

    $idMembro = $_POST['idMembro'];
    echo "$idMembro<br>";

    $familiar['nomeFamiliar'] = $_POST['nomeFamiliar'];
    $familiar['parentesco'] = $_POST['parentesco'];
    $familiar['familiarEvangelico'] = $_POST['familiarEvangelico'];
    $familiar['dataNascimentoFamiliar'] = $_POST['dataNascimentoFamiliar'];

    $familiarIBG2['nomeFamiliar2'] = $_POST['nomeFamiliar2'];
    $familiarIBG2['parentesco2'] = $_POST['parentesco2'];
    $familiarIBG2['familiarEvangelico2'] = $_POST['familiarEvangelico2'];
    $familiarIBG2['dataNascimentoFamiliar2'] = $_POST['dataNascimentoFamiliar2'];

    echo "Familiar normal";
    echo "<pre>";
        print_r($familiar);
    echo "</pre>";

    echo "<br>Familiar IBG2";
    echo "<pre>";
        print_r($familiarIBG2);
    echo "</pre>";

    if (inserirMembrosFamiliares2($con, $familiar, $familiarIBG2, $idMembro)) {
        echo "SUCESSO";
    } else {
        echo mysqli_error($con);
    }
